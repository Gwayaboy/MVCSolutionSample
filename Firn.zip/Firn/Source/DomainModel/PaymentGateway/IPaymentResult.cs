namespace Intrigma.Firn.DomainModel.PaymentGateway
{
    public interface IPaymentResult
    {
        string RawMessage { get; }
        bool Success { get; }
    }
}