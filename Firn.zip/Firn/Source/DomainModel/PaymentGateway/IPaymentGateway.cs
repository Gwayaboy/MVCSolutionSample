namespace Intrigma.Firn.DomainModel.PaymentGateway
{
    public interface IPaymentGateway
    {
        IPaymentResult IssueRefund(Customer customer, decimal amount);
        IPaymentResult MakePayment(Customer customer, decimal amount);
        void DeletePaymentMethod(int paymentMethodId);
        int CreatePaymentMethod(BillingType billingType, PaymentType paymentType);
        PaymentType GetPaymentMethod(BillingType billingType, int id);
    }
}