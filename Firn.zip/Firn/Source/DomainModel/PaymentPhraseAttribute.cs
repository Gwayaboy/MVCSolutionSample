using System;

namespace Intrigma.Firn.DomainModel
{
    [AttributeUsage(AttributeTargets.Field, AllowMultiple = false)]
    public class PaymentPhraseAttribute : Attribute, IDescriptionAttribute
    {
        private readonly string _text;

        public PaymentPhraseAttribute(string text)
        {
            _text = text;
        }

        #region IDescriptionAttribute Members

        public string Text
        {
            get { return _text; }
        }

        #endregion
    }
}