using System;
using System.Collections.Generic;
using NHibernate.Mapping.Attributes;

namespace Intrigma.Firn.DomainModel
{
    [Subclass(ExtendsType = typeof(BaseTransaction), NameType = typeof(BaseAccountTransaction))]
    public class BaseAccountTransaction : BaseTransaction
    {
        public static readonly TimeSpan TimeBeforeDueDateToBill = TimeSpan.FromDays(4 * 7);

        public BaseAccountTransaction(DateTime date, decimal amount, string name, string description)
            : base(date, amount, name, description) {}

        public BaseAccountTransaction() {}

        public override IList<Installment> CalculateInstallments(int months)
        {
            return new[] {new Installment(Date, Date - TimeBeforeDueDateToBill, Amount, this)};
        }
    }
}