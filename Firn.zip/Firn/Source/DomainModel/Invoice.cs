using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using Intrigma.Firn.DomainModel.PaymentGateway;
using NHibernate.Mapping.Attributes;

namespace Intrigma.Firn.DomainModel
{
    [Class(NameType = typeof(Invoice))]
    [AttributeIdentifier("Id.Generator", Value = "assigned")]
    public class Invoice : IntegerKeyedObject
    {
        public const string ToStringFormat = "Invoice [#{0} for {1}; dated {2:d}; due {3:d}]";

        [ManyToOne(Access = "field", NotNull = true, Column = "CustomerId")]
        private readonly Customer _customer;

        [Property(Access = "field", NotNull = true, Column = "DueDate")]
        private readonly DateTime _dueDate;

        [Property(Access = "field", NotNull = true, Column = "InvoiceDate")]
        private readonly DateTime _invoiceDate;

        [Bag(0, Access = "field", OrderBy = "ItemDate DESC", Cascade = "all-delete-orphan")]
        [Key(1, Column = "InvoiceId")]
        [OneToMany(2, ClassType = typeof(InvoiceLineItem))]
        private readonly IList<InvoiceLineItem> _lineItems = new List<InvoiceLineItem>();

        [Property(Access = "field", Column = "DatePaid")]
        private DateTime? _datePaid;

        [Property(Access = "field", Column = "PaymentResult")]
        private string _paymentResult;

        [Property(Access = "field", NotNull = true, Column = "PaymentStatus")]
        private InvoicePaymentStatus _paymentStatus;

        [Property(Access = "field", Column = "Total", NotNull = true)]
        private decimal _total;

        public Invoice(Customer customer, int id, DateTime invoiceDate, DateTime dueDate) : base(id)
        {
            _invoiceDate = invoiceDate;
            _dueDate = dueDate;
            _customer = customer;
            _customer.AddInvoice(this);
        }

        public Invoice() {}

        public virtual DateTime InvoiceDate
        {
            get { return _invoiceDate; }
        }

        public virtual DateTime DueDate
        {
            get { return _dueDate; }
        }

        public virtual IList<InvoiceLineItem> LineItems
        {
            get { return new ReadOnlyCollection<InvoiceLineItem>(_lineItems); }
        }

        public virtual decimal Total
        {
            get { return _total; }
        }

        public virtual Customer Customer
        {
            get { return _customer; }
        }

        public virtual InvoicePaymentStatus PaymentStatus
        {
            get { return _paymentStatus; }
        }

        public virtual string PaymentResult
        {
            get { return _paymentResult; }
        }

        public virtual DateTime? DatePaid
        {
            get { return _datePaid; }
        }

        public virtual void AddLineItem(InvoiceLineItem item)
        {
            _lineItems.Add(item);
            _total += item.Price;
        }

        public virtual IPaymentResult Pay(DateTime date, IPaymentGateway gateway)
        {
            return Pay(date, _total, gateway);
        }

        public virtual void Cancel()
        {
            _paymentStatus = InvoicePaymentStatus.Canceled;
            _paymentResult = null;
        }

        public virtual void MarkPaid(DateTime date)
        {
            _paymentStatus = InvoicePaymentStatus.Paid;
            _paymentResult = null;
            _datePaid = date;
        }

        public virtual IPaymentResult Pay(DateTime date, decimal amount, IPaymentGateway gateway)
        {
            var result = _customer.MakePayment(date, amount, gateway);
            if (result.Success)
            {
                MarkPaid(date);
            }
            else
            {
                _paymentStatus = InvoicePaymentStatus.PaymentFailed;
            }
            _paymentResult = result.RawMessage;
            return result;
        }

        public override string ToString()
        {
            return string.Format(ToStringFormat, Id, _customer, _invoiceDate, _dueDate);
        }

        public virtual void RecordPayment(DateTime date, BillingType billingType, decimal amount)
        {
            _customer.RecordPayment(date, billingType, amount);
            MarkPaid(date);
        }
    }
}