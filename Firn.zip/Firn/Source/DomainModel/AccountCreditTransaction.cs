using System;
using NHibernate.Mapping.Attributes;

namespace Intrigma.Firn.DomainModel
{
    [Subclass(ExtendsType = typeof(BaseAccountTransaction), DiscriminatorValue = "Credit",
        NameType = typeof(AccountCreditTransaction))]
    public class AccountCreditTransaction : BaseAccountTransaction
    {
        public const string DefaultName = "Credit";

        public AccountCreditTransaction(DateTime date, decimal amount, string reason)
            : base(date, -amount, DefaultName, reason) {}

        public AccountCreditTransaction() {}
    }
}