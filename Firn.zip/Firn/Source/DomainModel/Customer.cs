using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Net.Mail;
using Iesi.Collections.Generic;
using Intrigma.Firn.DomainModel.PaymentGateway;
using NHibernate.Mapping.Attributes;

namespace Intrigma.Firn.DomainModel
{
    [Class(NameType = typeof(Customer))]
    [AttributeIdentifier("Id.Generator", Value = "assigned")]
    public class Customer : IntegerKeyedObject
    {
        public const string AddressFormat = "{0}\n{1}, {2} {3}";
        public const string FullNameFormat = "{0} {1}";
        public const string InvalidEmailAddressFormat = "{0} is not a valid email address.";
        public const string ToStringFormat = "Customer [{0}]";

        [Bag(0, Access = "field", OrderBy = "InvoiceDate desc", Inverse = true, Cascade = "save-update")]
        [Key(1, Column = "CustomerId")]
        [OneToMany(2, ClassType = typeof(Invoice))]
        private readonly IList<Invoice> _invoices = new List<Invoice>();

        [Bag(0, Access = "field", Cascade = "all")]
        [Key(1, Column = "CustomerId")]
        [OneToMany(2, ClassType = typeof(Subscription))]
        private readonly IList<Subscription> _subscriptions = new List<Subscription>();

        [Bag(0, Access = "field", OrderBy = "TransactionDate desc", Cascade = "all")]
        [Key(1, Column = "CustomerId")]
        [OneToMany(2, ClassType = typeof(BaseTransaction))]
        private readonly IList<BaseTransaction> _transactions = new List<BaseTransaction>();

        private string _attnFirstName = string.Empty;
        private string _attnLastName = string.Empty;
        private string _billingNotes = string.Empty;
        private BillingPeriod _billingPeriod = BillingPeriod.Yearly;
        private DateTime? _billingStartDate;
        private BillingType _billingType;
        private string _city = string.Empty;
        private string _emailAddress = string.Empty;
        private string _name = string.Empty;
        private DateTime? _nextInvoiceDate;
        private string _nextSteps = string.Empty;
        private DateTime? _nextStepsDate;
        private int? _paymentMethodId;
        private string _phone = string.Empty;

        [Set(0, Access = "field", Table = "CustomerSecondaryEmailAddress")]
        [Key(1, Column = "CustomerId")]
        [Element(2, Column = "EmailAddress", TypeType = typeof(string), NotNull = true)]
        private Iesi.Collections.Generic.ISet<string> _secondaryEmailAddresses = new HashedSet<string>();

        private string _state = string.Empty;
        private string _streetAddress1 = string.Empty;
        private string _streetAddress2 = string.Empty;
        private string _zip = string.Empty;

        [Property(NotNull = true)]
        public virtual string AttnLastName
        {
            get { return _attnLastName; }
            set { _attnLastName = value; }
        }

        [Property(NotNull = true)]
        public virtual string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        [Property(NotNull = true)]
        public virtual string StreetAddress1
        {
            get { return _streetAddress1; }
            set { _streetAddress1 = value; }
        }

        [Property(NotNull = true)]
        public virtual string StreetAddress2
        {
            get { return _streetAddress2; }
            set { _streetAddress2 = value; }
        }

        [Property(NotNull = true)]
        public virtual string City
        {
            get { return _city; }
            set { _city = value; }
        }

        [Property(NotNull = true)]
        public virtual string State
        {
            get { return _state; }
            set { _state = value; }
        }

        [Property(NotNull = true)]
        public virtual string Zip
        {
            get { return _zip; }
            set { _zip = value; }
        }

        [Property(NotNull = true)]
        public virtual string EmailAddress
        {
            get { return _emailAddress; }
            set { _emailAddress = value; }
        }

        public virtual IList<Invoice> Invoices
        {
            get { return new ReadOnlyCollection<Invoice>(_invoices); }
        }

        [Property]
        public virtual BillingType BillingType
        {
            get { return _billingType; }
            set { _billingType = value; }
        }

        public virtual string Address
        {
            get
            {
                var streetPart = _streetAddress1 +
                                 (string.IsNullOrEmpty(_streetAddress2) ? string.Empty : "\n" + _streetAddress2);
                return string.Format(AddressFormat, streetPart, _city, _state, _zip);
            }
        }

        [Property]
        public virtual int? PaymentMethodId
        {
            get { return _paymentMethodId; }
            set { _paymentMethodId = value; }
        }

        [Property]
        public virtual DateTime? BillingStartDate
        {
            get { return _billingStartDate; }
            set { _billingStartDate = value; }
        }

        [Property]
        public virtual BillingPeriod BillingPeriod
        {
            get { return _billingPeriod; }
            set { _billingPeriod = value; }
        }

        public virtual decimal EndingBalance
        {
            get
            {
                decimal total = 0;
                foreach (var transaction in _transactions)
                {
                    total += transaction.Amount;
                }
                return total;
            }
        }

        public virtual IList<BaseTransaction> Transactions
        {
            get { return new ReadOnlyCollection<BaseTransaction>(_transactions); }
        }

        [Property(NotNull = true)]
        public virtual string Phone
        {
            get { return _phone; }
            set { _phone = value; }
        }

        [Property(NotNull = true)]
        public virtual string AttnFirstName
        {
            get { return _attnFirstName; }
            set { _attnFirstName = value; }
        }

        public virtual string AttnFullName
        {
            get { return string.Format(FullNameFormat, _attnFirstName, _attnLastName); }
        }

        public virtual IList<Subscription> Subscriptions
        {
            get { return new ReadOnlyCollection<Subscription>(_subscriptions); }
        }

        [Property]
        public virtual DateTime? NextInvoiceDate
        {
            get { return _nextInvoiceDate; }
            set { _nextInvoiceDate = value; }
        }

        public virtual bool CanAutomaticallyChargePayments
        {
            get { return _billingType != BillingType.MailPayment; }
        }

        public virtual Iesi.Collections.Generic.ISet<string> SecondaryEmailAddresses
        {
            get { return _secondaryEmailAddresses; }
        }

        public virtual bool CanSendEmail
        {
            get { return !string.IsNullOrEmpty(_emailAddress); }
        }

        [Property(0, Type = "StringClob")]
        [Column(1, Name = "BillingNotes", SqlType = "NTEXT", NotNull = true)]
        public virtual string BillingNotes
        {
            get { return _billingNotes; }
            set { _billingNotes = value; }
        }

        [Property(NotNull = true)]
        public virtual string NextSteps
        {
            get { return _nextSteps; }
            set { _nextSteps = value; }
        }

        [Property]
        public virtual DateTime? NextStepsDate
        {
            get { return _nextStepsDate; }
            set { _nextStepsDate = value; }
        }

        protected internal virtual void AddInvoice(Invoice invoice)
        {
            // Use the Invoice constructor instead of this method.
            _invoices.Add(invoice);
            _nextInvoiceDate = invoice.InvoiceDate.AddMonths((int) _billingPeriod);
        }

        public virtual void AddTransaction(BaseTransaction accountTransaction)
        {
            _transactions.Add(accountTransaction);
        }

        public virtual IPaymentResult IssueRefund(DateTime date, decimal amount, string reason, IPaymentGateway gateway)
        {
            var result = gateway.IssueRefund(this, amount);
            if (result.Success)
            {
                AddTransaction(new RefundTransaction(date, amount, reason, _billingType));
            }
            return result;
        }

        public virtual IPaymentResult MakePayment(DateTime date, decimal amount, IPaymentGateway gateway)
        {
            var result = gateway.MakePayment(this, amount);
            if (result.Success)
            {
                AddTransaction(new PaymentTransaction(date, amount, _billingType));
            }
            return result;
        }

        public virtual void AddSubscription(Subscription subscription)
        {
            _subscriptions.Add(subscription);
            AddTransaction(subscription.Transaction);
        }

        public virtual void RecordPayment(DateTime date, BillingType type, decimal amount)
        {
            AddTransaction(new PaymentTransaction(date, amount, type));
        }

        public virtual void AddAccountCredit(DateTime date, decimal amount, string reason)
        {
            AddTransaction(new AccountCreditTransaction(date, amount, reason));
        }

        public virtual void AddAccountCharge(DateTime date, string name, string description, decimal amount)
        {
            AddTransaction(new AccountChargeTransaction(date, amount, name, description));
        }

        public virtual void CheckSubscriptionRenewals(DateTime date)
        {
            // We might be adding renewal subscriptions here, so enumerate over a clone of the list.
            foreach (var subscription in new List<Subscription>(_subscriptions))
            {
                subscription.CheckRenewal(this, date);
            }
        }

        public virtual Statement CreateStatement(DateTime date)
        {
            var items = new List<Installment>();
            foreach (var transaction in _transactions)
            {
                var installments = transaction.CalculateInstallments((int) _billingPeriod);
                foreach (var installment in installments)
                {
                    if (installment.BillableDate <= date)
                    {
                        items.Add(installment);
                    }
                }
            }
            return new Statement(this, date, items);
        }

        public virtual bool ShouldInvoiceOn(DateTime date)
        {
            return _billingStartDate != null && date >= _billingStartDate &&
                   (_nextInvoiceDate == null || date >= _nextInvoiceDate);
        }

        public virtual decimal BalanceAsOf(DateTime date)
        {
            decimal total = 0;
            foreach (var transaction in _transactions)
            {
                if (transaction.Date <= date)
                {
                    total += transaction.Amount;
                }
            }
            return total;
        }

        public override string ToString()
        {
            return string.Format(ToStringFormat, _name);
        }

        public virtual Iesi.Collections.Generic.ISet<string> SetSecondaryEmailAddresses(
            Iesi.Collections.Generic.ISet<string> value)
        {
            var errors = new HashedSet<string>();
            Iesi.Collections.Generic.ISet<string> actual = new HashedSet<string>();
            foreach (var email in value)
            {
                var clean = email.Trim();
                if (clean.Length == 0)
                {
                    continue;
                }
                try
                {
                    new MailAddress(clean);
                    actual.Add(clean);
                }
                catch (Exception)
                {
                    errors.Add(string.Format(InvalidEmailAddressFormat, clean));
                }
            }
            if (errors.Count == 0)
            {
                _secondaryEmailAddresses = actual;
            }
            return errors;
        }

        public virtual void UpdatePaymentMethod(BillingType billingType, PaymentType paymentType,
                                                IPaymentGateway gateway)
        {
            var newPaymentMethodId = billingType == BillingType.MailPayment
                                         ? (int?) null
                                         : gateway.CreatePaymentMethod(billingType, paymentType);
            if (_paymentMethodId != null)
            {
                gateway.DeletePaymentMethod(_paymentMethodId.Value);
            }
            _paymentMethodId = newPaymentMethodId;
            _billingType = billingType;
        }

        public virtual PaymentType GetPaymentMethod(IPaymentGateway gateway)
        {
            return _paymentMethodId == null ? null : gateway.GetPaymentMethod(_billingType, _paymentMethodId.Value);
        }
    }
}