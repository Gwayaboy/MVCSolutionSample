namespace Intrigma.Firn.DomainModel
{
    public class PaymentType
    {
        private string _accountHolderName;
        private int _creditCardExpirationMonth;
        private int _creditCardExpirationYear;
        private string _creditCardNumber;
        private bool _creditCardProcurement;
        private CreditCardType _creditCardType;
        private string _eftAccountNumber;
        private EftAccountType _eftAccountType;
        private string _eftRoutingNumber;

        public EftAccountType EftAccountType
        {
            get { return _eftAccountType; }
            set { _eftAccountType = value; }
        }

        public string EftRoutingNumber
        {
            get { return _eftRoutingNumber; }
            set { _eftRoutingNumber = value; }
        }

        public string EftAccountNumber
        {
            get { return _eftAccountNumber; }
            set { _eftAccountNumber = value; }
        }

        public bool CreditCardProcurement
        {
            get { return _creditCardProcurement; }
            set { _creditCardProcurement = value; }
        }

        public CreditCardType CreditCardType
        {
            get { return _creditCardType; }
            set { _creditCardType = value; }
        }

        public int CreditCardExpirationYear
        {
            get { return _creditCardExpirationYear; }
            set { _creditCardExpirationYear = value; }
        }

        public int CreditCardExpirationMonth
        {
            get { return _creditCardExpirationMonth; }
            set { _creditCardExpirationMonth = value; }
        }

        public string CreditCardNumber
        {
            get { return _creditCardNumber; }
            set { _creditCardNumber = value; }
        }

        public string AccountHolderName
        {
            get { return _accountHolderName; }
            set { _accountHolderName = value; }
        }
    }
}