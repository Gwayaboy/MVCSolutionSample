using System.ComponentModel;

namespace Intrigma.Firn.DomainModel
{
    public enum CreditCardType
    {
        Visa = 0,
        MasterCard = 1,
        [Description("American Express")]
        AmericanExpress = 2,
    }
}