namespace Intrigma.Firn.DomainModel
{
    public enum BillingPeriod
    {
        Monthly = 1,
        Quarterly = 3,
        Semiannually = 6,
        Yearly = 12,
    }
}