using System;
using System.Collections.Generic;
using NHibernate.Mapping.Attributes;

namespace Intrigma.Firn.DomainModel
{
    [Class(NameType = typeof(BaseTransaction), Table = "AccountTransaction")]
    [Discriminator(Column = "TransactionType", Type = "String", Length = 100, NotNull = true)]
    public class BaseTransaction : IntegerKeyedObject
    {
        [Property(Access = "field", Column = "Amount")]
        private decimal _amount;

        [Property(Access = "field", Column = "TransactionDate")]
        private DateTime _date;

        [Property(Access = "field", Column = "Description")]
        private string _description;

        [Property(Access = "field", Column = "Name")]
        private string _name;

        public BaseTransaction(DateTime date, decimal amount, string name, string description)
        {
            _date = date;
            _amount = amount;
            _name = name;
            _description = description;
        }

        public BaseTransaction() {}

        public virtual DateTime Date
        {
            get { return _date; }
        }

        public virtual decimal Amount
        {
            get { return _amount; }
        }

        public virtual string Description
        {
            get { return _description; }
        }

        public virtual string Name
        {
            get { return _name; }
        }

        public virtual int? StaffCount
        {
            get { return null; }
        }

        public virtual bool ShowOnInvoice
        {
            get { return false; }
        }

        public virtual IList<Installment> CalculateInstallments(int months)
        {
            return new[] {new Installment(_date, _date, _amount, this)};
        }

        public virtual void Update(string name, string description, DateTime date, decimal amount)
        {
            _name = name;
            _description = description;
            _date = date;
            _amount = amount;
        }
    }
}