using System;
using System.Collections.Generic;

namespace Intrigma.Firn.DomainModel
{
    public struct DatePeriod
    {
        private readonly DateTime _end;
        private readonly DateTime _start;

        public DatePeriod(DateTime start, DateTime end)
        {
            _start = start;
            _end = end;
        }

        public DatePeriod(DateTime start, TimeSpan duration) : this(start, start + duration - TimeSpan.FromDays(1)) {}

        public DateTime Start
        {
            get { return _start; }
        }

        public DateTime End
        {
            get { return _end; }
        }

        public IList<DateTime> SplitByMonths(int months)
        {
            var points = new List<DateTime>();
            for (DateTime date = _start; date <= _end; date = date.AddMonths(months))
            {
                points.Add(date);
            }
            return points;
        }
    }
}