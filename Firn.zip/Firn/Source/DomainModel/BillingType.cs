using System.ComponentModel;

namespace Intrigma.Firn.DomainModel
{
    public enum BillingType
    {
        [Description("Mail Payment")]
        MailPayment = 0,
        [Description("Credit Card")]
        [PaymentPhrase("charge {0:c} to your credit card")]
        CreditCard = 1,
        [Description("EFT")]
        [PaymentPhrase("withdraw {0:c} from your bank account")]
        Eft = 2,
    }
}