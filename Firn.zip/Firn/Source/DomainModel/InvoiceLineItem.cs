using System;
using NHibernate.Mapping.Attributes;

namespace Intrigma.Firn.DomainModel
{
    [Class(NameType = typeof(InvoiceLineItem))]
    public class InvoiceLineItem : IntegerKeyedObject
    {
        [Property(Access = "field", Column = "ItemDate", NotNull = true)]
        private readonly DateTime _date;

        [Property(Access = "field", Column = "Description", NotNull = true)]
        private readonly string _description = string.Empty;

        [Property(Access = "field", Column = "Name", NotNull = true)]
        private readonly string _name = string.Empty;

        [Property(Access = "field", Column = "Price", NotNull = true)]
        private readonly decimal _price;

        [Property(Access = "field", Column = "StaffCount")]
        private readonly int? _staffCount;

        public InvoiceLineItem(DateTime date, string name, string description, int? staffCount, decimal price)
        {
            _date = date;
            _name = name;
            _description = description;
            _staffCount = staffCount;
            _price = price;
        }

        public InvoiceLineItem() {}

        public virtual string Name
        {
            get { return _name; }
        }

        public virtual string Description
        {
            get { return _description; }
        }

        public virtual int? StaffCount
        {
            get { return _staffCount; }
        }

        public virtual decimal Price
        {
            get { return _price; }
        }

        public virtual DateTime Date
        {
            get { return _date; }
        }
    }
}