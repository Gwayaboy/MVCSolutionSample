using NHibernate.Mapping.Attributes;

namespace Intrigma.Firn.DomainModel
{
    public class IntegerKeyedObject
    {
        [Id(0, Access = "field", Name = "_id", Column = "Id")]
        [Generator(1, Class = "{{Id.Generator}}")]
        [AttributeIdentifier("Id.Generator", Value = "native")]
        private int _id;

        [Version(Access = "field", Column = "Version")]
        private int _version;

        public IntegerKeyedObject() {}

        public IntegerKeyedObject(int id)
        {
            _id = id;
        }

        public virtual int Id
        {
            get { return _id; }
            set { _id = value; }
        }

        public virtual int Version
        {
            get { return _version; }
            set { _version = value; }
        }
    }
}