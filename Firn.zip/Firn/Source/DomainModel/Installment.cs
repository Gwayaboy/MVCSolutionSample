using System;

namespace Intrigma.Firn.DomainModel
{
    public struct Installment
    {
        public const string ToStringFormat = "Installment [{0:c} due on {1:d}]";
        private readonly decimal _amount;
        private readonly DateTime _billableDate;
        private readonly DateTime _dueDate;
        private readonly BaseTransaction _transaction;

        public Installment(DateTime dueDate, DateTime billableDate, decimal amount, BaseTransaction transaction)
        {
            _dueDate = dueDate;
            _billableDate = billableDate;
            _amount = amount;
            _transaction = transaction;
        }

        public DateTime DueDate
        {
            get { return _dueDate; }
        }

        public decimal Amount
        {
            get { return _amount; }
        }

        public BaseTransaction Transaction
        {
            get { return _transaction; }
        }

        public DateTime BillableDate
        {
            get { return _billableDate; }
        }

        public override string ToString()
        {
            return string.Format(ToStringFormat, _amount, _dueDate);
        }
    }
}