using System;
using System.Collections.Generic;
using NHibernate.Mapping.Attributes;

namespace Intrigma.Firn.DomainModel
{
    [Subclass(ExtendsType = typeof(BaseAccountTransaction), DiscriminatorValue = "Installment",
        NameType = typeof(InstallmentTransaction))]
    public class InstallmentTransaction : BaseAccountTransaction
    {
        public const int DefaultBillableWeeksBefore = 4;

        [Property(Access = "field", Column = "BillableWeeksBefore")]
        private int _billableWeeksBefore;

        [Property(Access = "field", Column = "EndDate")]
        private DateTime _end;

        [Property(Access = "field", Column = "StaffCount")]
        private int _staffCount;

        public InstallmentTransaction(DatePeriod period, decimal amount, string name, string description, int staffCount,
                                      int billableWeeksBefore) : base(period.Start, amount, name, description)
        {
            _staffCount = staffCount;
            _billableWeeksBefore = billableWeeksBefore;
            _end = period.End;
        }

        public InstallmentTransaction() {}

        public virtual DatePeriod Period
        {
            get { return new DatePeriod(Date, _end); }
        }

        public override int? StaffCount
        {
            get { return _staffCount; }
        }

        public override bool ShowOnInvoice
        {
            get { return true; }
        }

        public virtual int BillableWeeksBefore
        {
            get { return _billableWeeksBefore; }
        }

        public override IList<Installment> CalculateInstallments(int months)
        {
            IList<DateTime> dates = Period.SplitByMonths(months);
            IList<Money> amounts = new Money(Amount).SplitIntoParts(dates.Count);
            var result = new List<Installment>();
            TimeSpan billableBefore = TimeSpan.FromDays(7 * _billableWeeksBefore);
            for (int index = 0; index < dates.Count; index++)
            {
                result.Add(new Installment(dates[index], dates[index] - billableBefore, amounts[index].Amount, this));
            }
            return result;
        }

        public virtual void Update(string name, string description, DatePeriod period, decimal amount, int staffCount,
                                   int billableWeeksBefore)
        {
            Update(name, description, period.Start, amount);
            _end = period.End;
            _staffCount = staffCount;
            _billableWeeksBefore = billableWeeksBefore;
        }
    }
}