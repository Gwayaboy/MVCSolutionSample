using System;
using System.Collections.Generic;

namespace Intrigma.Firn.DomainModel
{
    public struct Money
    {
        private readonly decimal _amount;

        public Money(decimal amount)
        {
            _amount = amount;
        }

        public decimal Amount
        {
            get { return _amount; }
        }

        public IList<Money> SplitIntoParts(int parts)
        {
            var result = new Money[parts];
            decimal left = _amount;
            decimal mostParts = Math.Round(_amount / parts, 2);
            for (int part = 0; part < parts - 1; part++)
            {
                result[part] = new Money(mostParts);
                left -= mostParts;
            }
            result[parts - 1] = new Money(left);
            return result;
        }

        public override string ToString()
        {
            return _amount.ToString();
        }

        public string ToString(string format)
        {
            return _amount.ToString(format);
        }
    }
}