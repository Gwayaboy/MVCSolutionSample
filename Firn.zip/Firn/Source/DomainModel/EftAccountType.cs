namespace Intrigma.Firn.DomainModel
{
    public enum EftAccountType
    {
        Checking = 0,
        Savings = 1,
    }
}