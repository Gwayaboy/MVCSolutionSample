using System;
using NHibernate.Mapping.Attributes;

namespace Intrigma.Firn.DomainModel
{
    [Subclass(ExtendsType = typeof(BaseAccountTransaction), DiscriminatorValue = "Charge",
        NameType = typeof(AccountChargeTransaction))]
    public class AccountChargeTransaction : BaseAccountTransaction
    {
        public AccountChargeTransaction(DateTime date, decimal amount, string name, string description)
            : base(date, amount, name, description) {}

        public AccountChargeTransaction() {}

        public override bool ShowOnInvoice
        {
            get { return true; }
        }
    }
}