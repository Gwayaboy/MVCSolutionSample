﻿using System.Reflection;

[assembly: AssemblyTitle("Intrigma Firn Domain Model")]