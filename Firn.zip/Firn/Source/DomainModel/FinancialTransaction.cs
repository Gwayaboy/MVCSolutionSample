using System;
using NHibernate.Mapping.Attributes;

namespace Intrigma.Firn.DomainModel
{
    [Subclass(ExtendsType = typeof(BaseTransaction), NameType = typeof(FinancialTransaction))]
    public class FinancialTransaction : BaseTransaction
    {
        [Property(Access = "field", Column = "BillingType")]
        private readonly BillingType _type;

        public FinancialTransaction(DateTime date, decimal amount, string name, string description, BillingType type)
            : base(date, amount, name, description)
        {
            _type = type;
        }

        public FinancialTransaction() {}

        public virtual BillingType? Type
        {
            get { return _type; }
        }
    }
}