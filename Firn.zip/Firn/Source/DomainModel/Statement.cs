using System;
using System.Collections.Generic;

namespace Intrigma.Firn.DomainModel
{
    public class Statement
    {
        public const decimal MinimumForInvoice = 1;
        public static readonly TimeSpan InvoiceGracePeriod = TimeSpan.FromDays(10);
        private readonly decimal _balance;
        private readonly Customer _customer;
        private readonly DateTime _date;
        private readonly List<Installment> _installments;

        public Statement(Customer customer, DateTime date, IEnumerable<Installment> installments)
        {
            _customer = customer;
            // Sort in descending date order.
            _installments = new List<Installment>(installments);
            _installments.Sort(delegate(Installment a, Installment b) { return b.DueDate.CompareTo(a.DueDate); });
            _date = date;
            _balance = CalculateBalance();
        }

        public Statement() {}

        public IList<Installment> Installments
        {
            get { return _installments; }
        }

        public decimal CurrentBalance
        {
            get { return _balance; }
        }

        public DateTime Date
        {
            get { return _date; }
        }

        public Customer Customer
        {
            get { return _customer; }
        }

        private decimal CalculateBalance()
        {
            decimal total = 0;
            foreach (Installment installment in _installments)
            {
                total += installment.Amount;
            }
            return total;
        }

        public virtual Invoice CreateInvoice(int id)
        {
            if (_balance < MinimumForInvoice)
            {
                // Don't try to collect 2 pennies from the poor little old ladies.
                return null;
            }
            var validInstallments = new List<Installment>();
            foreach (Installment installment in _installments)
            {
                if (installment.Transaction.ShowOnInvoice && installment.Amount > 0)
                {
                    validInstallments.Add(installment);
                }
            }
            if (validInstallments.Count == 0)
            {
                // This would be a very odd case. Perhaps all of the transactions are refunds?
                return null;
            }
            var invoice = new Invoice(_customer, id, _date, _date + InvoiceGracePeriod);
            decimal runningTotal = 0;
            foreach (Installment installment in validInstallments)
            {
                decimal partialAmount = (runningTotal + installment.Amount > _balance
                                             ? _balance - runningTotal
                                             : installment.Amount);
                invoice.AddLineItem(new InvoiceLineItem(installment.DueDate, installment.Transaction.Name,
                                                        installment.Transaction.Description,
                                                        installment.Transaction.StaffCount, partialAmount));
                runningTotal += installment.Amount;
                if (runningTotal >= _balance)
                {
                    break;
                }
            }
            return invoice;
        }
    }
}