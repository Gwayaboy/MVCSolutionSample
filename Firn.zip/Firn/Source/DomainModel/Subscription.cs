using System;
using NHibernate.Mapping.Attributes;

namespace Intrigma.Firn.DomainModel
{
    [Class(NameType = typeof(Subscription))]
    public class Subscription : IntegerKeyedObject
    {
        private const int _renewWeeksInAdvance = 10;
        public static readonly TimeSpan RenewalWindow = TimeSpan.FromDays(_renewWeeksInAdvance * 7);

        [ManyToOne(Access = "field", NotNull = true, Fetch = FetchMode.Join, Column = "TransactionId",
            Cascade = "save-update")]
        private readonly InstallmentTransaction _transaction;

        [Property(Access = "field", Column = "Months")]
        private int _months;

        [Property(Access = "field", Column = "Renewed")]
        private bool _renewed;

        public Subscription() {}

        public Subscription(string name, string description, DateTime startDate, int months, decimal amount,
                            int staffCount, int billableWeeksBefore)
        {
            _transaction = new InstallmentTransaction(
                new DatePeriod(startDate, startDate.AddMonths(months).AddDays(-1)), amount, name, description,
                staffCount, billableWeeksBefore);
            _months = months;
        }

        public virtual InstallmentTransaction Transaction
        {
            get { return _transaction; }
        }

        public virtual int StaffCount
        {
            get { return _transaction.StaffCount.Value; }
        }

        public virtual int Months
        {
            get { return _months; }
        }

        public virtual bool Renewed
        {
            get { return _renewed; }
        }

        public virtual void CheckRenewal(Customer customer, DateTime date)
        {
            if (_renewed || (date < _transaction.Period.End - RenewalWindow))
            {
                return;
            }
            _renewed = true;
            customer.AddSubscription(new Subscription(_transaction.Name, _transaction.Description,
                                                      _transaction.Period.End.AddDays(1), _months, _transaction.Amount,
                                                      _transaction.StaffCount.Value, _transaction.BillableWeeksBefore));
        }

        public virtual void Update(string name, string description, DateTime startDate, int months, decimal amount,
                                   int staffCount, int billableWeeksBefore)
        {
            _months = months;
            _transaction.Update(name, description, new DatePeriod(startDate, startDate.AddMonths(months).AddDays(-1)),
                                amount, staffCount, billableWeeksBefore);
        }
    }
}