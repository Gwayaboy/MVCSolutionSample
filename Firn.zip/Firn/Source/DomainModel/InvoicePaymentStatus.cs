using System.ComponentModel;

namespace Intrigma.Firn.DomainModel
{
    public enum InvoicePaymentStatus
    {
        Pending,
        Paid,
        [Description("Payment Failed")]
        PaymentFailed,
        Canceled
    }
}