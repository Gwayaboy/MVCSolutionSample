using System;
using NHibernate.Mapping.Attributes;

namespace Intrigma.Firn.DomainModel
{
    [Subclass(ExtendsType = typeof(FinancialTransaction), DiscriminatorValue = "Refund",
        NameType = typeof(RefundTransaction))]
    public class RefundTransaction : FinancialTransaction
    {
        public const string DefaultName = "Refund";

        public RefundTransaction(DateTime date, decimal amount, string reason, BillingType type)
            : base(date, amount, DefaultName, reason, type) {}

        public RefundTransaction() {}
    }
}