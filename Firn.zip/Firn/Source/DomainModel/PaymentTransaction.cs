using System;
using NHibernate.Mapping.Attributes;

namespace Intrigma.Firn.DomainModel
{
    [Subclass(ExtendsType = typeof(FinancialTransaction), DiscriminatorValue = "Payment",
        NameType = typeof(PaymentTransaction))]
    public class PaymentTransaction : FinancialTransaction
    {
        public const string DefaultDescription = "Payment";

        public PaymentTransaction(DateTime date, decimal amount, BillingType type)
            : base(date, -amount, string.Empty, DefaultDescription, type) {}

        public PaymentTransaction() {}
    }
}