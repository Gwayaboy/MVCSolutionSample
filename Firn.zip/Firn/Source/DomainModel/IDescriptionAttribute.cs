namespace Intrigma.Firn.DomainModel
{
    public interface IDescriptionAttribute
    {
        string Text { get; }
    }
}