using System;
using System.Collections.Generic;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Data
{
    public interface IInvoiceRepository : IRepository<Invoice>
    {
        int LastInvoice();
        IList<Invoice> ListPayableInvoices(DateTime date);
    }
}