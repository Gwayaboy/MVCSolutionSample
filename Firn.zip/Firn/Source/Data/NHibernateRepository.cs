using Castle.Facilities.NHibernateIntegration;
using NHibernate;

namespace Intrigma.Firn.Data
{
    public class NHibernateRepository<T> : IRepository<T>
    {
        private readonly ISessionManager _sessionManager;

        public NHibernateRepository(ISessionManager sessionManager)
        {
            _sessionManager = sessionManager;
        }

        protected ISessionManager SessionManager
        {
            get { return _sessionManager; }
        }

        #region IRepository<T> Members

        public T GetById(int id)
        {
            ISession session = _sessionManager.OpenSession();
            return session.Get<T>(id);
        }

        public void Save(T obj)
        {
            ISession session = _sessionManager.OpenSession();
            session.SaveOrUpdate(obj);
        }

        #endregion
    }
}