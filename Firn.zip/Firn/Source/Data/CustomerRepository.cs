using System.Collections.Generic;
using Castle.Facilities.NHibernateIntegration;
using Intrigma.Firn.DomainModel;
using NHibernate;

namespace Intrigma.Firn.Data
{
    public class CustomerRepository : NHibernateRepository<Customer>, ICustomerRepository
    {
        public CustomerRepository(ISessionManager sessionManager) : base(sessionManager) {}

        #region ICustomerRepository Members

        public IList<Customer> ListByName()
        {
            ISession session = SessionManager.OpenSession();
            IQuery query = session.CreateQuery("SELECT c FROM Customer c ORDER BY c.Name");
            return query.List<Customer>();
        }

        #endregion
    }
}