using System.Collections.Generic;
using Intrigma.DatabaseVersion.Core;
using Intrigma.Firn.Data.Properties;
using Intrigma.Firn.DomainModel;
using NHibernate;
using NHibernate.Cfg;
using NHibernate.Mapping.Attributes;

namespace Intrigma.Firn.Data
{
    public static class DatabaseHelper
    {
        public const string TestDatabase = "Server=(local);Initial Catalog=FirnTest;Integrated Security=True";

        public static string ConnectionString { get; set; }

        public static ISessionFactory BuildSessionFactory(bool isTest)
        {
            return BuildConfiguration(isTest).BuildSessionFactory();
        }

        public static void UpgradeDatabase()
        {
            BuildDatabaseVersionEngine(false).Upgrade(false);
        }

        public static DatabaseVersionEngine BuildDatabaseVersionEngine(bool isTest)
        {
            var connection = new SqlServerConnection(GetConnectionString(isTest));
            var assembly = typeof(Resources).Assembly;
            var resourceBaseName = typeof(Resources).FullName;
            IVersionRepository versionRepository = new ResourceVersionRepository(assembly, resourceBaseName);
            IBaseRepository baseRepository = new ResourceBaseRepository(assembly, resourceBaseName);
            return new DatabaseVersionEngine(new DatabaseMetadataSource(connection), versionRepository, baseRepository,
                                             connection);
        }

        public static Configuration BuildConfiguration(bool isTest)
        {
            var cfg = new Configuration();
            var props = new Dictionary<string, string>();
            props["cache.provider_class"] = "NHibernate.Cache.HashtableCacheProvider, NHibernate";
            props["batch_size"] = "25";
            props["cache.use_query_cache"] = "true";
            props["connection.isolation"] = "ReadCommitted";
            props["dialect"] = "NHibernate.Dialect.MsSql2005Dialect";
            props["connection.driver_class"] = "NHibernate.Driver.SqlClientDriver";
            props["connection.connection_string"] = GetConnectionString(isTest);
            props["query.substitutions"] = "true 1, false 0, yes 'Y', no 'N'";
            props["proxyfactory.factory_class"] =
                "NHibernate.ByteCode.Castle.ProxyFactoryFactory, NHibernate.ByteCode.Castle";

            cfg.AddProperties(props);

            var serializer = HbmSerializer.Default;
            serializer.HbmSchema = "dbo";
            serializer.Validate = true;
            cfg.AddInputStream(serializer.Serialize(typeof(Customer).Assembly));

            return cfg;
        }

        private static string GetConnectionString(bool isTest)
        {
            return isTest ? TestDatabase : ConnectionString;
        }
    }
}