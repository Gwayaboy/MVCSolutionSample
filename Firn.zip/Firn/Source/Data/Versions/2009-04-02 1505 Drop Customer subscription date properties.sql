ALTER TABLE Customer
	DROP COLUMN SubscriptionStartDate
GO
ALTER TABLE Customer
	DROP COLUMN SubscriptionEndDate
GO