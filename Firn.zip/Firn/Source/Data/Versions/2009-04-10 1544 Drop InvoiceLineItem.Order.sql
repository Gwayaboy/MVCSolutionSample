ALTER TABLE InvoiceLineItem
	DROP COLUMN [Order]