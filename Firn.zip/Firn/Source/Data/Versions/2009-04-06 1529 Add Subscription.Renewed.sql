ALTER TABLE Subscription
	ADD Renewed BIT NOT NULL CONSTRAINT DF_Subscription_Renewed DEFAULT 0
GO
ALTER TABLE Subscription
	DROP CONSTRAINT DF_Subscription_Renewed
GO