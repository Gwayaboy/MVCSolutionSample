ALTER TABLE Customer
	ADD BillingType INT NOT NULL CONSTRAINT DF_Customer_BillingType DEFAULT 0
GO
ALTER TABLE Customer
	DROP CONSTRAINT DF_Customer_BillingType
GO