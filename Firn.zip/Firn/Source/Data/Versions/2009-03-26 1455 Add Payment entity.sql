CREATE TABLE dbo.Payment (
	Id INT IDENTITY NOT NULL,
	Version INT NOT NULL,
	PaymentDate DATETIME NOT NULL,
	PaymentType INT NOT NULL,
	Amount DECIMAL(12, 2) NOT NULL,
	CustomerId INT NULL,
	CONSTRAINT PK_Payment PRIMARY KEY (Id),
	CONSTRAINT FK_Payment_Customer FOREIGN KEY (CustomerId) REFERENCES Customer
)