ALTER TABLE Invoice
	ADD Total DECIMAL(12, 2) NULL
GO
UPDATE Invoice SET Total = 
	(SELECT COALESCE(SUM(Price), 0) FROM InvoiceLineItem WHERE InvoiceLineItem.InvoiceId = Invoice.Id)
GO
ALTER TABLE Invoice
	ALTER COLUMN Total DECIMAL(12, 2) NOT NULL
GO