CREATE TABLE dbo.Subscription (
	Id INT IDENTITY NOT NULL,
	Version INT NOT NULL,
	TransactionId INT NOT NULL,
	CustomerId INT NULL,
	CONSTRAINT PK_Subscription PRIMARY KEY (Id),
	CONSTRAINT FK_Subscription_AccountTransaction FOREIGN KEY (TransactionId) REFERENCES AccountTransaction,
	CONSTRAINT FK_Subscription_Customer FOREIGN KEY (CustomerId) REFERENCES Customer
)