ALTER TABLE Customer
	ADD PaymentMethodId INT NULL
GO

-- No one has any payment methods by default, so billing type = manual.
UPDATE Customer
	SET BillingType = 0
GO