EXEC sp_rename 'Customer.Attn', 'AttnLastName'
GO
ALTER TABLE Customer ADD
	AttnFirstName NVARCHAR(150) NOT NULL CONSTRAINT DF_Customer_AttnFirstName DEFAULT N'',
	Phone NVARCHAR(100) NOT NULL CONSTRAINT DF_Customer_Phone DEFAULT N''
GO
ALTER TABLE Customer
	DROP CONSTRAINT DF_Customer_AttnFirstName
GO
ALTER TABLE Customer
	DROP CONSTRAINT DF_Customer_Phone
GO