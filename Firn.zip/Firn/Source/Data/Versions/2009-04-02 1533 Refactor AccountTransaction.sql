EXEC sp_rename 'AccountTransaction.PaymentDate', 'TransactionDate'
GO
EXEC sp_rename 'AccountTransaction.PaymentType', 'BillingType'
GO
ALTER TABLE AccountTransaction
	ALTER COLUMN BillingType INT NULL
GO
ALTER TABLE AccountTransaction ADD
	Name NVARCHAR(100) NOT NULL CONSTRAINT DF_AccountTransaction_Name DEFAULT N''
GO
ALTER TABLE AccountTransaction
	DROP CONSTRAINT DF_AccountTransaction_Name
GO
UPDATE AccountTransaction SET TransactionType = CASE WHEN Amount > 0 THEN 'Charge' ELSE 'Payment' END
GO