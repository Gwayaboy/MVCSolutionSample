ALTER TABLE AccountTransaction ADD
	TransactionType NVARCHAR(100) NOT NULL CONSTRAINT DF_AccountTransaction_TransactionType DEFAULT N'AccountTransaction',
	EndDate DATETIME NULL
GO
ALTER TABLE AccountTransaction
	DROP CONSTRAINT DF_AccountTransaction_TransactionType
GO