ALTER TABLE Customer ADD
	BillingStartDate DATETIME NULL,
	SubscriptionStartDate DATETIME NULL,
	SubscriptionEndDate DATETIME NULL,
	BillingPeriod INT NOT NULL CONSTRAINT DF_Customer_BillingPeriod DEFAULT 12
GO
ALTER TABLE Customer
	DROP CONSTRAINT DF_Customer_BillingPeriod
GO