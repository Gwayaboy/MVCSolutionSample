CREATE TABLE dbo.CustomerSecondaryEmailAddress (
	CustomerId INT NOT NULL,
	EmailAddress NVARCHAR(200) NOT NULL,
	CONSTRAINT PK_CustomerSecondaryEmailAddress PRIMARY KEY (CustomerId, EmailAddress),
	CONSTRAINT FK_CustomerSecondaryEmailAddress_Customer FOREIGN KEY (CustomerId) REFERENCES Customer
)