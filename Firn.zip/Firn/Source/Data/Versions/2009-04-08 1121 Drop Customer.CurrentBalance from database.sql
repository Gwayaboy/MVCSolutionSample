ALTER TABLE Customer
	DROP COLUMN CurrentBalance