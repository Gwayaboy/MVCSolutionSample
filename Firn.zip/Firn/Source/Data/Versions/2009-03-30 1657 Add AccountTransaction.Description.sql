ALTER TABLE AccountTransaction
	ADD Description NVARCHAR(200) NOT NULL CONSTRAINT DF_AccountTransaction_Description DEFAULT N'Payment'
GO
ALTER TABLE AccountTransaction
	DROP CONSTRAINT DF_AccountTransaction_Description
GO