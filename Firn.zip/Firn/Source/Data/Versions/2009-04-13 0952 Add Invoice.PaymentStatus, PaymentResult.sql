ALTER TABLE Invoice ADD
	PaymentStatus INT NULL,
	PaymentResult NTEXT NULL
GO
UPDATE Invoice SET PaymentStatus = CASE WHEN DueDate >= GETDATE() THEN 0 ELSE 1 END
GO
ALTER TABLE Invoice
	ALTER COLUMN PaymentStatus INT NOT NULL
GO