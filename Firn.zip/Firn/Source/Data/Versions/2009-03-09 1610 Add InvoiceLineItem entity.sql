CREATE TABLE dbo.InvoiceLineItem (
	Id INT IDENTITY NOT NULL,
	Version INT NOT NULL,
	Name NVARCHAR(100) NOT NULL,
	[Order] INT NOT NULL,
	Description NTEXT NOT NULL,
	StaffCount INT NOT NULL,
	Price DECIMAL(12, 2) NOT NULL,
	InvoiceId INT NULL,
	CONSTRAINT PK_InvoiceLineItem PRIMARY KEY (Id),
	CONSTRAINT FK_InvoiceLineItem_Invoice FOREIGN KEY (InvoiceId) REFERENCES Invoice
)