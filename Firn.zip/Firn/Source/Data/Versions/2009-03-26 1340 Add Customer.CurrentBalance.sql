ALTER TABLE Customer
	ADD CurrentBalance DECIMAL(12, 2) NOT NULL CONSTRAINT DF_Customer_CurrentBalance DEFAULT 0
GO
ALTER TABLE Customer
	DROP CONSTRAINT DF_Customer_CurrentBalance
GO