ALTER TABLE AccountTransaction
	ADD StaffCount INT NULL
GO
UPDATE AccountTransaction SET 
	StaffCount = (SELECT StaffCount FROM Subscription WHERE Subscription.TransactionId = AccountTransaction.Id)
GO
ALTER TABLE Subscription
	DROP COLUMN StaffCount
GO