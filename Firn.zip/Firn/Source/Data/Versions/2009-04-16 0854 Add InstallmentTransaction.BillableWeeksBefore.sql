ALTER TABLE AccountTransaction
	ADD BillableWeeksBefore INT NULL
GO
UPDATE AccountTransaction
	SET BillableWeeksBefore = 4
	WHERE TransactionType = 'Installment'
GO