ALTER TABLE Subscription
	ADD StaffCount INT NOT NULL CONSTRAINT DF_Subscription_StaffCount DEFAULT 0
GO
ALTER TABLE Subscription
	DROP CONSTRAINT DF_Subscription_StaffCount
GO