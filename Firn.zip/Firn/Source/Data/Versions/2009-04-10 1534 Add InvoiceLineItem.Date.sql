ALTER TABLE InvoiceLineItem
	ADD ItemDate DATETIME NULL
GO
UPDATE InvoiceLineItem SET ItemDate = (SELECT InvoiceDate FROM Invoice WHERE Invoice.Id = InvoiceLineItem.InvoiceId)
GO
ALTER TABLE InvoiceLineItem
	ALTER COLUMN ItemDate DATETIME NOT NULL
GO