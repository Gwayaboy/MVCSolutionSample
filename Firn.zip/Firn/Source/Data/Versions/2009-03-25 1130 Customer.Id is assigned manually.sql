CREATE TABLE dbo.TempCustomer (
	Id int NOT NULL,
	Version int NOT NULL,
	Attn nvarchar(150) NOT NULL,
	Name nvarchar(200) NOT NULL,
	StreetAddress1 nvarchar(200) NOT NULL,
	StreetAddress2 nvarchar(200) NOT NULL,
	City nvarchar(100) NOT NULL,
	State nvarchar(100) NOT NULL,
	Zip nvarchar(20) NOT NULL,
	EmailAddress nvarchar(100) NOT NULL,
	ClientId int NOT NULL,
	BillingType int NOT NULL,
	PaymentMethodId int NULL
)
GO
IF EXISTS (SELECT * FROM Customer)
	 INSERT INTO TempCustomer (Id, Version, Attn, Name, StreetAddress1, StreetAddress2, City, State, Zip, EmailAddress, ClientId, BillingType, PaymentMethodId)
		SELECT Id, Version, Attn, Name, StreetAddress1, StreetAddress2, City, State, Zip, EmailAddress, ClientId, BillingType, PaymentMethodId FROM Customer
GO
ALTER TABLE Invoice
	DROP CONSTRAINT FK_Invoice_Customer
GO
DROP TABLE Customer
GO
EXECUTE sp_rename N'TempCustomer', N'Customer'
GO
ALTER TABLE Customer ADD CONSTRAINT PK_Customer PRIMARY KEY (Id)
GO
ALTER TABLE Invoice ADD CONSTRAINT FK_Invoice_Customer FOREIGN KEY (CustomerId) REFERENCES Customer
GO
