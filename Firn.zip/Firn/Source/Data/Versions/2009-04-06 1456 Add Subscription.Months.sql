ALTER TABLE Subscription
	ADD Months INT NOT NULL CONSTRAINT DF_Subscription_Months DEFAULT 12
GO
ALTER TABLE Subscription
	DROP CONSTRAINT DF_Subscription_Months
GO