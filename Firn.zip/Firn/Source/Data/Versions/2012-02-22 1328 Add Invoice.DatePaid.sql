﻿ALTER TABLE Invoice ADD DatePaid DATETIME NULL
GO
UPDATE Invoice SET DatePaid = DueDate WHERE PaymentStatus = 1 -- Paid
GO