namespace Intrigma.Firn.Data
{
    public interface IRepository<T>
    {
        T GetById(int id);
        void Save(T obj);
    }
}