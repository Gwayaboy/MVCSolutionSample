using System.Collections.Generic;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Data
{
    public interface ICustomerRepository : IRepository<Customer>
    {
        IList<Customer> ListByName();
    }
}