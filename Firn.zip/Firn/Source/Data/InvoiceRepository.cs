using System;
using System.Collections.Generic;
using Castle.Facilities.NHibernateIntegration;
using Intrigma.Firn.DomainModel;
using NHibernate;

namespace Intrigma.Firn.Data
{
    public class InvoiceRepository : NHibernateRepository<Invoice>, IInvoiceRepository
    {
        public InvoiceRepository(ISessionManager sessionManager) : base(sessionManager) {}

        #region IInvoiceRepository Members

        public int LastInvoice()
        {
            ISession session = SessionManager.OpenSession();
            IQuery query = session.CreateQuery(@"SELECT MAX(i._id) FROM Invoice i");
            object result = query.UniqueResult();
            return (result == null) ? 0 : (int) result;
        }

        public IList<Invoice> ListPayableInvoices(DateTime date)
        {
            ISession session = SessionManager.OpenSession();
            IQuery query =
                session.CreateQuery(
                    @"SELECT i FROM Invoice i WHERE 
i._paymentStatus = :paymentStatus AND i._dueDate <= :date AND i._customer.BillingType != :billingType");
            query.SetEnum("paymentStatus", InvoicePaymentStatus.Pending);
            query.SetDateTime("date", date);
            query.SetEnum("billingType", BillingType.MailPayment);
            return query.List<Invoice>();
        }

        #endregion
    }
}