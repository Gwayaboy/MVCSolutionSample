using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.PaymentGateway;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;

namespace Intrigma.Firn.Core.Tests
{
    [TestFixture]
    public class StubPaymentGatewayTests : MockTestFixture
    {
        #region Setup/Teardown

        public override void SetUp()
        {
            base.SetUp();
            _inner = DynamicMock<IPaymentGateway>();
            _target = new StubPaymentGateway();
        }

        #endregion

        private StubPaymentGateway _target;
        private IPaymentGateway _inner;

        [Test]
        public void CreateReturnsBillingType()
        {
            var billingType = Create.NonDefaultBillingType();
            ReplayAll();

            Assert.That(_target.CreatePaymentMethod(billingType, new PaymentType()), Is.EqualTo((int) billingType));
        }

        [Test]
        public void DeleteDoesNothing()
        {
            ReplayAll();

            _target.DeletePaymentMethod(5);
        }

        [Test]
        public void FailedPaymentSinceEftTransaction()
        {
            ReplayAll();
            var customer = new Customer();
            customer.BillingType = BillingType.Eft;
            decimal amount = 234;
            Assert.That(_target.MakePayment(customer, amount),
                        Is.EqualTo(
                            new PaymentResult(string.Format(StubPaymentGateway.PaymentFailureFormat, customer, amount),
                                              false)));
        }

        [Test]
        public void FailedRefundSinceEftTransaction()
        {
            ReplayAll();
            var customer = new Customer();
            customer.BillingType = BillingType.Eft;
            decimal amount = 234;
            Assert.That(_target.IssueRefund(customer, amount),
                        Is.EqualTo(
                            new PaymentResult(string.Format(StubPaymentGateway.RefundFailureFormat, customer, amount),
                                              false)));
        }

        [Test]
        public void GetCreditCardReturnsSomethingWithACreditCardNumber()
        {
            ReplayAll();

            Assert.That(_target.GetPaymentMethod(BillingType.CreditCard, 0).CreditCardNumber, Is.Not.Empty);
        }

        [Test]
        public void GetEftReturnsSomethingWithAnAccountNumber()
        {
            ReplayAll();

            Assert.That(_target.GetPaymentMethod(BillingType.Eft, 0).EftAccountNumber, Is.Not.Empty);
        }

        [Test]
        public void SuccessfulPayment()
        {
            ReplayAll();
            var customer = new Customer();
            customer.BillingType = BillingType.CreditCard;
            decimal amount = 234;
            Assert.That(_target.MakePayment(customer, amount),
                        Is.EqualTo(
                            new PaymentResult(string.Format(StubPaymentGateway.PaymentSuccessFormat, customer, amount),
                                              true)));
        }

        [Test]
        public void SuccessfulRefund()
        {
            ReplayAll();
            var customer = new Customer();
            customer.BillingType = BillingType.CreditCard;
            decimal amount = 234;
            Assert.That(_target.IssueRefund(customer, amount),
                        Is.EqualTo(
                            new PaymentResult(string.Format(StubPaymentGateway.RefundSuccessFormat, customer, amount),
                                              true)));
        }
    }
}