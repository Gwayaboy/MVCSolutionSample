using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Core.Tests
{
    [TestFixture]
    public class NextInvoiceNumberTests : MockTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _invoices = DynamicMock<IInvoiceRepository>();
            _target = new NextInvoiceNumber(_invoices);
        }

        private NextInvoiceNumber _target;
        private IInvoiceRepository _invoices;

        [Test]
        public void NoPreviousInvoices()
        {
            SetupResult.For(_invoices.LastInvoice()).Return(0);
            ReplayAll();

            Assert.That(_target.Next, Is.EqualTo(1));
        }

        [Test]
        public void ThereAreABunchOfPreviousInvoices()
        {
            const int lastInvoice = 2135;
            SetupResult.For(_invoices.LastInvoice()).Return(lastInvoice);
            ReplayAll();

            Assert.That(_target.Next, Is.EqualTo(lastInvoice + 1));
        }
    }
}