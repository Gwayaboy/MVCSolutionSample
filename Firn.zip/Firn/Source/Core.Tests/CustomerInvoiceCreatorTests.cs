using System;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Core.Tests
{
    [TestFixture]
    public class CustomerInvoiceCreatorTests : MockTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _invoiceRepository = DynamicMock<IInvoiceRepository>();
            _idFetcher = DynamicMock<INextInvoiceNumber>();
            _target = new CustomerInvoiceCreator(_idFetcher, _invoiceRepository);
        }

        private CustomerInvoiceCreator _target;
        private IInvoiceRepository _invoiceRepository;
        private INextInvoiceNumber _idFetcher;

        [Test]
        public void NoInvoiceToSave()
        {
            var customer = DynamicMock<Customer>();
            DateTime date = Create.AnyDate();
            var statement = DynamicMock<Statement>();
            SetupResult.For(customer.CreateStatement(date)).Return(statement);
            const int id = 245;
            SetupResult.For(_idFetcher.Next).Return(id);
            SetupResult.For(statement.CreateInvoice(id)).Return(null);
            DoNotExpect.Call(() => _invoiceRepository.Save(null));
            ReplayAll();

            _target.CreateFor(customer, date);
        }

        [Test]
        public void ReturnInvoice()
        {
            var customer = DynamicMock<Customer>();
            DateTime date = Create.AnyDate();
            var statement = DynamicMock<Statement>();
            SetupResult.For(customer.CreateStatement(date)).Return(statement);
            var invoice = new Invoice();
            const int id = 245;
            SetupResult.For(_idFetcher.Next).Return(id);
            SetupResult.For(statement.CreateInvoice(id)).Return(invoice);
            ReplayAll();

            Assert.That(_target.CreateFor(customer, date), Is.SameAs(invoice));
        }

        [Test]
        public void SaveInvoice()
        {
            var customer = DynamicMock<Customer>();
            DateTime date = Create.AnyDate();
            var statement = DynamicMock<Statement>();
            SetupResult.For(customer.CreateStatement(date)).Return(statement);
            var invoice = new Invoice();
            const int id = 245;
            SetupResult.For(_idFetcher.Next).Return(id);
            SetupResult.For(statement.CreateInvoice(id)).Return(invoice);
            _invoiceRepository.Save(invoice);
            ReplayAll();

            _target.CreateFor(customer, date);
        }
    }
}