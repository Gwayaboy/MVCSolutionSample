using System;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.PaymentGateway;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Core.Tests
{
    [TestFixture]
    public class PaymentManagerTests : MockTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _currentDate = DynamicMock<ICurrentDateFetcher>();
            _repository = DynamicMock<IRepository<Customer>>();
            _gateway = DynamicMock<IPaymentGateway>();
            _target = new PaymentManager(_currentDate, _repository, _gateway);
            _paymentResult = DynamicMock<IPaymentResult>();
            _customer = DynamicMock<Customer>();
        }

        private PaymentManager _target;
        private ICurrentDateFetcher _currentDate;
        private IPaymentResult _paymentResult;
        private IRepository<Customer> _repository;
        private Customer _customer;
        private IPaymentGateway _gateway;

        [Test]
        public void IssueRefundReturnsTheResults()
        {
            decimal amount = 345;
            DateTime date = Create.AnyDate();
            string reason = Create.AnyString();
            SetupResult.For(_currentDate.Now).Return(date);
            SetupResult.For(_customer.IssueRefund(date, amount, reason, _gateway)).Return(_paymentResult);
            ReplayAll();

            Assert.That(_target.IssueRefund(_customer, amount, reason), Is.SameAs(_paymentResult));
        }

        [Test]
        public void IssueRefundSavesTheCustomer()
        {
            decimal amount = 345;
            DateTime date = Create.AnyDate();
            SetupResult.For(_currentDate.Now).Return(date);
            SetupResult.For(_customer.IssueRefund(date, amount, null, _gateway)).Return(_paymentResult);
            _repository.Save(_customer);
            ReplayAll();

            _target.IssueRefund(_customer, amount, null);
        }

        [Test]
        public void MakePaymentReturnsTheResults()
        {
            decimal amount = 345;
            DateTime date = Create.AnyDate();
            SetupResult.For(_currentDate.Now).Return(date);
            var invoice = DynamicMock<Invoice>();
            SetupResult.For(invoice.Pay(date, amount, _gateway)).Return(_paymentResult);
            ReplayAll();

            Assert.That(_target.MakePayment(invoice, amount), Is.SameAs(_paymentResult));
        }

        [Test]
        public void MakePaymentSavesTheCustomer()
        {
            decimal amount = 345;
            DateTime date = Create.AnyDate();
            SetupResult.For(_currentDate.Now).Return(date);
            SetupResult.For(_customer.MakePayment(date, amount, _gateway)).Return(_paymentResult);
            _repository.Save(_customer);
            ReplayAll();

            Invoice invoice = Create.InvoiceForCustomer(_customer);
            _target.MakePayment(invoice, amount);
        }
    }
}