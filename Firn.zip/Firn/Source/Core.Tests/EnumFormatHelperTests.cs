using Castle.Core;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;

namespace Intrigma.Firn.Core.Tests
{
    [TestFixture]
    public class EnumFormatHelperTests : MockTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _target = new EnumFormatHelper();
        }

        private EnumFormatHelper _target;

        private const string _bDesc = "b description";
        private const string _cPhrase = "c phrase";

        private enum TestEnum
        {
            A,
            [System.ComponentModel.Description(_bDesc)]
            B,
            [PaymentPhrase(_cPhrase)]
            C
        }

        [Test]
        public void EnumToPairs()
        {
            Assert.That(_target.EnumToPairs(typeof(TestEnum)),
                        Is.EqualTo(new[]
                                       {
                                           new Pair<int, string>((int) TestEnum.A, TestEnum.A.ToString()),
                                           new Pair<int, string>((int) TestEnum.B, _bDesc),
                                           new Pair<int, string>((int) TestEnum.C, TestEnum.C.ToString()),
                                       }));
        }

        [Test]
        public void EnumToPairsButExcludeTwo()
        {
            Assert.That(_target.EnumToPairs(typeof(TestEnum), new object[] {TestEnum.A, TestEnum.C}),
                        Is.EqualTo(new[] {new Pair<int, string>((int) TestEnum.B, _bDesc),}));
        }

        [Test]
        public void GetAttributeText()
        {
            Assert.That(_target.GetAttributeText<PaymentPhraseAttribute>(TestEnum.C), Is.EqualTo(_cPhrase));
        }

        [Test]
        public void GetAttributeTextReturnsNullWhenAttributeDoesNotExist()
        {
            Assert.That(_target.GetAttributeText<PaymentPhraseAttribute>(TestEnum.B), Is.Null);
        }

        [Test]
        public void GetDefaultDescription()
        {
            Assert.That(_target.GetDescription(TestEnum.A), Is.EqualTo(TestEnum.A.ToString()));
        }

        [Test]
        public void GetDescription()
        {
            Assert.That(_target.GetDescription(TestEnum.B), Is.EqualTo(_bDesc));
        }
    }
}