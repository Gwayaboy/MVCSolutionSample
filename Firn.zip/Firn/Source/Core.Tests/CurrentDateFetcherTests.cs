using System;
using NUnit.Framework;

namespace Intrigma.Firn.Core.Tests
{
    [TestFixture]
    public class CurrentDateFetcherTests
    {
        [Test]
        public void Now()
        {
            var target = new CurrentDateFetcher();
            DateTime before = DateTime.Now;
            DateTime after = target.Now;
            Assert.That(after - before, Is.LessThan(TimeSpan.FromSeconds(1)));
        }
    }
}