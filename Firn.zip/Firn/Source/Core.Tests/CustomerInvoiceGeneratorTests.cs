using Intrigma.Firn.Core.InvoiceReport;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Core.Tests
{
    [TestFixture]
    public class CustomerInvoiceGeneratorTests : MockTestFixture
    {
        #region Setup/Teardown

        public override void SetUp()
        {
            base.SetUp();
            _mailer = DynamicMock<IInvoiceMailer>();
            _creator = DynamicMock<ICustomerInvoiceCreator>();
            _target = new CustomerInvoiceGenerator(_mailer, _creator);
        }

        #endregion

        private CustomerInvoiceGenerator _target;
        private IInvoiceMailer _mailer;
        private ICustomerInvoiceCreator _creator;

        [Test]
        public void DoNotTryToSendMailIfNoInvoiceIsGenerated()
        {
            var customer = new Customer();
            var date = Create.AnyDate();
            SetupResult.For(_creator.CreateFor(customer, date)).Return(null);
            DoNotExpect.Call(_mailer.Mail(null));
            ReplayAll();

            _target.GenerateInvoice(customer, date);
        }

        [Test]
        public void MailInvoice()
        {
            var customer = new Customer();
            var date = Create.AnyDate();
            var invoice = new Invoice();
            SetupResult.For(_creator.CreateFor(customer, date)).Return(invoice);
            Expect.Call(_mailer.Mail(invoice)).Return(Create.AnyString());
            ReplayAll();

            _target.GenerateInvoice(customer, date);
        }

        [Test]
        public void ReturnInvoice()
        {
            var customer = new Customer();
            var date = Create.AnyDate();
            var invoice = new Invoice();
            SetupResult.For(_creator.CreateFor(customer, date)).Return(invoice);
            ReplayAll();

            Assert.That(_target.GenerateInvoice(customer, date), Is.SameAs(invoice));
        }
    }
}