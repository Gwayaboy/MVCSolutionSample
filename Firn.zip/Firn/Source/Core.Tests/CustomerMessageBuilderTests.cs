using System.Net.Mail;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;

namespace Intrigma.Firn.Core.Tests
{
    [TestFixture]
    public class CustomerMessageBuilderTests : MockTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _target = new CustomerMessageBuilder();
        }

        private CustomerMessageBuilder _target;

        [Test]
        public void SetFromAddress()
        {
            Customer customer = Create.CustomerWithEmailAddress();
            MailMessage message = _target.Build(customer);
            Assert.That(message.From, Is.EqualTo(ProductNameConstants.FromAddress));
        }

        [Test]
        public void SetToAddress()
        {
            var customer = new Customer();
            customer.AttnFirstName = Create.AnyString();
            customer.AttnLastName = Create.AnyString();
            customer.EmailAddress = Create.AnyEmailAddress();
            MailMessage message = _target.Build(customer);
            Assert.That(message.To, Is.EqualTo(new[] {new MailAddress(customer.EmailAddress, customer.AttnFullName),}));
        }

        [Test]
        public void SetTwoCcAddresses()
        {
            Customer customer = Create.CustomerWithEmailAddress();
            string[] emails = {Create.UniqueEmailAddress(), Create.UniqueEmailAddress()};
            customer.SetSecondaryEmailAddresses(Create.Set(emails));
            MailMessage message = _target.Build(customer);
            Assert.That(message.CC, Is.EquivalentTo(new[] {new MailAddress(emails[0]), new MailAddress(emails[1]),}));
        }
    }
}