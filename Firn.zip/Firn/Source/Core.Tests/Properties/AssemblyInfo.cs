﻿using System.Reflection;

[assembly: AssemblyTitle("Intrigma Firn Core Tests")]