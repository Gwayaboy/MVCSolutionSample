using System.Net.Mail;
using Intrigma.Firn.Core.Mail;
using NUnit.Framework;

namespace Intrigma.Firn.Core.Tests.Mail
{
    [TestFixture]
    public class RemoveOutsideAddressesFilterTests
    {
        [SetUp]
        public void SetUp()
        {
            _target = new RemoveOutsideAddressesFilter();
        }

        private RemoveOutsideAddressesFilter _target;

        [Test]
        public void ProcessRemovesAllRecipientsTest()
        {
            var msg = new MailMessage();
            msg.To.Add(new MailAddress("notyou@example.com", "No One"));

            Assert.That(_target.Process(msg), Is.False);
        }

        [Test]
        public void RemoveBccAddress()
        {
            var msg = new MailMessage();
            var okAddress = new MailAddress("foo" + RemoveOutsideAddressesFilter.AcceptableAddressSuffix, "Foo");
            msg.Bcc.Add(new MailAddress("notyou@example.com", "No One"));
            msg.Bcc.Add(okAddress);

            _target.Process(msg);
            Assert.That(msg.Bcc, Is.EqualTo(new[] {okAddress}));
        }

        [Test]
        public void RemoveCcAddress()
        {
            var msg = new MailMessage();
            var okAddress = new MailAddress("foo" + RemoveOutsideAddressesFilter.AcceptableAddressSuffix, "Foo");
            msg.CC.Add(new MailAddress("notyou@example.com", "No One"));
            msg.CC.Add(okAddress);

            _target.Process(msg);
            Assert.That(msg.CC, Is.EqualTo(new[] {okAddress}));
        }

        [Test]
        public void RemoveToAddress()
        {
            var msg = new MailMessage();
            var okAddress = new MailAddress("foo" + RemoveOutsideAddressesFilter.AcceptableAddressSuffix, "Foo");
            msg.To.Add(okAddress);
            msg.To.Add(new MailAddress("notyou@example.com", "No One"));

            Assert.That(_target.Process(msg), Is.True);
            Assert.That(msg.To, Is.EqualTo(new[] {okAddress}));
        }
    }
}