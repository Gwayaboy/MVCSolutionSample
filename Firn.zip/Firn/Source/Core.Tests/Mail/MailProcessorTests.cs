using System.Collections.Generic;
using System.Net.Mail;
using Castle.Core.Logging;
using Intrigma.Firn.Core.Mail;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Core.Tests.Mail
{
    [TestFixture]
    public class MailProcessorTests : MockTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _mailService = DynamicMock<IMailer>();
            _target = new MailProcessor(_mailService, NullLogger.Instance);
        }

        private IMailer _mailService;
        private MailProcessor _target;

        [Test]
        public void SendCancelledTest()
        {
            var msg = new MailMessage();
            IList<IMailFilter> filters = CreateMocksArray<IMailFilter>(5);
            for (int index = 0; index < 3; index++)
            {
                // The third filter cancels sending the message.
                Expect.Call(filters[index].Process(msg)).Return(index < 2);
            }
            DoNotExpect.Call(delegate { _mailService.Mail(msg); });
            ReplayAll();

            _target.Filters = filters;
            _target.Send(msg);
        }

        [Test]
        public void SendTest()
        {
            var msg = new MailMessage();
            IList<IMailFilter> filters = CreateMocksArray<IMailFilter>(5);
            foreach (IMailFilter filter in filters)
            {
                Expect.Call(filter.Process(msg)).Return(true);
            }
            _mailService.Mail(msg);
            ReplayAll();

            _target.Filters = filters;
            _target.Send(msg);
        }
    }
}