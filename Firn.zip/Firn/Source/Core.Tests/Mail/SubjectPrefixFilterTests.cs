using System.Net.Mail;
using Intrigma.Firn.Core.Environment;
using Intrigma.Firn.Core.Mail;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Core.Tests.Mail
{
    [TestFixture]
    public class SubjectPrefixFilterTests : MockTestFixture
    {
        #region Setup/Teardown

        public override void SetUp()
        {
            base.SetUp();
            _environment = DynamicMock<IEnvironment>();
            _target = new SubjectPrefixFilter(_environment);
        }

        #endregion

        private SubjectPrefixFilter _target;
        private IEnvironment _environment;

        [Test]
        public void AddPrefix()
        {
            var prefix = Create.UniqueString();
            var message = new MailMessage();
            const string baseSubject = "hello subject";
            message.Subject = baseSubject;
            SetupResult.For(_environment.EmailSubjectPrefix).Return(prefix);
            ReplayAll();

            _target.Process(message);
            Assert.That(message.Subject, Is.EqualTo(prefix + baseSubject));
        }

        [Test]
        public void ReturnOk()
        {
            ReplayAll();
            Assert.That(_target.Process(new MailMessage()), Is.True);
        }
    }
}