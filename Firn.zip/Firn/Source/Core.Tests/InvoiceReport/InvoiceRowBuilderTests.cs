using System;
using Intrigma.Firn.Core.InvoiceReport;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Core.Tests.InvoiceReport
{
    [TestFixture]
    public class InvoiceRowBuilderTests : MockTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _target = new InvoiceRowBuilder();
            _dataSet = new InvoiceReportDataSet();
        }

        private InvoiceRowBuilder _target;
        private InvoiceReportDataSet _dataSet;

        [Test]
        public void AddRowToDataSet()
        {
            Assert.That(_target.Add(_dataSet, new Invoice(new Customer(), 0, default(DateTime), default(DateTime))),
                        Is.SameAs(_dataSet.Invoice[0]));
        }

        [Test]
        public void SetBillToAddress()
        {
            var customer = new Customer();
            customer.StreetAddress1 = "blah";
            customer.StreetAddress2 = "the boonies";

            Assert.That(
                _target.Add(_dataSet, new Invoice(customer, 0, default(DateTime), default(DateTime))).BillToAddress,
                Is.EqualTo(customer.Address));
        }

        [Test]
        public void SetBillToAttn()
        {
            var customer = new Customer();
            customer.AttnFirstName = Create.AnyString();
            customer.AttnLastName = Create.AnyString();
            Assert.That(
                _target.Add(_dataSet, new Invoice(customer, 0, default(DateTime), default(DateTime))).BillToAttn,
                Is.EqualTo(customer.AttnFullName));
        }

        [Test]
        public void SetBillToEmailAddress()
        {
            var customer = new Customer();
            customer.EmailAddress = Create.AnyString();
            Assert.That(
                _target.Add(_dataSet, new Invoice(customer, 0, default(DateTime), default(DateTime))).BillToEmailAddress,
                Is.EqualTo(customer.EmailAddress));
        }

        [Test]
        public void SetBillToName()
        {
            var customer = new Customer();
            customer.Name = Create.AnyString();
            Assert.That(
                _target.Add(_dataSet, new Invoice(customer, 0, default(DateTime), default(DateTime))).BillToName,
                Is.EqualTo(customer.Name));
        }

        [Test]
        public void SetBillToPhone()
        {
            var customer = new Customer();
            customer.Phone = Create.AnyString();
            Assert.That(
                _target.Add(_dataSet, new Invoice(customer, 0, default(DateTime), default(DateTime))).BillToPhone,
                Is.EqualTo(customer.Phone));
        }

        [Test]
        public void SetBillingPeriod()
        {
            var customer = new Customer();
            customer.BillingPeriod = BillingPeriod.Quarterly;
            Assert.That(
                _target.Add(_dataSet, new Invoice(customer, 0, default(DateTime), default(DateTime))).BillingPeriod,
                Is.EqualTo(customer.BillingPeriod.ToString()));
        }

        [Test]
        public void SetBillingType()
        {
            var customer = new Customer();
            customer.BillingType = BillingType.CreditCard;
            Assert.That(
                _target.Add(_dataSet, new Invoice(customer, 0, default(DateTime), default(DateTime))).BillingType,
                Is.EqualTo(new EnumFormatHelper().GetDescription(customer.BillingType)));
        }

        [Test]
        public void SetDueDate()
        {
            var invoice = new Invoice(new Customer(), 6, default(DateTime), Create.AnyDate());
            Assert.That(_target.Add(_dataSet, invoice).DueDate, Is.EqualTo(invoice.DueDate));
        }

        [Test]
        public void SetId()
        {
            var invoice = new Invoice(new Customer(), 6, default(DateTime), default(DateTime));
            Assert.That(_target.Add(_dataSet, invoice).Id, Is.EqualTo(invoice.Id));
        }

        [Test]
        public void SetInvoiceDate()
        {
            var invoice = new Invoice(new Customer(), 6, Create.AnyDate(), default(DateTime));
            Assert.That(_target.Add(_dataSet, invoice).InvoiceDate, Is.EqualTo(invoice.InvoiceDate));
        }

        [Test]
        public void SetTotal()
        {
            var invoice = DynamicMock<Invoice>();
            decimal total = 546.45m;
            SetupResult.For(invoice.Total).Return(total);
            SetupResult.For(invoice.Customer).Return(new Customer());
            ReplayAll();

            Assert.That(_target.Add(_dataSet, invoice).Total, Is.EqualTo(invoice.Total));
        }
    }
}