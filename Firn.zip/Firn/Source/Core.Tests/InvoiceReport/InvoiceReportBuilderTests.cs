using Intrigma.Firn.Core.InvoiceReport;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Core.Tests.InvoiceReport
{
    [TestFixture]
    public class InvoiceReportBuilderTests : MockTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _dataSetFactory = DynamicMock<IInvoiceReportDataSetFactory>();
            _reportFactory = DynamicMock<IInvoiceReportFactory>();
            _dataSetBuilder = DynamicMock<IInvoiceDataSetBuilder>();
            _target = new InvoiceReportBuilder(_dataSetFactory, _dataSetBuilder, _reportFactory);
        }

        private InvoiceReportBuilder _target;
        private IInvoiceReportDataSetFactory _dataSetFactory;
        private IInvoiceReportFactory _reportFactory;
        private IInvoiceDataSetBuilder _dataSetBuilder;

        [Test]
        public void BuildDataSource()
        {
            var invoice = new Invoice();
            var dataSet = new InvoiceReportDataSet();
            SetupResult.For(_dataSetFactory.Create()).Return(dataSet);
            _dataSetBuilder.Build(dataSet, invoice);
            SetupResult.For(_reportFactory.Create()).Return(DynamicMock<IInvoiceReport>());
            ReplayAll();

            _target.Build(invoice);
        }

        [Test]
        public void ReturnReport()
        {
            var report = DynamicMock<IInvoiceReport>();
            SetupResult.For(_reportFactory.Create()).Return(report);
            ReplayAll();

            Assert.That(_target.Build(new Invoice()), Is.SameAs(report));
        }

        [Test]
        public void SetDataSource()
        {
            var dataSet = new InvoiceReportDataSet();
            SetupResult.For(_dataSetFactory.Create()).Return(dataSet);
            var report = DynamicMock<IInvoiceReport>();
            SetupResult.For(_reportFactory.Create()).Return(report);
            report.DataSource = dataSet;
            ReplayAll();

            _target.Build(new Invoice());
        }
    }
}