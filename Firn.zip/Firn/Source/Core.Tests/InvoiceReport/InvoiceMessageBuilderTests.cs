using System;
using System.IO;
using System.Net.Mail;
using System.Net.Mime;
using Intrigma.Firn.Core.InvoiceReport;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Core.Tests.InvoiceReport
{
    [TestFixture]
    public class InvoiceMessageBuilderTests : MockTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _reportBuilder = DynamicMock<IInvoiceReportBuilder>();
            _pdfExporter = DynamicMock<IReportPdfExporter>();
            _customerBuilder = DynamicMock<ICustomerMessageBuilder>();
            _target = new InvoiceMessageBuilder(_reportBuilder, _pdfExporter, _customerBuilder);
        }

        private InvoiceMessageBuilder _target;
        private IInvoiceReportBuilder _reportBuilder;
        private IReportPdfExporter _pdfExporter;
        private ICustomerMessageBuilder _customerBuilder;

        [Test]
        public void AddAttachmentWithReportContents()
        {
            var message = new MailMessage();
            var invoice = new Invoice(Create.CustomerWithEmailAddress(), 5, default(DateTime), default(DateTime));
            SetupResult.For(_customerBuilder.Build(invoice.Customer)).Return(message);
            var report = DynamicMock<IInvoiceReport>();
            SetupResult.For(_reportBuilder.Build(invoice)).Return(report);
            byte[] contents = {36, 34, 66, 13};
            SetupResult.For(_pdfExporter.Export(report)).Return(contents);
            ReplayAll();

            _target.Build(invoice);
            Assert.That(((MemoryStream) message.Attachments[0].ContentStream).ToArray(), Is.EqualTo(contents));
        }

        [Test]
        public void ReturnMessage()
        {
            var message = new MailMessage();
            var invoice = new Invoice(Create.CustomerWithEmailAddress(), 5, default(DateTime), default(DateTime));
            SetupResult.For(_customerBuilder.Build(invoice.Customer)).Return(message);
            SetupResult.For(_pdfExporter.Export(null)).Return(new byte[0]);
            ReplayAll();

            Assert.That(_target.Build(invoice), Is.SameAs(message));
        }

        [Test]
        public void SetAttachmentContentType()
        {
            var message = new MailMessage();
            var invoice = new Invoice(Create.CustomerWithEmailAddress(), 5, default(DateTime), default(DateTime));
            SetupResult.For(_customerBuilder.Build(invoice.Customer)).Return(message);
            SetupResult.For(_pdfExporter.Export(null)).Return(new byte[0]);
            ReplayAll();

            _target.Build(invoice);
            Assert.That(message.Attachments[0].ContentType.MediaType, Is.EqualTo(MediaTypeNames.Application.Pdf));
        }

        [Test]
        public void SetAttachmentName()
        {
            var message = new MailMessage();
            var invoice = new Invoice(Create.CustomerWithEmailAddress(), 5, default(DateTime), default(DateTime));
            SetupResult.For(_customerBuilder.Build(invoice.Customer)).Return(message);
            SetupResult.For(_pdfExporter.Export(null)).Return(new byte[0]);
            string expected = string.Format(InvoiceMessageBuilder.AttachmentNameFormat, invoice.Id);
            ReplayAll();

            _target.Build(invoice);
            Assert.That(message.Attachments[0].Name, Is.EqualTo(expected));
        }

        [Test]
        public void SetBodyWhenCanAutoPay()
        {
            var message = new MailMessage();
            Customer customer = Create.CustomerWithEmailAddress();
            SetupResult.For(_customerBuilder.Build(customer)).Return(message);
            customer.BillingType = Create.NonDefaultBillingType();
            decimal total = 345;
            Invoice invoice = Create.InvoiceForCustomerWithTotal(customer, total);
            SetupResult.For(_pdfExporter.Export(null)).Return(new byte[0]);
            string expected = string.Format(InvoiceMessageBuilder.AutoPayBodyFormat, invoice.Id, invoice.DueDate,
                                            string.Format(
                                                new EnumFormatHelper().GetAttributeText<PaymentPhraseAttribute>(
                                                    customer.BillingType), total));
            ReplayAll();

            _target.Build(invoice);
            Assert.That(message.Body, Is.EqualTo(expected));
        }

        [Test]
        public void SetBodyWhenCannotAutoPay()
        {
            var message = new MailMessage();
            var invoice = new Invoice(Create.CustomerWithEmailAddress(), 5, default(DateTime), default(DateTime));
            SetupResult.For(_customerBuilder.Build(invoice.Customer)).Return(message);
            SetupResult.For(_pdfExporter.Export(null)).Return(new byte[0]);
            string expected = string.Format(InvoiceMessageBuilder.BodyFormat, invoice.Id, invoice.DueDate);
            ReplayAll();

            _target.Build(invoice);
            Assert.That(message.Body, Is.EqualTo(expected));
        }

        [Test]
        public void SetSubject()
        {
            var message = new MailMessage();
            var invoice = new Invoice(Create.CustomerWithEmailAddress(), 5, default(DateTime), default(DateTime));
            SetupResult.For(_customerBuilder.Build(invoice.Customer)).Return(message);
            SetupResult.For(_pdfExporter.Export(null)).Return(new byte[0]);
            string expected = string.Format(InvoiceMessageBuilder.SubjectFormat, invoice.Id, invoice.DueDate);
            ReplayAll();

            _target.Build(invoice);
            Assert.That(message.Subject, Is.EqualTo(expected));
        }
    }
}