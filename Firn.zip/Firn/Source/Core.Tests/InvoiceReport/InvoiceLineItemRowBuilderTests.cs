using System;
using Intrigma.Firn.Core.InvoiceReport;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;

namespace Intrigma.Firn.Core.Tests.InvoiceReport
{
    [TestFixture]
    public class InvoiceLineItemRowBuilderTests : MockTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _target = new InvoiceLineItemRowBuilder();
            _dataSet = new InvoiceReportDataSet();
            _invoiceRow = _dataSet.Invoice.AddInvoiceRow(1, 0, default(DateTime), default(DateTime), string.Empty,
                                                         string.Empty, string.Empty, string.Empty, string.Empty,
                                                         string.Empty, string.Empty);
        }

        private InvoiceLineItemRowBuilder _target;
        private InvoiceReportDataSet _dataSet;
        private InvoiceReportDataSet.InvoiceRow _invoiceRow;

        [Test]
        public void AddRowToDataSet()
        {
            Assert.That(_target.Add(_dataSet, _invoiceRow, new InvoiceLineItem()),
                        Is.SameAs(_dataSet.InvoiceLineItem[0]));
        }

        [Test]
        public void SetDate()
        {
            var item = new InvoiceLineItem(Create.AnyDate(), Create.AnyString(), string.Empty, 0, 0);
            Assert.That(_target.Add(_dataSet, _invoiceRow, item).Date, Is.EqualTo(item.Date));
        }

        [Test]
        public void SetDescription()
        {
            var item = new InvoiceLineItem(default(DateTime), string.Empty, Create.AnyString(), 0, 0);
            Assert.That(_target.Add(_dataSet, _invoiceRow, item).Description, Is.EqualTo(item.Description));
        }

        [Test]
        public void SetId()
        {
            var item = new InvoiceLineItem();
            item.Id = 54;
            Assert.That(_target.Add(_dataSet, _invoiceRow, item).Id, Is.EqualTo(item.Id));
        }

        [Test]
        public void SetName()
        {
            var item = new InvoiceLineItem(default(DateTime), Create.AnyString(), string.Empty, 0, 0);
            Assert.That(_target.Add(_dataSet, _invoiceRow, item).Name, Is.EqualTo(item.Name));
        }

        [Test]
        public void SetParentInvoice()
        {
            var item = new InvoiceLineItem();
            Assert.That(_target.Add(_dataSet, _invoiceRow, item).InvoiceRow, Is.SameAs(_invoiceRow));
        }

        [Test]
        public void SetPrice()
        {
            var item = new InvoiceLineItem(default(DateTime), string.Empty, string.Empty, 0, 0.25m);
            Assert.That(_target.Add(_dataSet, _invoiceRow, item).Price, Is.EqualTo(item.Price));
        }

        [Test]
        public void SetStaffCount()
        {
            var item = new InvoiceLineItem(default(DateTime), string.Empty, string.Empty, 50, 0);
            Assert.That(_target.Add(_dataSet, _invoiceRow, item).StaffCount, Is.EqualTo(item.StaffCount));
        }

        [Test]
        public void SetStaffCountNull()
        {
            var item = new InvoiceLineItem(default(DateTime), string.Empty, string.Empty, null, 0);
            Assert.That(_target.Add(_dataSet, _invoiceRow, item).IsStaffCountNull(), Is.True);
        }
    }
}