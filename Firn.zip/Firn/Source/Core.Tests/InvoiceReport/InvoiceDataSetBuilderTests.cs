using Intrigma.Firn.Core.InvoiceReport;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Core.Tests.InvoiceReport
{
    [TestFixture]
    public class InvoiceDataSetBuilderTests : MockTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _invoiceBuilder = DynamicMock<IInvoiceRowBuilder>();
            _lineItemBuilder = DynamicMock<IInvoiceLineItemRowBuilder>();
            _target = new InvoiceDataSetBuilder(_invoiceBuilder, _lineItemBuilder);
            _dataSet = new InvoiceReportDataSet();
        }

        private InvoiceDataSetBuilder _target;
        private IInvoiceRowBuilder _invoiceBuilder;
        private IInvoiceLineItemRowBuilder _lineItemBuilder;
        private InvoiceReportDataSet _dataSet;

        [Test]
        public void NoLineItemsBuildsInvoiceAnyway()
        {
            var invoice = new Invoice();
            Expect.Call(_invoiceBuilder.Add(_dataSet, invoice)).Return(null);
            ReplayAll();

            _target.Build(_dataSet, invoice);
        }

        [Test]
        public void TwoLineItemsToBuild()
        {
            var invoice = new Invoice();
            invoice.AddLineItem(new InvoiceLineItem());
            invoice.AddLineItem(new InvoiceLineItem());
            InvoiceReportDataSet.InvoiceRow row = _dataSet.Invoice.NewInvoiceRow();
            SetupResult.For(_invoiceBuilder.Add(_dataSet, invoice)).Return(row);
            Expect.Call(_lineItemBuilder.Add(_dataSet, row, invoice.LineItems[0])).Return(null);
            Expect.Call(_lineItemBuilder.Add(_dataSet, row, invoice.LineItems[1])).Return(null);
            ReplayAll();

            _target.Build(_dataSet, invoice);
        }
    }
}