using System.Net.Mail;
using Intrigma.Firn.Core.InvoiceReport;
using Intrigma.Firn.Core.Mail;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Core.Tests.InvoiceReport
{
    [TestFixture]
    public class InvoiceMailerTests : MockTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _builder = DynamicMock<IInvoiceMessageBuilder>();
            _mailer = DynamicMock<IMailProcessor>();
            _target = new InvoiceMailer(_builder, _mailer);
        }

        private InvoiceMailer _target;
        private IInvoiceMessageBuilder _builder;
        private IMailProcessor _mailer;

        [Test]
        public void BuildAndSendMessage()
        {
            var customer = new Customer();
            customer.EmailAddress = Create.AnyEmailAddress();
            Invoice invoice = Create.InvoiceForCustomer(customer);
            var message = new MailMessage();
            SetupResult.For(_builder.Build(invoice)).Return(message);
            _mailer.Send(message);
            ReplayAll();

            _target.Mail(invoice);
        }

        [Test]
        public void DoNothingIfCustomerCannotReceiveMail()
        {
            var customer = new Customer();
            Invoice invoice = Create.InvoiceForCustomer(customer);
            DoNotExpect.Call(delegate { _mailer.Send(null); });
            ReplayAll();

            _target.Mail(invoice);
        }

        [Test]
        public void ReturnErrorIfCustomerCannotReceiveMail()
        {
            var customer = new Customer();
            Invoice invoice = Create.InvoiceForCustomer(customer);
            ReplayAll();

            Assert.That(_target.Mail(invoice), Is.EqualTo(InvoiceMailer.NoEmailError));
            _target.Mail(invoice);
        }

        [Test]
        public void ReturnNoError()
        {
            var customer = new Customer();
            customer.EmailAddress = Create.AnyEmailAddress();
            Invoice invoice = Create.InvoiceForCustomer(customer);
            ReplayAll();

            Assert.That(_target.Mail(invoice), Is.Null);
        }
    }
}