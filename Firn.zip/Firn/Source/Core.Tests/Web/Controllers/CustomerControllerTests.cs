using System;
using System.Collections.Generic;
using Intrigma.Firn.Core.Web.Controllers;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.PaymentGateway;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Core.Tests.Web.Controllers
{
    public class StubCustomerController : CustomerController
    {
        private Customer _customer;

        private bool _redirected;

        public StubCustomerController(ICustomerRepository customerRepository, ICurrentDateFetcher date,
                                      IPaymentGateway gateway) : base(customerRepository, date, gateway) {}

        public Customer Customer
        {
            get { return _customer; }
            set { _customer = value; }
        }

        public bool Redirected
        {
            get { return _redirected; }
        }

        public override Customer GetCustomer()
        {
            return _customer;
        }

        public override void RedirectToView(Customer customer)
        {
            _redirected = true;
        }
    }

    [TestFixture]
    public class CustomerControllerTests : ControllerTestFixture<StubCustomerController>
    {
        private ICustomerRepository _customerRepository;
        private ICurrentDateFetcher _date;
        private IPaymentGateway _gateway;

        protected override StubCustomerController CreateController()
        {
            _customerRepository = DynamicMock<ICustomerRepository>();
            _date = DynamicMock<ICurrentDateFetcher>();
            _gateway = DynamicMock<IPaymentGateway>();
            return new StubCustomerController(_customerRepository, _date, _gateway);
        }

        [Test]
        public void ChangePaymentMethodCrashesSetsCorrectView()
        {
            var customer = DynamicMock<Customer>();
            Controller.Customer = customer;
            BillingType billingType = BillingType.Eft;
            var payment = new PaymentType();
            customer.UpdatePaymentMethod(billingType, payment, _gateway);
            LastCall.Throw(new Exception("asdfasdfasdf"));
            ReplayAll();

            Controller.ChangePaymentMethod(billingType, payment);
            Assert.That(Controller.SelectedViewName, Is.EqualTo(@"Controller\ShowPaymentMethod"));
        }

        [Test]
        public void ChangePaymentMethodCrashesSetsCustomerInView()
        {
            var customer = DynamicMock<Customer>();
            Controller.Customer = customer;
            BillingType billingType = BillingType.Eft;
            var payment = new PaymentType();
            customer.UpdatePaymentMethod(billingType, payment, _gateway);
            LastCall.Throw(new Exception());
            ReplayAll();

            Controller.ChangePaymentMethod(billingType, payment);
            Assert.That(Controller.PropertyBag[CustomerConstants.Customer], Is.SameAs(customer));
        }

        [Test]
        public void ChangePaymentMethodCrashesSetsErrorMessageInView()
        {
            var customer = DynamicMock<Customer>();
            Controller.Customer = customer;
            BillingType billingType = BillingType.Eft;
            var payment = new PaymentType();
            customer.UpdatePaymentMethod(billingType, payment, _gateway);
            string message = "aasgasd";
            LastCall.Throw(new Exception(message));
            ReplayAll();

            Controller.ChangePaymentMethod(billingType, payment);
            Assert.That(Controller.PropertyBag["error"], Is.EqualTo(message));
        }

        [Test]
        public void ChangePaymentMethodCrashesSetsPaymentMethodInView()
        {
            var customer = DynamicMock<Customer>();
            Controller.Customer = customer;
            BillingType billingType = BillingType.Eft;
            var payment = new PaymentType();
            customer.UpdatePaymentMethod(billingType, payment, _gateway);
            LastCall.Throw(new Exception());
            ReplayAll();

            Controller.ChangePaymentMethod(billingType, payment);
            Assert.That(Controller.PropertyBag[CustomerConstants.PaymentMethod], Is.SameAs(payment));
        }

        [Test]
        public void ChangePaymentMethodDoIt()
        {
            var customer = DynamicMock<Customer>();
            Controller.Customer = customer;
            BillingType billingType = BillingType.Eft;
            var payment = new PaymentType();
            customer.UpdatePaymentMethod(billingType, payment, _gateway);
            ReplayAll();

            Controller.ChangePaymentMethod(billingType, payment);
        }

        [Test]
        public void ChangePaymentMethodRedirectsBackHome()
        {
            Controller.Customer = DynamicMock<Customer>();
            ReplayAll();

            Controller.ChangePaymentMethod(default(BillingType), new PaymentType());
            Assert.That(Controller.Redirected, Is.True);
        }

        [Test]
        public void DeleteSecondaryEmailAddresses()
        {
            var customer = new Customer();
            customer.SetSecondaryEmailAddresses(Create.Set(Create.AnyEmailAddress()));
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(null, null, null, null, null, null, null, null, null, null);
            Assert.That(customer.SecondaryEmailAddresses, Is.Empty);
        }

        [Test]
        public void DoNotUpdateContactInformationWhenValidationFails()
        {
            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(Create.AnyString(), null, null, null, null, null, null, null, null,
                                                "ddddd");
            Assert.That(customer.AttnFirstName, Is.Empty);
        }

        [Test]
        public void EditCustomerSetsAddress1InBag()
        {
            var customer = new Customer();
            const string address1 = "address";
            customer.StreetAddress1 = address1;
            Controller.Customer = customer;
            ReplayAll();

            Controller.ShowContactInformation();
            Assert.That(Controller.PropertyBag[CustomerConstants.Street1], Is.EqualTo(address1));
        }

        [Test]
        public void EditCustomerSetsAddress2InBag()
        {
            var customer = new Customer();
            const string address2 = "address";
            customer.StreetAddress2 = address2;
            Controller.Customer = customer;
            ReplayAll();

            Controller.ShowContactInformation();
            Assert.That(Controller.PropertyBag[CustomerConstants.Street2], Is.EqualTo(address2));
        }

        [Test]
        public void EditCustomerSetsAttnFirstNameInBag()
        {
            var customer = new Customer();
            const string value = "name";
            customer.AttnFirstName = value;
            Controller.Customer = customer;
            ReplayAll();

            Controller.ShowContactInformation();
            Assert.That(Controller.PropertyBag[CustomerConstants.AttnFirstName], Is.EqualTo(value));
        }

        [Test]
        public void EditCustomerSetsAttnInBag()
        {
            var customer = new Customer();
            const string attn = "attn";
            customer.AttnLastName = attn;
            Controller.Customer = customer;
            ReplayAll();

            Controller.ShowContactInformation();
            Assert.That(Controller.PropertyBag[CustomerConstants.AttnLastName], Is.EqualTo(attn));
        }

        [Test]
        public void EditCustomerSetsCityInBag()
        {
            var customer = new Customer();
            const string city = "city";
            customer.City = city;
            Controller.Customer = customer;
            ReplayAll();

            Controller.ShowContactInformation();
            Assert.That(Controller.PropertyBag[CustomerConstants.City], Is.EqualTo(city));
        }

        [Test]
        public void EditCustomerSetsCustomerInBag()
        {
            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.ShowContactInformation();
            Assert.That(Controller.PropertyBag[CustomerConstants.Customer], Is.SameAs(customer));
        }

        [Test]
        public void EditCustomerSetsEmailInBag()
        {
            var customer = new Customer();
            const string email = "email";
            customer.EmailAddress = email;
            Controller.Customer = customer;
            ReplayAll();

            Controller.ShowContactInformation();
            Assert.That(Controller.PropertyBag[CustomerConstants.Email], Is.EqualTo(email));
        }

        [Test]
        public void EditCustomerSetsPhoneInBag()
        {
            var customer = new Customer();
            const string value = "name";
            customer.Phone = value;
            Controller.Customer = customer;
            ReplayAll();

            Controller.ShowContactInformation();
            Assert.That(Controller.PropertyBag[CustomerConstants.Phone], Is.EqualTo(value));
        }

        [Test]
        public void EditCustomerSetsSecondaryEmailsInBag()
        {
            var customer = new Customer();
            string[] emails = {Create.UniqueEmailAddress(), Create.UniqueEmailAddress()};
            customer.SetSecondaryEmailAddresses(Create.Set(emails));
            Controller.Customer = customer;
            ReplayAll();

            Controller.ShowContactInformation();
            Assert.That(Controller.PropertyBag[CustomerConstants.SecondaryEmails], Is.EqualTo(string.Join("\n", emails)));
        }

        [Test]
        public void EditCustomerSetsStateInBag()
        {
            var customer = new Customer();
            const string state = "state";
            customer.State = state;
            Controller.Customer = customer;
            ReplayAll();

            Controller.ShowContactInformation();
            Assert.That(Controller.PropertyBag[CustomerConstants.State], Is.EqualTo(state));
        }

        [Test]
        public void EditCustomerSetsZipInBag()
        {
            var customer = new Customer();
            const string zip = "zip";
            customer.Zip = zip;
            Controller.Customer = customer;
            ReplayAll();

            Controller.ShowContactInformation();
            Assert.That(Controller.PropertyBag[CustomerConstants.Zip], Is.EqualTo(zip));
        }

        [Test]
        public void RenderShowContantViewWhenUpdateFails()
        {
            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(null, null, null, null, null, null, null, null, null, "ddddd");
            Assert.That(Controller.SelectedViewName, Is.EqualTo(@"Controller\ShowContactInformation"));
        }

        [Test]
        public void ShowPaymentMethodSetsBillingTypeInBag()
        {
            var customer = new Customer();
            customer.BillingType = BillingType.CreditCard;
            Controller.Customer = customer;
            ReplayAll();

            Controller.ShowPaymentMethod();
            Assert.That(Controller.PropertyBag[CustomerConstants.BillingType], Is.EqualTo(customer.BillingType));
        }

        [Test]
        public void ShowPaymentMethodSetsCustomerInBag()
        {
            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.ShowPaymentMethod();
            Assert.That(Controller.PropertyBag[CustomerConstants.Customer], Is.SameAs(customer));
        }

        [Test]
        public void SubmitClickedRedirectsBackHome()
        {
            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(null, null, null, null, null, null, null, null, null, null);
            Assert.That(Controller.Redirected, Is.True);
        }

        [Test]
        public void SubmitClickedSavesTheCustomer()
        {
            var customer = new Customer();
            Controller.Customer = customer;
            _customerRepository.Save(customer);
            ReplayAll();

            Controller.UpdateContactInformation(null, null, null, null, null, null, null, null, null, null);
        }

        [Test]
        public void SubmitClickedSetsAddress2ToEmptyInsteadOfNullIfLeftBlank()
        {
            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(null, null, null, null, null, null, null, null, null, null);
            Assert.That(customer.StreetAddress2, Is.EqualTo(string.Empty));
        }

        [Test]
        public void SubmitClickedSetsAttnFirstName()
        {
            string attn = Create.UniqueString();

            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(attn, null, null, null, null, null, null, null, null, null);
            Assert.That(customer.AttnFirstName, Is.EqualTo(attn));
        }

        [Test]
        public void SubmitClickedSetsAttnLastName()
        {
            string attn = Create.UniqueString();

            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(null, attn, null, null, null, null, null, null, null, null);
            Assert.That(customer.AttnLastName, Is.EqualTo(attn));
        }

        [Test]
        public void SubmitClickedSetsCity()
        {
            string city = Create.UniqueString();

            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(null, null, null, null, city, null, null, null, null, null);
            Assert.That(customer.City, Is.EqualTo(city));
        }

        [Test]
        public void SubmitClickedSetsCustomerInView()
        {
            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(null, null, null, null, null, null, null, null, null, null);
            Assert.That(Controller.PropertyBag[CustomerConstants.Customer], Is.SameAs(customer));
        }

        [Test]
        public void SubmitClickedSetsEmail()
        {
            string email = Create.UniqueString();

            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(null, null, null, null, null, null, null, null, email, null);
            Assert.That(customer.EmailAddress, Is.EqualTo(email));
        }

        [Test]
        public void SubmitClickedSetsPhone()
        {
            string phone = Create.UniqueString();

            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(null, null, null, null, null, null, null, phone, null, null);
            Assert.That(customer.Phone, Is.EqualTo(phone));
        }

        [Test]
        public void SubmitClickedSetsState()
        {
            string state = Create.UniqueString();

            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(null, null, null, null, null, state, null, null, null, null);
            Assert.That(customer.State, Is.EqualTo(state));
        }

        [Test]
        public void SubmitClickedSetsStreet1()
        {
            string street = Create.UniqueString();

            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(null, null, street, null, null, null, null, null, null, null);
            Assert.That(customer.StreetAddress1, Is.EqualTo(street));
        }

        [Test]
        public void SubmitClickedSetsStreet2()
        {
            string street = Create.UniqueString();

            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(null, null, null, street, null, null, null, null, null, null);
            Assert.That(customer.StreetAddress2, Is.EqualTo(street));
        }

        [Test]
        public void SubmitClickedSetsZip()
        {
            string zip = Create.UniqueString();

            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(null, null, null, null, null, null, zip, null, null, null);
            Assert.That(customer.Zip, Is.EqualTo(zip));
        }

        [Test]
        public void UpdateContactInformationWhenValidationSucceeds()
        {
            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(Create.AnyString(), null, null, null, null, null, null, null, null,
                                                Create.AnyEmailAddress());
            Assert.That(customer.AttnFirstName, Is.Not.Empty);
        }

        [Test]
        public void UpdateSetsEmailErrors()
        {
            var customer = new Customer();
            string[] emails = {"ddd", "asdfasdf@..."};
            Controller.Customer = customer;
            ReplayAll();

            Controller.UpdateContactInformation(null, null, null, null, null, null, null, null, null,
                                                string.Join("\n", emails));
            Assert.That(Controller.PropertyBag["errors"],
                        Is.EquivalentTo(new[]
                                            {
                                                string.Format(Customer.InvalidEmailAddressFormat, emails[0]),
                                                string.Format(Customer.InvalidEmailAddressFormat, emails[1]),
                                            }));
        }

        [Test]
        public void ViewCustomerSetsPaymentMethodInBag()
        {
            var customer = DynamicMock<Customer>();
            Controller.Customer = customer;
            var paymentType = new PaymentType();
            SetupResult.For(customer.GetPaymentMethod(_gateway)).Return(paymentType);
            ReplayAll();

            Controller.View();
            Assert.That(Controller.PropertyBag[CustomerConstants.PaymentMethod], Is.SameAs(paymentType));
        }

        [Test]
        public void ViewSetsCurrentDateInBag()
        {
            var customer = new Customer();
            Controller.Customer = customer;
            DateTime date = Create.AnyDate();
            SetupResult.For(_date.Now).Return(date);
            ReplayAll();

            Controller.View();
            Assert.That(Controller.PropertyBag[CustomerConstants.CurrentDate], Is.EqualTo(date));
        }

        [Test]
        public void ViewSetsCustomerInBag()
        {
            var customer = new Customer();
            Controller.Customer = customer;
            ReplayAll();

            Controller.View();
            Assert.That(Controller.PropertyBag[CustomerConstants.Customer], Is.SameAs(customer));
        }

        [Test]
        public void ViewSetsInvoicesInBagForCustomer()
        {
            var customer = DynamicMock<Customer>();
            Controller.Customer = customer;
            IList<Invoice> invoices = new[] {new Invoice(), new Invoice(), new Invoice(),};
            SetupResult.For(customer.Invoices).Return(invoices);
            ReplayAll();

            Controller.View();
            Assert.That(Controller.PropertyBag["invoices"], Is.EqualTo(invoices));
        }

        [Test]
        public void ViewSetsSubscriptionsInBagForCustomer()
        {
            var customer = DynamicMock<Customer>();
            Controller.Customer = customer;
            IList<Subscription> subscriptions = CreateMocks<Subscription>(5);
            SetupResult.For(customer.Subscriptions).Return(subscriptions);
            ReplayAll();

            Controller.View();
            Assert.That(Controller.PropertyBag[CustomerConstants.Subscriptions], Is.SameAs(subscriptions));
        }

        [Test]
        public void ViewSetsTransactionsInBagForCustomer()
        {
            var customer = DynamicMock<Customer>();
            Controller.Customer = customer;
            IList<BaseTransaction> payments = CreateMocks<BaseTransaction>(5);
            SetupResult.For(customer.Transactions).Return(payments);
            ReplayAll();

            Controller.View();
            Assert.That(Controller.PropertyBag[CustomerConstants.Transactions], Is.SameAs(payments));
        }
    }
}