using System.Collections.Generic;
using Castle.MonoRail.Framework;
using Castle.MonoRail.TestSupport;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Core.Tests.Web.Controllers
{
    public abstract class ControllerTestFixture<TController> : BaseControllerTest where TController : Controller
    {
        private TController _controller;
        private MockRepository _mocks;

        protected TController Controller
        {
            get { return _controller; }
        }

        protected MockRepository Mocks
        {
            get { return _mocks; }
        }

        [SetUp]
        public virtual void Init()
        {
            _mocks = new MockRepository();
            _controller = CreateController();
            PrepareController(_controller);
        }

        protected abstract TController CreateController();

        [TearDown]
        public virtual void TearDown()
        {
            _mocks.VerifyAll();
        }

        public IList<T> CreateMocks<T>(int count) where T : class
        {
            var list = new List<T>();
            for (int index = 0; index < count; index++)
            {
                list.Add(_mocks.DynamicMock<T>());
            }
            return list;
        }

        public T DynamicMock<T>() where T : class
        {
            return _mocks.DynamicMock<T>();
        }

        public void ReplayAll()
        {
            _mocks.ReplayAll();
        }
    }
}