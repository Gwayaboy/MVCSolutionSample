using System;
using System.Collections.Generic;
using Iesi.Collections.Generic;
using Intrigma.Firn.DomainModel.PaymentGateway;
using Rhino.Mocks;

namespace Intrigma.Firn.DomainModel.Tests
{
    public static class Create
    {
        private static readonly string[] _cuteTestStrings = {
                                                                "Ponies!", "Look, a horse!", "glitterfly",
                                                                "I can has cookie?"
                                                            };

        private static int _testStringIndex;
        private static int _uniqueDateIndex;
        private static int _uniqueEmailIndex;

        public static DateTime AnyDate()
        {
            return new DateTime(2009, 3, 9);
        }

        public static string AnyString()
        {
            return "cute!";
        }

        public static string UniqueString()
        {
            _testStringIndex++;
            return _cuteTestStrings[_testStringIndex % _cuteTestStrings.Length] + _testStringIndex;
        }

        public static string AnyEmailAddress()
        {
            return "cute@awww.com";
        }

        public static Invoice InvoiceForCustomer(Customer customer)
        {
            return new Invoice(customer, 4, AnyDate(), AnyDate());
        }

        public static BillingType NonDefaultBillingType()
        {
            return BillingType.CreditCard;
        }

        public static DatePeriod AnyDatePeriod()
        {
            DateTime start = AnyDate();
            return new DatePeriod(start, start.AddDays(7));
        }

        public static Customer CustomerWithBalance(decimal balance)
        {
            var customer = new Customer();
            customer.AddTransaction(new BaseTransaction(AnyDate(), balance, "Starting", "Starting balance"));
            return customer;
        }

        public static Subscription MockSubscription(MockRepository mocks)
        {
            var subscription = mocks.DynamicMock<Subscription>();
            SetupResult.For(subscription.Transaction).Return(new InstallmentTransaction(AnyDatePeriod(), 5, AnyString(),
                                                                                        AnyString(), 0, 0));
            return subscription;
        }

        public static Subscription Subscription()
        {
            return new Subscription(AnyString(), AnyString(), default(DateTime), 12, 200, 20, 0);
        }

        public static Subscription SubscriptionForAmount(decimal amount)
        {
            return new Subscription(AnyString(), AnyString(), AnyDate(), 12, amount, 20, 0);
        }

        public static Subscription SubscriptionEndingOn(DateTime date)
        {
            return new Subscription(AnyString(), AnyString(), date.AddMonths(-12).AddDays(1), 12, 200, 20, 4);
        }

        public static Subscription SubscriptionThatHasBeenRenewed(Customer customer)
        {
            DateTime end = AnyDate();
            Subscription subscription = SubscriptionEndingOn(end);
            customer.AddSubscription(subscription);
            subscription.CheckRenewal(customer, end);
            return subscription;
        }

        public static DatePeriod AnyDatePeriodForMonths(int months)
        {
            DateTime start = AnyDate();
            return new DatePeriod(start, start.AddMonths(months).AddDays(-1));
        }

        public static Installment InstallmentForAmount(decimal amount)
        {
            return new Installment(AnyDate(), default(DateTime), amount, new AccountChargeTransaction());
        }

        public static BaseTransaction TransactionOnDate(DateTime date)
        {
            return new BaseTransaction(date, 10, string.Empty, string.Empty);
        }

        public static IList<T> MergedList<T>(params IEnumerable<T>[] lists)
        {
            var result = new List<T>();
            foreach (IEnumerable<T> list in lists)
            {
                result.AddRange(list);
            }
            return result;
        }

        public static Installment InstallmentBillableOnDate(DateTime date)
        {
            return new Installment(default(DateTime), date, 100, null);
        }

        public static IList<Installment> InstallmentsWithPositiveBalance()
        {
            return new[] {InstallmentForAmount(Statement.MinimumForInvoice + 10)};
        }

        public static BaseTransaction TransactionForInvoice()
        {
            return new AccountChargeTransaction();
        }

        public static Invoice InvoicePaid(MockRepository mocks)
        {
            var customer = new Customer();
            var gateway = mocks.DynamicMock<IPaymentGateway>();
            var result = mocks.DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(true);
            SetupResult.For(result.RawMessage).Return(AnyString());
            SetupResult.For(gateway.MakePayment(customer, 0)).Return(result);
            mocks.ReplayAll();

            Invoice invoice = InvoiceForCustomer(customer);
            invoice.Pay(AnyDate(), gateway);
            mocks.BackToRecordAll();
            return invoice;
        }

        public static DateTime UniqueDate()
        {
            return AnyDate().AddDays(_uniqueDateIndex++);
        }

        public static Invoice InvoiceForCustomerWithTotal(Customer customer, decimal total)
        {
            Invoice invoice = InvoiceForCustomer(customer);
            invoice.AddLineItem(new InvoiceLineItem(AnyDate(), AnyString(), AnyString(), null, total));
            return invoice;
        }

        public static Iesi.Collections.Generic.ISet<T> Set<T>(params T[] items)
        {
            return new HashedSet<T>(items);
        }

        public static string UniqueEmailAddress()
        {
            return "awww" + _uniqueEmailIndex++ + "@intrigma.com";
        }

        public static Customer CustomerWithEmailAddress()
        {
            return new Customer {EmailAddress = AnyEmailAddress()};
        }
    }
}