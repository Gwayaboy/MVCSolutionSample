using System;
using NUnit.Framework;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class AccountChargeTransactionTests
    {
        [Test]
        public void ConstructWithAmount()
        {
            decimal amount = 36.5m;
            var target = new AccountChargeTransaction(Create.AnyDate(), amount, null, null);
            Assert.That(target.Amount, Is.EqualTo(amount));
        }

        [Test]
        public void ConstructWithDate()
        {
            DateTime date = Create.AnyDate();
            var target = new AccountChargeTransaction(date, 0, null, null);
            Assert.That(target.Date, Is.EqualTo(date));
        }

        [Test]
        public void ConstructWithDescription()
        {
            string description = Create.AnyString();
            var target = new AccountChargeTransaction(Create.AnyDate(), 0, null, description);
            Assert.That(target.Description, Is.EqualTo(description));
        }

        [Test]
        public void ConstructWithName()
        {
            string name = Create.AnyString();
            var target = new AccountChargeTransaction(Create.AnyDate(), 0, name, null);
            Assert.That(target.Name, Is.EqualTo(name));
        }

        [Test]
        public void IsAnAccountTransaction()
        {
            Assert.That(new AccountChargeTransaction(), Is.InstanceOf<BaseAccountTransaction>());
        }

        [Test]
        public void ShowOnInvoice()
        {
            Assert.That(new AccountChargeTransaction().ShowOnInvoice, Is.True);
        }
    }
}