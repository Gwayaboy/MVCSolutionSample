using System;
using NUnit.Framework;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class AccountCreditTransactionTests
    {
        [Test]
        public void ConstructWithDate()
        {
            DateTime date = Create.AnyDate();
            var target = new AccountCreditTransaction(date, 0, null);
            Assert.That(target.Date, Is.EqualTo(date));
        }

        [Test]
        public void ConstructWithName()
        {
            var target = new AccountCreditTransaction(Create.AnyDate(), 0, null);
            Assert.That(target.Name, Is.EqualTo(AccountCreditTransaction.DefaultName));
        }

        [Test]
        public void ConstructWithReason()
        {
            string reason = Create.AnyString();
            var target = new AccountCreditTransaction(Create.AnyDate(), 0, reason);
            Assert.That(target.Description, Is.EqualTo(reason));
        }

        [Test]
        public void ConstructingWithAnAmountNegatesIt()
        {
            decimal amount = 36.5m;
            var target = new AccountCreditTransaction(Create.AnyDate(), amount, null);
            Assert.That(target.Amount, Is.EqualTo(-amount));
        }

        [Test]
        public void IsAnAccountTransaction()
        {
            Assert.That(new AccountCreditTransaction(), Is.InstanceOf<BaseTransaction>());
        }
    }
}