using System;
using NUnit.Framework;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class InstallmentTests : MockTestFixture
    {
        [Test]
        public void ConstructWithAmount()
        {
            decimal amount = 2536;
            Assert.That(new Installment(default(DateTime), default(DateTime), amount, null).Amount, Is.EqualTo(amount));
        }

        [Test]
        public void ConstructWithBillableDate()
        {
            DateTime billableDate = Create.AnyDate();
            Assert.That(new Installment(default(DateTime), billableDate, 0, null).BillableDate, Is.EqualTo(billableDate));
        }

        [Test]
        public void ConstructWithDueDate()
        {
            DateTime dueDate = Create.AnyDate();
            Assert.That(new Installment(dueDate, default(DateTime), 0, null).DueDate, Is.EqualTo(dueDate));
        }

        [Test]
        public void ConstructWithTransaction()
        {
            var tx = new BaseTransaction();
            Assert.That(new Installment(default(DateTime), default(DateTime), 0, tx).Transaction, Is.SameAs(tx));
        }

        [Test]
        public void ToStringFormat()
        {
            decimal amount = 45.65m;
            DateTime dueDate = Create.AnyDate();
            Assert.That(new Installment(dueDate, default(DateTime), amount, null).ToString(),
                        Is.EqualTo(string.Format(Installment.ToStringFormat, amount, dueDate)));
        }
    }
}