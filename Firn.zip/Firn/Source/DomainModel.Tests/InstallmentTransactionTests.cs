using System;
using NUnit.Framework;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class InstallmentTransactionTests : MockTestFixture
    {
        [Test]
        public void CalculateInstallmentsWithThreePayments()
        {
            DatePeriod period = Create.AnyDatePeriodForMonths(9);
            var target = new InstallmentTransaction(period, 90, string.Empty, string.Empty, 0, 0);
            Assert.That(target.CalculateInstallments(3),
                        Is.EqualTo(new[]
                                       {
                                           new Installment(period.Start, period.Start, 30, target),
                                           new Installment(period.Start.AddMonths(3), period.Start.AddMonths(3), 30, target)
                                           ,
                                           new Installment(period.Start.AddMonths(6), period.Start.AddMonths(6), 30, target)
                                           ,
                                       }));
        }

        [Test]
        public void CalculateInstallmentsWithThreeUnequalPayments()
        {
            DatePeriod period = Create.AnyDatePeriodForMonths(9);
            var target = new InstallmentTransaction(period, 20, string.Empty, string.Empty, 0, 0);
            Assert.That(target.CalculateInstallments(3),
                        Is.EqualTo(new[]
                                       {
                                           new Installment(period.Start, period.Start, 6.67m, target),
                                           new Installment(period.Start.AddMonths(3), period.Start.AddMonths(3), 6.67m,
                                                           target),
                                           new Installment(period.Start.AddMonths(6), period.Start.AddMonths(6), 6.66m,
                                                           target),
                                       }));
        }

        [Test]
        public void CalculateInstallmentsWithTwoPayments()
        {
            DatePeriod period = Create.AnyDatePeriodForMonths(8);
            var target = new InstallmentTransaction(period, 100, string.Empty, string.Empty, 0, 0);
            Assert.That(target.CalculateInstallments(4),
                        Is.EqualTo(new[]
                                       {
                                           new Installment(period.Start, period.Start, 50, target),
                                           new Installment(period.Start.AddMonths(4), period.Start.AddMonths(4), 50, target)
                                           ,
                                       }));
        }

        [Test]
        public void CalculateInstallmentsWithTwoPaymentsAndDifferentBillableDate()
        {
            DatePeriod period = Create.AnyDatePeriodForMonths(8);
            int weeksBefore = 2;
            var target = new InstallmentTransaction(period, 100, string.Empty, string.Empty, 0, weeksBefore);
            Assert.That(target.CalculateInstallments(4),
                        Is.EqualTo(new[]
                                       {
                                           new Installment(period.Start,
                                                           period.Start - TimeSpan.FromDays(7 * weeksBefore), 50, target)
                                           ,
                                           new Installment(period.Start.AddMonths(4),
                                                           period.Start.AddMonths(4) -
                                                           TimeSpan.FromDays(7 * weeksBefore), 50, target),
                                       }));
        }

        [Test]
        public void ConstructWithAmount()
        {
            decimal amount = 2345.5m;
            var target = new InstallmentTransaction(Create.AnyDatePeriod(), amount, null, null, 0, 0);
            Assert.That(target.Amount, Is.EqualTo(amount));
        }

        [Test]
        public void ConstructWithBillableWeeksBefore()
        {
            int weeksBefore = 345;
            var target = new InstallmentTransaction(Create.AnyDatePeriod(), 0, null, null, 0, weeksBefore);
            Assert.That(target.BillableWeeksBefore, Is.EqualTo(weeksBefore));
        }

        [Test]
        public void ConstructWithDate()
        {
            DateTime start = Create.AnyDate();
            var target = new InstallmentTransaction(new DatePeriod(start, start.AddDays(1)), 0, null, null, 0, 0);
            Assert.That(target.Date, Is.EqualTo(start));
        }

        [Test]
        public void ConstructWithDescription()
        {
            string desc = Create.AnyString();
            var target = new InstallmentTransaction(Create.AnyDatePeriod(), 0, null, desc, 0, 0);
            Assert.That(target.Description, Is.EqualTo(desc));
        }

        [Test]
        public void ConstructWithName()
        {
            string name = Create.AnyString();
            var target = new InstallmentTransaction(Create.AnyDatePeriod(), 0, name, null, 0, 0);
            Assert.That(target.Name, Is.EqualTo(name));
        }

        [Test]
        public void ConstructWithPeriod()
        {
            DatePeriod period = Create.AnyDatePeriod();
            var target = new InstallmentTransaction(period, 0, null, null, 0, 0);
            Assert.That(target.Period, Is.EqualTo(period));
        }

        [Test]
        public void ConstructWithStaffCount()
        {
            int value = 346;
            var target = new InstallmentTransaction(Create.AnyDatePeriod(), 0, string.Empty, string.Empty, value, 0);
            Assert.That(target.StaffCount, Is.EqualTo(value));
        }

        [Test]
        public void IsAnAccountTransaction()
        {
            Assert.That(new InstallmentTransaction(), Is.InstanceOf<BaseAccountTransaction>());
        }

        [Test]
        public void ShowOnInvoice()
        {
            Assert.That(new InstallmentTransaction().ShowOnInvoice, Is.True);
        }
    }
}