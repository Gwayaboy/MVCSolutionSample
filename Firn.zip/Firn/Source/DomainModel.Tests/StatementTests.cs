using System;
using NUnit.Framework;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class StatementTests
    {
        [Test]
        public void CalculateBalance()
        {
            var installments = new[] {Create.InstallmentForAmount(40), Create.InstallmentForAmount(-10)};
            var target = new Statement(null, default(DateTime), installments);
            Assert.That(target.CurrentBalance, Is.EqualTo(installments[0].Amount + installments[1].Amount));
        }

        [Test]
        public void CalculateBalanceWithNoItems()
        {
            var target = new Statement(null, default(DateTime), new Installment[0]);
            Assert.That(target.CurrentBalance, Is.EqualTo(0m));
        }

        [Test]
        public void ConstructWithCustomer()
        {
            var customer = new Customer();
            var target = new Statement(customer, default(DateTime), new Installment[0]);
            Assert.That(target.Customer, Is.SameAs(customer));
        }

        [Test]
        public void ConstructWithDate()
        {
            DateTime date = Create.AnyDate();
            var target = new Statement(null, date, new Installment[0]);
            Assert.That(target.Date, Is.EqualTo(date));
        }

        [Test]
        public void ConstructWithInstallments()
        {
            var installments = new[] {new Installment(), new Installment(),};
            var target = new Statement(null, default(DateTime), installments);
            Assert.That(target.Installments, Is.EqualTo(installments));
        }

        [Test]
        public void CreateInvoiceAndAddItemsInDescendingDateOrder()
        {
            DateTime date = Create.AnyDate();
            var installment1 = new Installment(date.AddDays(-1), default(DateTime), 15, Create.TransactionForInvoice());
            var installment2 = new Installment(date, default(DateTime), 20, Create.TransactionForInvoice());
            var target = new Statement(new Customer(), default(DateTime), new[] {installment1, installment2,});
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.LineItems[0].Price, Is.EqualTo(20));
        }

        [Test]
        public void CreateInvoiceAndDoNotIncludeCredits()
        {
            var installment1 = new Installment(Create.AnyDate(), default(DateTime), 15, Create.TransactionForInvoice());
            var installment2 = new Installment(Create.AnyDate(), default(DateTime), -5, Create.TransactionForInvoice());
            var target = new Statement(new Customer(), default(DateTime), new[] {installment1, installment2});
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.LineItems, Has.Count.EqualTo(1));
        }

        [Test]
        public void CreateInvoiceAndDoNotIncludeZeroItems()
        {
            var installment1 = new Installment(Create.AnyDate(), default(DateTime), 15, Create.TransactionForInvoice());
            var installment2 = new Installment(Create.AnyDate(), default(DateTime), 0, Create.TransactionForInvoice());
            var target = new Statement(new Customer(), default(DateTime), new[] {installment1, installment2});
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.LineItems, Has.Count.EqualTo(1));
        }

        [Test]
        public void CreateInvoiceAndIgnoreOtherTransactionsThatShouldNotBeShown()
        {
            decimal amount = 6;
            DateTime date = Create.AnyDate();
            var installment1 = new Installment(date.AddDays(1), default(DateTime), amount + 1,
                                               Create.TransactionForInvoice());
            var installment2 = new Installment(date, default(DateTime), amount, new AccountCreditTransaction());
            var target = new Statement(new Customer(), default(DateTime), new[] {installment1, installment2});
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.LineItems, Has.Count.EqualTo(1));
        }

        [Test]
        public void CreateInvoiceAndIgnoreRefunds()
        {
            decimal amount = 6;
            DateTime date = Create.AnyDate();
            var installment1 = new Installment(date.AddDays(1), default(DateTime), amount + 1,
                                               Create.TransactionForInvoice());
            var installment2 = new Installment(date, default(DateTime), amount, new RefundTransaction());
            var target = new Statement(new Customer(), default(DateTime), new[] {installment1, installment2});
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.LineItems, Has.Count.EqualTo(1));
        }

        [Test]
        public void CreateInvoiceAndQuitAddingItemsWhenYouHaveEnough()
        {
            DateTime date = Create.AnyDate();
            var installment1 = new Installment(date.AddDays(2), default(DateTime), 15, Create.TransactionForInvoice());
            var installment2 = new Installment(date.AddDays(1), default(DateTime), -5, Create.TransactionForInvoice());
            var installment3 = new Installment(date, default(DateTime), 20, Create.TransactionForInvoice());
            var installment4 = new Installment(date.AddDays(-1), default(DateTime), 2, Create.TransactionForInvoice());
            var target = new Statement(new Customer(), default(DateTime),
                                       new[] {installment1, installment2, installment3, installment4});
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.LineItems, Has.Count.EqualTo(2));
        }

        [Test]
        public void CreateInvoiceAndTruncateLastItemToMatchBalance()
        {
            DateTime date = Create.AnyDate();
            var installment1 = new Installment(date.AddDays(2), default(DateTime), 15, Create.TransactionForInvoice());
            var installment2 = new Installment(date.AddDays(1), default(DateTime), -5, Create.TransactionForInvoice());
            var installment3 = new Installment(date, default(DateTime), 20, Create.TransactionForInvoice());
            var target = new Statement(new Customer(), default(DateTime),
                                       new[] {installment1, installment2, installment3});
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.LineItems[1].Price, Is.EqualTo(15));
        }

        [Test]
        public void CreateInvoiceWithCustomer()
        {
            var customer = new Customer();
            var target = new Statement(customer, Create.AnyDate(), Create.InstallmentsWithPositiveBalance());
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.Customer, Is.SameAs(customer));
        }

        [Test]
        public void CreateInvoiceWithDate()
        {
            DateTime date = Create.AnyDate();
            var target = new Statement(new Customer(), date, Create.InstallmentsWithPositiveBalance());
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.InvoiceDate, Is.EqualTo(date));
        }

        [Test]
        public void CreateInvoiceWithDueDate()
        {
            DateTime date = Create.AnyDate();
            var target = new Statement(new Customer(), date, Create.InstallmentsWithPositiveBalance());
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.DueDate, Is.EqualTo(date + Statement.InvoiceGracePeriod));
        }

        [Test]
        public void CreateInvoiceWithId()
        {
            int id = 45;
            var target = new Statement(new Customer(), default(DateTime), Create.InstallmentsWithPositiveBalance());
            Invoice invoice = target.CreateInvoice(id);
            Assert.That(invoice.Id, Is.EqualTo(id));
        }

        [Test]
        public void CreateInvoiceWithOneItem()
        {
            decimal amount = 6;
            var installment = new Installment(Create.AnyDate(), default(DateTime), amount,
                                              Create.TransactionForInvoice());
            var target = new Statement(new Customer(), default(DateTime), new[] {installment});
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.LineItems, Has.Count.EqualTo(1));
        }

        [Test]
        public void CreateInvoiceWithOneItemAndSetAmount()
        {
            decimal amount = 6;
            var installment = new Installment(Create.AnyDate(), default(DateTime), amount,
                                              Create.TransactionForInvoice());
            var target = new Statement(new Customer(), default(DateTime), new[] {installment});
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.LineItems[0].Price, Is.EqualTo(amount));
        }

        [Test]
        public void CreateInvoiceWithOneItemAndSetDate()
        {
            DateTime date = Create.AnyDate();
            var installment = new Installment(date, default(DateTime), 50,
                                              new AccountChargeTransaction(Create.AnyDate(), 50, null, null));
            var target = new Statement(new Customer(), default(DateTime), new[] {installment});
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.LineItems[0].Date, Is.EqualTo(date));
        }

        [Test]
        public void CreateInvoiceWithOneItemAndSetDescription()
        {
            string description = Create.AnyString();
            var installment = new Installment(Create.AnyDate(), default(DateTime), 50,
                                              new AccountChargeTransaction(Create.AnyDate(), 50, null, description));
            var target = new Statement(new Customer(), default(DateTime), new[] {installment});
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.LineItems[0].Description, Is.EqualTo(description));
        }

        [Test]
        public void CreateInvoiceWithOneItemAndSetName()
        {
            string name = Create.AnyString();
            var installment = new Installment(Create.AnyDate(), default(DateTime), 50,
                                              new AccountChargeTransaction(Create.AnyDate(), 50, name, null));
            var target = new Statement(new Customer(), default(DateTime), new[] {installment});
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.LineItems[0].Name, Is.EqualTo(name));
        }

        [Test]
        public void CreateInvoiceWithOneItemAndSetStaffCount()
        {
            int staffCount = 56;
            var installment = new Installment(Create.AnyDate(), default(DateTime), 5,
                                              new InstallmentTransaction(Create.AnyDatePeriod(), 5, string.Empty,
                                                                         string.Empty, staffCount, 0));
            var target = new Statement(new Customer(), default(DateTime), new[] {installment});
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.LineItems[0].StaffCount, Is.EqualTo(staffCount));
        }

        [Test]
        public void CreateInvoiceWithTwoItemsAndSetAmount()
        {
            decimal amount = 6;
            DateTime date = Create.AnyDate();
            var installment1 = new Installment(date.AddDays(1), default(DateTime), amount + 1,
                                               Create.TransactionForInvoice());
            var installment2 = new Installment(date, default(DateTime), amount, Create.TransactionForInvoice());
            var target = new Statement(new Customer(), default(DateTime), new[] {installment1, installment2});
            Invoice invoice = target.CreateInvoice(0);
            Assert.That(invoice.LineItems[1].Price, Is.EqualTo(amount));
        }

        [Test]
        public void DoNotCreateInvoiceIfThereAreOnlyRefunds()
        {
            var installment1 = new Installment(Create.AnyDate(), default(DateTime), 50,
                                               new RefundTransaction(Create.AnyDate(), 50, null, default(BillingType)));
            var installment2 = new Installment(Create.AnyDate(), default(DateTime), 50,
                                               new RefundTransaction(Create.AnyDate(), 50, null, default(BillingType)));
            var target = new Statement(new Customer(), default(DateTime), new[] {installment1, installment2});
            Assert.That(target.CreateInvoice(0), Is.Null);
        }

        [Test]
        public void DoNotCreateInvoiceIfYouOnlyOweAFewPennies()
        {
            var target = new Statement(new Customer(), default(DateTime),
                                       new[] {Create.InstallmentForAmount(Statement.MinimumForInvoice - 0.01m)});
            Assert.That(target.CreateInvoice(0), Is.Null);
        }
    }
}