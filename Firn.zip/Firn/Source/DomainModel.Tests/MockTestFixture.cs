using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.DomainModel.Tests
{
    public class MockTestFixture
    {
        private MockRepository _mocks;

        protected MockRepository Mocks
        {
            get
            {
                if (_mocks == null)
                {
                    _mocks = new MockRepository();
                }
                return _mocks;
            }
        }

        [SetUp]
        public virtual void SetUp()
        {
            _mocks = null;
        }

        [TearDown]
        public virtual void TearDown()
        {
            if (_mocks != null)
            {
                _mocks.VerifyAll();
                // To avoid calls on mock objects throwing exceptions in Dispose methods:
                _mocks.BackToRecordAll();
                _mocks = null;
            }
        }

        public T[] CreateMocksArray<T>(int count) where T : class
        {
            var list = new T[count];
            for (int index = 0; index < count; index++)
            {
                list[index] = Mocks.DynamicMock<T>();
            }
            return list;
        }

        public T DynamicMock<T>() where T : class
        {
            return Mocks.DynamicMock<T>();
        }

        public void ReplayAll()
        {
            Mocks.ReplayAll();
        }
    }
}