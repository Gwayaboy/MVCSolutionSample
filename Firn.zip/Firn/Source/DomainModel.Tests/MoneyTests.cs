using NUnit.Framework;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class MoneyTests
    {
        [Test]
        public void ConstructWithAmount()
        {
            decimal amount = 2345.45m;
            Assert.That(new Money(amount).Amount, Is.EqualTo(amount));
        }

        [Test]
        public void SplitIntoFourParts()
        {
            Assert.That(new Money(10).SplitIntoParts(4),
                        Is.EqualTo(new[] {new Money(2.5m), new Money(2.5m), new Money(2.5m), new Money(2.5m),}));
        }

        [Test]
        public void SplitIntoThreeParts()
        {
            Assert.That(new Money(45).SplitIntoParts(3),
                        Is.EqualTo(new[] {new Money(15), new Money(15), new Money(15),}));
        }

        [Test]
        public void SplitIntoThreeUnequalParts()
        {
            Assert.That(new Money(10).SplitIntoParts(3),
                        Is.EqualTo(new[] {new Money(3.33m), new Money(3.33m), new Money(3.34m),}));
        }

        [Test]
        public void SplitIntoTwoParts()
        {
            Assert.That(new Money(20).SplitIntoParts(2), Is.EqualTo(new[] {new Money(10), new Money(10),}));
        }

        [Test]
        public void ToStringFormat()
        {
            decimal amount = 20.56m;
            Assert.That(new Money(amount).ToString(), Is.EqualTo(amount.ToString()));
        }

        [Test]
        public void ToStringWithFormatSpecifier()
        {
            decimal amount = 20.56m;
            Assert.That(new Money(amount).ToString("c"), Is.EqualTo(amount.ToString("c")));
        }
    }
}