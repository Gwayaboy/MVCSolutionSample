using NUnit.Framework;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class BaseTransactionTests
    {
        [Test]
        public void ConstructWithAmount()
        {
            var amount = 36.5m;
            var target = new BaseTransaction(Create.AnyDate(), amount, null, null);
            Assert.That(target.Amount, Is.EqualTo(amount));
        }

        [Test]
        public void ConstructWithDate()
        {
            var date = Create.AnyDate();
            var target = new BaseTransaction(date, 0, null, null);
            Assert.That(target.Date, Is.EqualTo(date));
        }

        [Test]
        public void ConstructWithDescription()
        {
            var description = Create.AnyString();
            var target = new BaseTransaction(Create.AnyDate(), 0, null, description);
            Assert.That(target.Description, Is.EqualTo(description));
        }

        [Test]
        public void ConstructWithName()
        {
            var name = Create.AnyString();
            var target = new BaseTransaction(Create.AnyDate(), 0, name, null);
            Assert.That(target.Name, Is.EqualTo(name));
        }

        [Test]
        public void DefaultStaffCountIsNull()
        {
            Assert.That(new BaseTransaction().StaffCount, Is.Null);
        }

        [Test]
        public void DoNotShowOnInvoice()
        {
            Assert.That(new BaseTransaction().ShowOnInvoice, Is.False);
        }

        [Test]
        public void OneInstallmentByDefault()
        {
            var target = new BaseTransaction(Create.AnyDate(), 44, string.Empty, string.Empty);
            Assert.That(target.CalculateInstallments(5),
                        Is.EqualTo(new[] {new Installment(target.Date, target.Date, target.Amount, target),}));
        }
    }
}