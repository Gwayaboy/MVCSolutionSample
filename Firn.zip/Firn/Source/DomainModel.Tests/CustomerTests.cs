using System;
using Intrigma.Firn.DomainModel.PaymentGateway;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class CustomerPaymentMethodTests : MockTestFixture
    {
        #region Setup/Teardown

        public override void SetUp()
        {
            base.SetUp();
            _gateway = DynamicMock<IPaymentGateway>();
        }

        #endregion

        private IPaymentGateway _gateway;

        [Test]
        public void GetPaymentMethod()
        {
            const int id = 345;
            var target = new Customer {BillingType = BillingType.Eft, PaymentMethodId = id};
            var paymentType = new PaymentType();
            SetupResult.For(_gateway.GetPaymentMethod(BillingType.Eft, id)).Return(paymentType);
            ReplayAll();

            Assert.That(target.GetPaymentMethod(_gateway), Is.SameAs(paymentType));
        }

        [Test]
        public void GetPaymentMethodButCustomerHasNone()
        {
            ReplayAll();

            var target = new Customer();
            Assert.That(target.GetPaymentMethod(_gateway), Is.Null);
        }

        [Test]
        public void UpdatePaymentMethodDeletesOldPaymentMethod()
        {
            var paymentType = new PaymentType();
            var target = new Customer();
            const int oldId = 2345;
            target.PaymentMethodId = oldId;
            const BillingType billingType = BillingType.CreditCard;
            _gateway.DeletePaymentMethod(oldId);
            ReplayAll();

            target.UpdatePaymentMethod(billingType, paymentType, _gateway);
        }

        [Test]
        public void UpdatePaymentMethodDoesNothingIfCreateFails()
        {
            var paymentType = new PaymentType();
            var target = new Customer();
            const BillingType billingType = BillingType.CreditCard;
            int? id = 345;
            target.PaymentMethodId = id;
            SetupResult.For(_gateway.CreatePaymentMethod(billingType, paymentType)).Throw(new Exception());
            ReplayAll();

            try
            {
                target.UpdatePaymentMethod(billingType, paymentType, _gateway);
            }
            catch
            {
                Assert.That(target.PaymentMethodId, Is.EqualTo(id));
            }
        }

        [Test]
        public void UpdatePaymentMethodSetToMailPayment()
        {
            var paymentType = new PaymentType();
            var target = new Customer();
            const BillingType billingType = BillingType.MailPayment;
            ReplayAll();

            target.UpdatePaymentMethod(billingType, paymentType, _gateway);
            Assert.That(target.PaymentMethodId, Is.Null);
        }

        [Test]
        public void UpdatePaymentMethodSetsBillingType()
        {
            var paymentType = new PaymentType();
            var target = new Customer();
            const BillingType billingType = BillingType.CreditCard;
            ReplayAll();

            target.UpdatePaymentMethod(billingType, paymentType, _gateway);
            Assert.That(target.BillingType, Is.EqualTo(billingType));
        }

        [Test]
        public void UpdatePaymentMethodSetsNewPaymentMethodId()
        {
            var paymentType = new PaymentType();
            var target = new Customer();
            const BillingType billingType = BillingType.CreditCard;
            const int id = 345;
            SetupResult.For(_gateway.CreatePaymentMethod(billingType, paymentType)).Return(id);
            ReplayAll();

            target.UpdatePaymentMethod(billingType, paymentType, _gateway);
            Assert.That(target.PaymentMethodId, Is.EqualTo(id));
        }
    }

    [TestFixture]
    public class CustomerSecondaryEmailAddressesTests : MockTestFixture
    {
        [Test]
        public void EmptyByDefault()
        {
            var target = new Customer();
            Assert.That(target.SecondaryEmailAddresses, Is.Empty);
        }

        [Test]
        public void IgnoreEmptyEmailAddresses()
        {
            var target = new Customer();
            target.SetSecondaryEmailAddresses(Create.Set(Create.AnyEmailAddress()));
            var value = Create.Set("   ", "\t");
            target.SetSecondaryEmailAddresses(value);
            Assert.That(target.SecondaryEmailAddresses, Is.Empty);
        }

        [Test]
        public void OneInvalidEmailAddressSoRejectUpdate()
        {
            var target = new Customer();
            target.SetSecondaryEmailAddresses(Create.Set("dan@", "dan+test@intrigma.com"));
            Assert.That(target.SecondaryEmailAddresses, Is.Empty);
        }

        [Test]
        public void ReturnErrorsForTwoInvalidEmailAddresses()
        {
            var target = new Customer();
            string[] items = {"dan+", "@intrigma.com"};
            Assert.That(target.SetSecondaryEmailAddresses(Create.Set(items)),
                        Is.EquivalentTo(new[]
                                            {
                                                string.Format(Customer.InvalidEmailAddressFormat, items[0]),
                                                string.Format(Customer.InvalidEmailAddressFormat, items[1])
                                            }));
        }

        [Test]
        public void SetTwoValidEmailAddresses()
        {
            var target = new Customer();
            var value = Create.Set("dan@intrigma.com", "chris@intrigma.com");
            target.SetSecondaryEmailAddresses(value);
            Assert.That(target.SecondaryEmailAddresses, Is.EqualTo(value));
        }

        [Test]
        public void TrimWhitespace()
        {
            var target = new Customer();
            target.SetSecondaryEmailAddresses(Create.Set(Create.AnyEmailAddress()));
            var email = Create.AnyEmailAddress();
            target.SetSecondaryEmailAddresses(Create.Set("   " + email));
            Assert.That(target.SecondaryEmailAddresses, Is.EqualTo(new[] {email}));
        }
    }

    [TestFixture]
    public class CustomerTests : MockTestFixture
    {
        private delegate void CheckRenewalDelegate(Customer customer, DateTime date);

        [Test]
        public void AddAccountChargeAddsTransactionAmount()
        {
            var target = new Customer();
            const decimal amount = 345.56m;
            target.AddAccountCharge(default(DateTime), null, null, amount);
            Assert.That(target.Transactions[0].Amount, Is.EqualTo(amount));
        }

        [Test]
        public void AddAccountChargeAddsTransactionDate()
        {
            var target = new Customer();
            var date = Create.AnyDate();
            target.AddAccountCharge(date, null, null, 5);
            Assert.That(target.Transactions[0].Date, Is.EqualTo(date));
        }

        [Test]
        public void AddAccountChargeAddsTransactionDescription()
        {
            var target = new Customer();
            var description = Create.AnyString();
            target.AddAccountCharge(default(DateTime), null, description, 5);
            Assert.That(target.Transactions[0].Description, Is.EqualTo(description));
        }

        [Test]
        public void AddAccountChargeAddsTransactionName()
        {
            var target = new Customer();
            var name = Create.AnyString();
            target.AddAccountCharge(default(DateTime), name, null, 5);
            Assert.That(target.Transactions[0].Name, Is.EqualTo(name));
        }

        [Test]
        public void AddAccountChargeAddsTransactionOfCorrectType()
        {
            var target = new Customer();
            target.AddAccountCharge(default(DateTime), null, null, 0);
            Assert.That(target.Transactions[0], Is.InstanceOf<AccountChargeTransaction>());
        }

        [Test]
        public void AddAccountChargeUpdatesBalance()
        {
            const decimal starting = 2346;
            var target = Create.CustomerWithBalance(starting);
            const decimal amount = 345.56m;
            target.AddAccountCharge(default(DateTime), null, null, amount);
            Assert.That(target.EndingBalance, Is.EqualTo(starting + amount));
        }

        [Test]
        public void AddAccountCreditAddsCorrectTransactionType()
        {
            var target = new Customer();
            target.AddAccountCredit(default(DateTime), 0, null);
            Assert.That(target.Transactions[0], Is.InstanceOf<AccountCreditTransaction>());
        }

        [Test]
        public void AddAccountCreditSetsReason()
        {
            var reason = Create.AnyString();
            var target = new Customer();
            target.AddAccountCredit(default(DateTime), 11, reason);
            Assert.That(target.Transactions[0].Description, Is.EqualTo(reason));
        }

        [Test]
        public void AddAccountCreditSetsTransactionAmount()
        {
            const decimal amount = 56;
            var target = new Customer();
            target.AddAccountCredit(default(DateTime), amount, null);
            Assert.That(target.Transactions[0].Amount, Is.EqualTo(-amount));
        }

        [Test]
        public void AddAccountCreditSetsTransactionDate()
        {
            var date = Create.AnyDate();
            var target = new Customer();
            target.AddAccountCredit(date, 23465, null);
            Assert.That(target.Transactions[0].Date, Is.EqualTo(date));
        }

        [Test]
        public void AddAccountCreditUpdatesBalance()
        {
            const decimal amount = 277;
            const decimal starting = 346;
            var target = Create.CustomerWithBalance(starting);
            target.AddAccountCredit(default(DateTime), amount, null);
            Assert.That(target.EndingBalance, Is.EqualTo(starting - amount));
        }

        [Test]
        public void AddInvoicePushesNextInvoiceDateForwardOneMonth()
        {
            var customer = new Customer {BillingPeriod = BillingPeriod.Monthly};
            var date = Create.AnyDate();
            new Invoice(customer, 4, date, default(DateTime));
            Assert.That(customer.NextInvoiceDate, Is.EqualTo(date.AddMonths(1)));
        }

        [Test]
        public void AddInvoicePushesNextInvoiceDateForwardSixMonths()
        {
            var customer = new Customer {BillingPeriod = BillingPeriod.Semiannually};
            var date = Create.AnyDate();
            new Invoice(customer, 4, date, default(DateTime));
            Assert.That(customer.NextInvoiceDate, Is.EqualTo(date.AddMonths(6)));
        }

        [Test]
        public void AddSubscriptionAddsToCollection()
        {
            var subscription = Create.Subscription();
            var target = new Customer();
            target.AddSubscription(subscription);
            Assert.That(target.Subscriptions, Is.EqualTo(new[] {subscription}));
        }

        [Test]
        public void AddSubscriptionAddsTransaction()
        {
            var subscription = Create.Subscription();
            var target = new Customer();
            target.AddSubscription(subscription);
            Assert.That(target.Transactions, Is.EqualTo(new BaseTransaction[] {subscription.Transaction}));
        }

        [Test]
        public void AddSubscriptionUpdatesBalance()
        {
            const decimal amount = 345;
            var subscription = Create.SubscriptionForAmount(amount);
            const decimal starting = 2345;
            var target = Create.CustomerWithBalance(starting);
            target.AddSubscription(subscription);
            Assert.That(target.EndingBalance, Is.EqualTo(starting + amount));
        }

        [Test]
        public void AddTransactionAddsAmountToCurrentBalance()
        {
            const decimal starting = 3245;
            const decimal txAmount = 34;
            var accountTransaction = new BaseTransaction(Create.AnyDate(), txAmount, null, null);
            var target = Create.CustomerWithBalance(starting);

            target.AddTransaction(accountTransaction);
            Assert.That(target.EndingBalance, Is.EqualTo(starting + txAmount));
        }

        [Test]
        public void AddTransactionRecordsIt()
        {
            var accountTransaction = new BaseTransaction(Create.AnyDate(), 4356, null, null);
            var target = new Customer();
            target.AddTransaction(accountTransaction);
            Assert.That(target.Transactions, Is.EqualTo(new[] {accountTransaction}));
        }

        [Test]
        public void AddressWithAllFields()
        {
            var target = new Customer
                             {
                                 StreetAddress1 = "34534534",
                                 StreetAddress2 = "x ave.",
                                 City = "lebanon",
                                 State = "is not a country, apparently",
                                 Zip = "010101"
                             };
            var expected = string.Format(Customer.AddressFormat, target.StreetAddress1 + "\n" + target.StreetAddress2,
                                         target.City, target.State, target.Zip);
            Assert.That(target.Address, Is.EqualTo(expected));
        }

        [Test]
        public void AddressWithoutLine2()
        {
            var target = new Customer
                             {
                                 StreetAddress1 = "34534534",
                                 City = "lebanon",
                                 State = "is not a country, apparently",
                                 Zip = "010101"
                             };
            var expected = string.Format(Customer.AddressFormat, target.StreetAddress1, target.City, target.State,
                                         target.Zip);
            Assert.That(target.Address, Is.EqualTo(expected));
        }

        [Test]
        public void AttnFirstName()
        {
            var target = new Customer();
            const string value = "cute test string of my own";
            target.AttnFirstName = value;
            Assert.That(target.AttnFirstName, Is.EqualTo(value));
        }

        [Test]
        public void AttnFullName()
        {
            var target = new Customer {AttnFirstName = Create.AnyString(), AttnLastName = Create.AnyString()};
            Assert.That(target.AttnFullName,
                        Is.EqualTo(string.Format(Customer.FullNameFormat, target.AttnFirstName, target.AttnLastName)));
        }

        [Test]
        public void AttnLastName()
        {
            var target = new Customer();
            const string value = "cute test string of my own";
            target.AttnLastName = value;
            Assert.That(target.AttnLastName, Is.EqualTo(value));
        }

        [Test]
        public void BalanceAsOfWithNoTransactions()
        {
            var target = new Customer();
            Assert.That(target.BalanceAsOf(Create.AnyDate()), Is.EqualTo(0));
        }

        [Test]
        public void BalanceAsOfWithTwoTransactions()
        {
            var start = Create.AnyDate();
            var target = new Customer();
            target.AddTransaction(new BaseTransaction(start, 5, null, null));
            target.AddTransaction(new BaseTransaction(start.AddDays(1), 10, null, null));
            target.AddTransaction(new BaseTransaction(start.AddDays(2), 20, null, null));
            Assert.That(target.BalanceAsOf(start.AddDays(1)), Is.EqualTo(15));
        }

        [Test]
        public void BillingNotes()
        {
            var target = new Customer();
            const string value = "cute test string of my own";
            target.BillingNotes = value;
            Assert.That(target.BillingNotes, Is.EqualTo(value));
        }

        [Test]
        public void BillingStartDate()
        {
            var target = new Customer();
            var value = Create.AnyDate();
            target.BillingStartDate = value;
            Assert.That(target.BillingStartDate, Is.EqualTo(value));
        }

        [Test]
        public void CanAutoChargePayments()
        {
            var target = new Customer {BillingType = BillingType.Eft};
            Assert.That(target.CanAutomaticallyChargePayments, Is.True);
        }

        [Test]
        public void CanSendMailWithAddress()
        {
            var target = new Customer {EmailAddress = Create.AnyEmailAddress()};
            Assert.That(target.CanSendEmail, Is.True);
        }

        [Test]
        public void CannotAutoChargePayments()
        {
            var target = new Customer();
            Assert.That(target.CanAutomaticallyChargePayments, Is.False);
        }

        [Test]
        public void CannotDirectlyAddToInvoicesCollection()
        {
            var target = new Customer();
            Assert.That(() => target.Invoices.Add(new Invoice()), Throws.Exception);
        }

        [Test]
        public void CannotSendMailWithNoAddress()
        {
            var target = new Customer();
            Assert.That(target.CanSendEmail, Is.False);
        }

        [Test]
        public void CheckSubscriptionRenewals()
        {
            var target = new Customer();
            var sub1 = Create.MockSubscription(Mocks);
            var sub2 = Create.MockSubscription(Mocks);
            var date = Create.AnyDate();
            sub1.CheckRenewal(target, date);
            sub2.CheckRenewal(target, date);
            ReplayAll();

            target.AddSubscription(sub1);
            target.AddSubscription(sub2);
            target.CheckSubscriptionRenewals(date);
        }

        [Test]
        public void CheckSubscriptionRenewalsAndCollectionModified()
        {
            var target = new Customer();
            var sub1 = Create.MockSubscription(Mocks);
            var sub2 = Create.MockSubscription(Mocks);
            var date = Create.AnyDate();
            sub1.CheckRenewal(target, date);
            LastCall.Do((CheckRenewalDelegate) delegate { target.AddSubscription(Create.Subscription()); });
            ReplayAll();

            target.AddSubscription(sub1);
            target.AddSubscription(sub2);
            target.CheckSubscriptionRenewals(date);
        }

        [Test]
        public void City()
        {
            var target = new Customer();
            const string city = "cute test string of my own";
            target.City = city;
            Assert.That(target.City, Is.EqualTo(city));
        }

        [Test]
        public void CreateStatementIgnoringItemsInTheFuture()
        {
            var date = Create.AnyDate();
            var tx = DynamicMock<BaseTransaction>();
            var installments = new[]
                                   {
                                       Create.InstallmentBillableOnDate(date.AddDays(1)),
                                       Create.InstallmentBillableOnDate(date)
                                   };
            SetupResult.For(tx.CalculateInstallments(3)).Return(installments);
            var target = new Customer();
            ReplayAll();

            target.BillingPeriod = BillingPeriod.Quarterly;
            target.AddTransaction(tx);
            var statement = target.CreateStatement(date);
            Assert.That(statement.Installments, Is.EqualTo(new[] {installments[1]}));
        }

        [Test]
        public void CreateStatementWithCorrectBillingPeriod()
        {
            var date = Create.AnyDate();
            var tx = DynamicMock<BaseTransaction>();
            var installments = new[] {Create.InstallmentBillableOnDate(date)};
            SetupResult.For(tx.CalculateInstallments(3)).Return(installments);
            var target = new Customer();
            ReplayAll();

            target.BillingPeriod = BillingPeriod.Quarterly;
            target.AddTransaction(tx);
            var statement = target.CreateStatement(date);
            Assert.That(statement.Installments, Is.EqualTo(installments));
        }

        [Test]
        public void CreateStatementWithCustomer()
        {
            var target = new Customer();
            var statement = target.CreateStatement(Create.AnyDate());
            Assert.That(statement.Customer, Is.SameAs(target));
        }

        [Test]
        public void CreateStatementWithDate()
        {
            var date = Create.AnyDate();
            var target = new Customer();
            var statement = target.CreateStatement(date);
            Assert.That(statement.Date, Is.EqualTo(date));
        }

        [Test]
        public void CreateStatementWithNoItems()
        {
            var target = new Customer();
            var statement = target.CreateStatement(Create.AnyDate());
            Assert.That(statement.Installments, Is.Empty);
        }

        [Test]
        public void CreateStatementWithTwoItems()
        {
            var date = Create.AnyDate();
            var tx1 = Create.TransactionOnDate(date);
            var tx2 = Create.TransactionOnDate(date.AddDays(-1));
            var target = new Customer {BillingPeriod = BillingPeriod.Semiannually};
            target.AddTransaction(tx1);
            target.AddTransaction(tx2);
            var statement = target.CreateStatement(date);
            Assert.That(statement.Installments,
                        Is.EqualTo(Create.MergedList(tx1.CalculateInstallments(6), tx2.CalculateInstallments(6))));
        }

        [Test]
        public void DefaultBillingPeriod()
        {
            var target = new Customer();
            Assert.That(target.BillingPeriod, Is.EqualTo(BillingPeriod.Yearly));
        }

        [Test]
        public void DefaultBillingStartDate()
        {
            var target = new Customer();
            Assert.That(target.BillingStartDate, Is.Null);
        }

        [Test]
        public void DefaultBillingType()
        {
            var target = new Customer();
            Assert.That(target.BillingType, Is.EqualTo(BillingType.MailPayment));
        }

        [Test]
        public void DefaultCurrentBalance()
        {
            var target = new Customer();
            Assert.That(target.EndingBalance, Is.EqualTo(0));
        }

        [Test]
        public void DefaultNextInvoiceDate()
        {
            var target = new Customer();
            Assert.That(target.NextInvoiceDate, Is.Null);
        }

        [Test]
        public void Email()
        {
            var target = new Customer();
            const string email = "cute test string of my own";
            target.EmailAddress = email;
            Assert.That(target.EmailAddress, Is.EqualTo(email));
        }

        [Test]
        public void IssueRefundAddsTransactionForAmountOnSuccess()
        {
            var target = new Customer();
            var gateway = DynamicMock<IPaymentGateway>();
            const decimal amount = 2435.45m;
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(true);
            SetupResult.For(gateway.IssueRefund(target, amount)).Return(result);
            ReplayAll();

            target.IssueRefund(default(DateTime), amount, null, gateway);
            Assert.That(target.Transactions[0].Amount, Is.EqualTo(amount));
        }

        [Test]
        public void IssueRefundAddsTransactionForDateOnSuccess()
        {
            var target = new Customer();
            var gateway = DynamicMock<IPaymentGateway>();
            const decimal amount = 2435.45m;
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(true);
            SetupResult.For(gateway.IssueRefund(target, amount)).Return(result);
            var date = Create.AnyDate();
            ReplayAll();

            target.IssueRefund(date, amount, null, gateway);
            Assert.That(target.Transactions[0].Date, Is.EqualTo(date));
        }

        [Test]
        public void IssueRefundAddsTransactionWithBillingTypeOnSuccess()
        {
            var target = new Customer {BillingType = Create.NonDefaultBillingType()};
            var gateway = DynamicMock<IPaymentGateway>();
            const decimal amount = 2435.45m;
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(true);
            SetupResult.For(gateway.IssueRefund(target, amount)).Return(result);
            ReplayAll();

            target.IssueRefund(default(DateTime), amount, null, gateway);
            var transaction = (RefundTransaction) target.Transactions[0];
            Assert.That(transaction.Type, Is.EqualTo(target.BillingType));
        }

        [Test]
        public void IssueRefundAddsTransactionWithReasonOnSuccess()
        {
            var target = new Customer();
            var gateway = DynamicMock<IPaymentGateway>();
            const decimal amount = 2435.45m;
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(true);
            SetupResult.For(gateway.IssueRefund(target, amount)).Return(result);
            ReplayAll();

            var reason = Create.AnyString();
            target.IssueRefund(default(DateTime), amount, reason, gateway);
            Assert.That(target.Transactions[0].Description, Is.EqualTo(reason));
        }

        [Test]
        public void IssueRefundDoesNotAddTransactionOnFailure()
        {
            var target = new Customer();
            var gateway = DynamicMock<IPaymentGateway>();
            const decimal amount = 2435.45m;
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(false);
            SetupResult.For(gateway.IssueRefund(target, amount)).Return(result);
            ReplayAll();

            target.IssueRefund(default(DateTime), amount, null, gateway);
            Assert.That(target.Transactions, Is.Empty);
        }

        [Test]
        public void IssueRefundSendsGatewayCommandAndReturnsResult()
        {
            var target = new Customer();
            var gateway = DynamicMock<IPaymentGateway>();
            const decimal amount = 2435.45m;
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(gateway.IssueRefund(target, amount)).Return(result);
            ReplayAll();

            Assert.That(target.IssueRefund(default(DateTime), amount, null, gateway), Is.SameAs(result));
        }

        [Test]
        public void IssueRefundUpdatesBalanceOnSuccess()
        {
            const decimal starting = 234;
            var target = Create.CustomerWithBalance(starting);
            var gateway = DynamicMock<IPaymentGateway>();
            const decimal amount = 2435.45m;
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(true);
            SetupResult.For(gateway.IssueRefund(target, amount)).Return(result);
            ReplayAll();

            target.IssueRefund(default(DateTime), amount, null, gateway);
            Assert.That(target.EndingBalance, Is.EqualTo(starting + amount));
        }

        [Test]
        public void MakePaymentAddsTransactionForAmountOnSuccess()
        {
            var target = new Customer();
            var gateway = DynamicMock<IPaymentGateway>();
            const decimal amount = 2435.45m;
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(true);
            SetupResult.For(gateway.MakePayment(target, amount)).Return(result);
            ReplayAll();

            target.MakePayment(default(DateTime), amount, gateway);
            Assert.That(target.Transactions[0].Amount, Is.EqualTo(-amount));
        }

        [Test]
        public void MakePaymentAddsTransactionForDateOnSuccess()
        {
            var target = new Customer();
            var gateway = DynamicMock<IPaymentGateway>();
            const decimal amount = 2435.45m;
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(true);
            SetupResult.For(gateway.MakePayment(target, amount)).Return(result);
            var date = Create.AnyDate();
            ReplayAll();

            target.MakePayment(date, amount, gateway);
            Assert.That(target.Transactions[0].Date, Is.EqualTo(date));
        }

        [Test]
        public void MakePaymentAddsTransactionWithBillingTypeOnSuccess()
        {
            var target = new Customer {BillingType = Create.NonDefaultBillingType()};
            var gateway = DynamicMock<IPaymentGateway>();
            const decimal amount = 2435.45m;
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(true);
            SetupResult.For(gateway.MakePayment(target, amount)).Return(result);
            ReplayAll();

            target.MakePayment(default(DateTime), amount, gateway);
            var transaction = (PaymentTransaction) target.Transactions[0];
            Assert.That(transaction.Type, Is.EqualTo(target.BillingType));
        }

        [Test]
        public void MakePaymentDoesNotAddTransactionOnFailure()
        {
            var target = new Customer();
            var gateway = DynamicMock<IPaymentGateway>();
            const decimal amount = 2435.45m;
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(false);
            SetupResult.For(gateway.MakePayment(target, amount)).Return(result);
            ReplayAll();

            target.MakePayment(default(DateTime), amount, gateway);
            Assert.That(target.Transactions, Is.Empty);
        }

        [Test]
        public void MakePaymentSendsGatewayCommandAndReturnsResult()
        {
            var target = new Customer();
            var gateway = DynamicMock<IPaymentGateway>();
            const decimal amount = 2435.45m;
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(gateway.MakePayment(target, amount)).Return(result);
            ReplayAll();

            Assert.That(target.MakePayment(default(DateTime), amount, gateway), Is.SameAs(result));
        }

        [Test]
        public void MakePaymentUpdatesBalanceOnSuccess()
        {
            const decimal starting = 234;
            var target = Create.CustomerWithBalance(starting);
            var gateway = DynamicMock<IPaymentGateway>();
            const decimal amount = 2435.45m;
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(true);
            SetupResult.For(gateway.MakePayment(target, amount)).Return(result);
            ReplayAll();

            target.MakePayment(default(DateTime), amount, gateway);
            Assert.That(target.EndingBalance, Is.EqualTo(starting - amount));
        }

        [Test]
        public void Name()
        {
            var target = new Customer();
            const string name = "cute test string of my own";
            target.Name = name;
            Assert.That(target.Name, Is.EqualTo(name));
        }

        [Test]
        public void NextInvoiceDate()
        {
            var target = new Customer();
            var value = Create.AnyDate();
            target.NextInvoiceDate = value;
            Assert.That(target.NextInvoiceDate, Is.EqualTo(value));
        }

        [Test]
        public void NextSteps()
        {
            var target = new Customer();
            const string value = "cute test string of my own";
            target.NextSteps = value;
            Assert.That(target.NextSteps, Is.EqualTo(value));
        }

        [Test]
        public void NextStepsDate()
        {
            var target = new Customer();
            var value = Create.AnyDate();
            target.NextStepsDate = value;
            Assert.That(target.NextStepsDate, Is.EqualTo(value));
        }

        [Test]
        public void OpenUpMyStomachAndStickAHamburgerInFails()
        {
            var target = new Customer();
            Assert.That(() => target.Subscriptions.Add(new Subscription()), Throws.Exception);
        }

        [Test]
        public void Phone()
        {
            var target = new Customer();
            var value = Create.AnyString();
            target.Phone = value;
            Assert.That(target.Phone, Is.EqualTo(value));
        }

        [Test]
        public void RecordPaymentAddsCorrectTransactionType()
        {
            var target = new Customer();
            target.RecordPayment(Create.AnyDate(), default(BillingType), 346.6m);
            Assert.That(target.Transactions[0], Is.InstanceOf<PaymentTransaction>());
        }

        [Test]
        public void RecordPaymentSetsTransactionAmount()
        {
            const decimal amount = 4536;
            var target = new Customer();
            target.RecordPayment(Create.AnyDate(), default(BillingType), amount);
            Assert.That(target.Transactions[0].Amount, Is.EqualTo(-amount));
        }

        [Test]
        public void RecordPaymentSetsTransactionBillingType()
        {
            var type = Create.NonDefaultBillingType();
            var target = new Customer();
            target.RecordPayment(Create.AnyDate(), type, 4356);
            var transaction = (PaymentTransaction) target.Transactions[0];
            Assert.That(transaction.Type, Is.EqualTo(type));
        }

        [Test]
        public void RecordPaymentSetsTransactionDate()
        {
            var date = Create.AnyDate();
            var target = new Customer();
            target.RecordPayment(date, default(BillingType), 4356);
            Assert.That(target.Transactions[0].Date, Is.EqualTo(date));
        }

        [Test]
        public void RecordPaymentUpdatesBalance()
        {
            const decimal amount = 4536;
            const decimal starting = 236;
            var target = Create.CustomerWithBalance(starting);
            target.RecordPayment(Create.AnyDate(), default(BillingType), amount);
            Assert.That(target.EndingBalance, Is.EqualTo(starting - amount));
        }

        [Test]
        public void SetBillingPeriod()
        {
            var target = new Customer();
            const BillingPeriod value = BillingPeriod.Semiannually;
            target.BillingPeriod = value;
            Assert.That(target.BillingPeriod, Is.EqualTo(value));
        }

        [Test]
        public void SetBillingType()
        {
            const BillingType value = BillingType.Eft;
            var target = new Customer {BillingType = value};
            Assert.That(target.BillingType, Is.EqualTo(value));
        }

        [Test]
        public void SetNullPaymentMethod()
        {
            var target = new Customer();
            Assert.That(target.PaymentMethodId, Is.Null);
        }

        [Test]
        public void SetPaymentMethodId()
        {
            const int value = 23456;
            var target = new Customer {PaymentMethodId = value};
            Assert.That(target.PaymentMethodId, Is.EqualTo(value));
        }

        [Test]
        public void ShouldGenerateInvoiceNow()
        {
            var start = Create.AnyDate();
            var target = new Customer {BillingStartDate = start};
            Assert.That(target.ShouldInvoiceOn(start.AddDays(1)), Is.True);
        }

        [Test]
        public void ShouldGenerateInvoiceOnBillingStartDate()
        {
            var start = Create.AnyDate();
            var target = new Customer {BillingStartDate = start};
            Assert.That(target.ShouldInvoiceOn(start), Is.True);
        }

        [Test]
        public void ShouldGenerateInvoiceOnNextInvoiceDate()
        {
            var target = new Customer();
            var invoice = Create.InvoiceForCustomer(target);
            target.BillingStartDate = invoice.InvoiceDate;
            Assert.That(target.ShouldInvoiceOn(target.NextInvoiceDate.Value), Is.True);
        }

        [Test]
        public void ShouldNotGenerateInvoiceSinceBillingStartDateNotReachedYet()
        {
            var start = Create.AnyDate();
            var target = new Customer {BillingStartDate = start};
            Assert.That(target.ShouldInvoiceOn(start.AddDays(-1)), Is.False);
        }

        [Test]
        public void ShouldNotGenerateInvoiceSinceNextInvoiceDateNotReachedYet()
        {
            var target = new Customer();
            var invoice = Create.InvoiceForCustomer(target);
            target.BillingStartDate = invoice.InvoiceDate;
            Assert.That(target.ShouldInvoiceOn(invoice.InvoiceDate), Is.False);
        }

        [Test]
        public void ShouldNotGenerateInvoiceSinceNoBillingStartDateSet()
        {
            var start = Create.AnyDate();
            var target = new Customer();
            Assert.That(target.ShouldInvoiceOn(start), Is.False);
        }

        [Test]
        public void State()
        {
            var target = new Customer();
            const string state = "cute test string of my own";
            target.State = state;
            Assert.That(target.State, Is.EqualTo(state));
        }

        [Test]
        public void Street1()
        {
            var target = new Customer();
            const string street1 = "cute test string of my own";
            target.StreetAddress1 = street1;
            Assert.That(target.StreetAddress1, Is.EqualTo(street1));
        }

        [Test]
        public void Street2()
        {
            var target = new Customer();
            const string street2 = "cute test string of my own";
            target.StreetAddress2 = street2;
            Assert.That(target.StreetAddress2, Is.EqualTo(street2));
        }

        [Test]
        public void ToStringFormat()
        {
            var name = Create.AnyString();
            var target = new Customer {Name = name};
            Assert.That(target.ToString(), Is.EqualTo(string.Format(Customer.ToStringFormat, name)));
        }

        [Test]
        public void TransactionsCollectionIsReadOnly()
        {
            var target = new Customer();
            Assert.That(() => target.Transactions.Add(new BaseTransaction()), Throws.Exception);
        }

        [Test]
        public void Zip()
        {
            var target = new Customer();
            const string zip = "cute test string of my own";
            target.Zip = zip;
            Assert.That(target.Zip, Is.EqualTo(zip));
        }
    }
}