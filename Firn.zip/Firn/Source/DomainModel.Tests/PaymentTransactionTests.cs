using System;
using NUnit.Framework;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class PaymentTransactionTests
    {
        [Test]
        public void ConstructWithAmountNegatesIt()
        {
            decimal amount = 36.5m;
            var target = new PaymentTransaction(Create.AnyDate(), amount, default(BillingType));
            Assert.That(target.Amount, Is.EqualTo(-amount));
        }

        [Test]
        public void ConstructWithBillingType()
        {
            BillingType value = Create.NonDefaultBillingType();
            var target = new PaymentTransaction(Create.AnyDate(), 0, value);
            Assert.That(target.Type, Is.EqualTo(value));
        }

        [Test]
        public void ConstructWithDate()
        {
            DateTime date = Create.AnyDate();
            var target = new PaymentTransaction(date, 0, default(BillingType));
            Assert.That(target.Date, Is.EqualTo(date));
        }

        [Test]
        public void ConstructWithDescription()
        {
            var target = new PaymentTransaction(Create.AnyDate(), 0, default(BillingType));
            Assert.That(target.Description, Is.EqualTo(PaymentTransaction.DefaultDescription));
        }

        [Test]
        public void ConstructWithName()
        {
            var target = new PaymentTransaction(Create.AnyDate(), 0, default(BillingType));
            Assert.That(target.Name, Is.EqualTo(string.Empty));
        }

        [Test]
        public void IsAPaymentTransaction()
        {
            Assert.That(new PaymentTransaction(), Is.InstanceOf<FinancialTransaction>());
        }
    }
}