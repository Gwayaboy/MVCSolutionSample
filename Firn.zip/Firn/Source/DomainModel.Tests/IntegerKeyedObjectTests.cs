using NUnit.Framework;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class IntegerKeyedObjectTests
    {
        [Test]
        public void ConstructWithId()
        {
            int id = 32456;
            var target = new IntegerKeyedObject(id);
            Assert.That(target.Id, Is.EqualTo(id));
        }

        [Test]
        public void Id()
        {
            var target = new IntegerKeyedObject();
            int key = 5;
            Assert.That(target.Id, Is.EqualTo(0));
            target.Id = key;
            Assert.That(target.Id, Is.EqualTo(key));
        }

        [Test]
        public void Version()
        {
            var target = new IntegerKeyedObject();
            int version = 5;
            Assert.That(target.Version, Is.EqualTo(0));
            target.Version = version;
            Assert.That(target.Version, Is.EqualTo(version));
        }
    }
}