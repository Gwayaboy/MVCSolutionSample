using System;
using NUnit.Framework;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class RefundTransactionTests
    {
        [Test]
        public void ConstructWithAmount()
        {
            decimal amount = 36.5m;
            var target = new RefundTransaction(Create.AnyDate(), amount, null, default(BillingType));
            Assert.That(target.Amount, Is.EqualTo(amount));
        }

        [Test]
        public void ConstructWithBillingType()
        {
            BillingType value = Create.NonDefaultBillingType();
            var target = new RefundTransaction(Create.AnyDate(), 0, null, value);
            Assert.That(target.Type, Is.EqualTo(value));
        }

        [Test]
        public void ConstructWithDate()
        {
            DateTime date = Create.AnyDate();
            var target = new RefundTransaction(date, 0, null, default(BillingType));
            Assert.That(target.Date, Is.EqualTo(date));
        }

        [Test]
        public void ConstructWithName()
        {
            var target = new RefundTransaction(Create.AnyDate(), 0, null, default(BillingType));
            Assert.That(target.Name, Is.EqualTo(RefundTransaction.DefaultName));
        }

        [Test]
        public void ConstructWithReason()
        {
            string reason = Create.AnyString();
            var target = new RefundTransaction(Create.AnyDate(), 0, reason, default(BillingType));
            Assert.That(target.Description, Is.EqualTo(reason));
        }

        [Test]
        public void IsAFinancialTransaction()
        {
            Assert.That(new RefundTransaction(), Is.InstanceOf<FinancialTransaction>());
        }
    }
}