using System;
using NUnit.Framework;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class InvoiceLineItemTests
    {
        [Test]
        public void ConstructWithDate()
        {
            DateTime date = Create.AnyDate();
            var target = new InvoiceLineItem(date, null, null, 6754, 0);
            Assert.That(target.Date, Is.EqualTo(date));
        }

        [Test]
        public void ConstructWithDescription()
        {
            string description = Create.AnyString();
            var target = new InvoiceLineItem(default(DateTime), null, description, 0, 0);
            Assert.That(target.Description, Is.EqualTo(description));
        }

        [Test]
        public void ConstructWithName()
        {
            string name = Create.AnyString();
            var target = new InvoiceLineItem(default(DateTime), name, null, 0, 0);
            Assert.That(target.Name, Is.EqualTo(name));
        }

        [Test]
        public void ConstructWithNullStaffCount()
        {
            var target = new InvoiceLineItem(default(DateTime), null, null, null, 0);
            Assert.That(target.StaffCount, Is.Null);
        }

        [Test]
        public void ConstructWithPrice()
        {
            decimal price = 467.45m;
            var target = new InvoiceLineItem(default(DateTime), null, null, 6754, price);
            Assert.That(target.Price, Is.EqualTo(price));
        }

        [Test]
        public void ConstructWithStaffCount()
        {
            int count = 56;
            var target = new InvoiceLineItem(default(DateTime), null, null, count, 0);
            Assert.That(target.StaffCount, Is.EqualTo(count));
        }

        [Test]
        public void DefaultStaffCount()
        {
            Assert.That(new InvoiceLineItem().StaffCount, Is.Null);
        }
    }
}