using NUnit.Framework;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class BaseAccountTransactionTests
    {
        [Test]
        public void ConstructWithAmount()
        {
            var amount = 36.5m;
            var target = new BaseAccountTransaction(Create.AnyDate(), amount, null, null);
            Assert.That(target.Amount, Is.EqualTo(amount));
        }

        [Test]
        public void ConstructWithDate()
        {
            var date = Create.AnyDate();
            var target = new BaseAccountTransaction(date, 0, null, null);
            Assert.That(target.Date, Is.EqualTo(date));
        }

        [Test]
        public void ConstructWithDescription()
        {
            var description = Create.AnyString();
            var target = new BaseAccountTransaction(Create.AnyDate(), 0, null, description);
            Assert.That(target.Description, Is.EqualTo(description));
        }

        [Test]
        public void ConstructWithName()
        {
            var name = Create.AnyString();
            var target = new BaseAccountTransaction(Create.AnyDate(), 0, name, null);
            Assert.That(target.Name, Is.EqualTo(name));
        }

        [Test]
        public void IsATransaction()
        {
            Assert.That(new BaseAccountTransaction(), Is.InstanceOf<BaseTransaction>());
        }

        [Test]
        public void OneInstallmentByDefault()
        {
            var target = new BaseAccountTransaction(Create.AnyDate(), 44, string.Empty, string.Empty);
            Assert.That(target.CalculateInstallments(5),
                        Is.EqualTo(new[]
                                       {
                                           new Installment(target.Date,
                                                           target.Date - BaseAccountTransaction.TimeBeforeDueDateToBill,
                                                           target.Amount, target),
                                       }));
        }
    }
}