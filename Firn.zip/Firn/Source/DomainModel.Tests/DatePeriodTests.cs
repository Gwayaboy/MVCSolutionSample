using System;
using NUnit.Framework;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class DatePeriodTests : MockTestFixture
    {
        [Test]
        public void CheckEquality()
        {
            Assert.That(new DatePeriod(Create.AnyDate(), Create.AnyDate()),
                        Is.EqualTo(new DatePeriod(Create.AnyDate(), Create.AnyDate())));
        }

        [Test]
        public void ConstructWithEndDate()
        {
            DateTime end = Create.AnyDate();
            var target = new DatePeriod(default(DateTime), end);
            Assert.That(target.End, Is.EqualTo(end));
        }

        [Test]
        public void ConstructWithStartAndDuration()
        {
            DateTime start = Create.AnyDate();
            Assert.That(new DatePeriod(start, TimeSpan.FromDays(2)), Is.EqualTo(new DatePeriod(start, start.AddDays(1))));
        }

        [Test]
        public void ConstructWithStartDate()
        {
            DateTime start = Create.AnyDate();
            var target = new DatePeriod(start, Create.AnyDate());
            Assert.That(target.Start, Is.EqualTo(start));
        }

        [Test]
        public void SplitIntoOneChunk()
        {
            DateTime start = Create.AnyDate();
            var target = new DatePeriod(start, start.AddDays(5));
            Assert.That(target.SplitByMonths(1), Is.EqualTo(new[] {start}));
        }

        [Test]
        public void SplitIntoThreeChunks()
        {
            DateTime start = Create.AnyDate();
            var target = new DatePeriod(start, start.AddMonths(6).AddDays(-1));
            Assert.That(target.SplitByMonths(2), Is.EqualTo(new[] {start, start.AddMonths(2), start.AddMonths(4)}));
        }

        [Test]
        public void SplitIntoTwoChunks()
        {
            DateTime start = Create.AnyDate();
            var target = new DatePeriod(start, start.AddMonths(10).AddDays(-1));
            Assert.That(target.SplitByMonths(5), Is.EqualTo(new[] {start, start.AddMonths(5)}));
        }
    }
}