using System;
using NUnit.Framework;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class SubscriptionTests : MockTestFixture
    {
        [Test]
        public void ConstructWithAmount()
        {
            decimal amount = 246;
            var target = new Subscription(null, null, Create.AnyDate(), 1, amount, 0, 0);
            Assert.That(target.Transaction.Amount, Is.EqualTo(amount));
        }

        [Test]
        public void ConstructWithBillableWeeksBefore()
        {
            int billableWeeksBefore = 346;
            var target = new Subscription(null, null, Create.AnyDate(), 1, 0, 0, billableWeeksBefore);
            Assert.That(target.Transaction.BillableWeeksBefore, Is.EqualTo(billableWeeksBefore));
        }

        [Test]
        public void ConstructWithDescription()
        {
            string description = Create.AnyString();
            var target = new Subscription(null, description, Create.AnyDate(), 0, 0, 0, 0);
            Assert.That(target.Transaction.Description, Is.EqualTo(description));
        }

        [Test]
        public void ConstructWithMonths()
        {
            DateTime startDate = Create.AnyDate();
            int months = 3;
            var target = new Subscription(null, null, startDate, months, 0, 0, 0);
            Assert.That(target.Months, Is.EqualTo(months));
        }

        [Test]
        public void ConstructWithName()
        {
            string name = Create.AnyString();
            var target = new Subscription(name, null, Create.AnyDate(), 0, 0, 0, 0);
            Assert.That(target.Transaction.Name, Is.EqualTo(name));
        }

        [Test]
        public void ConstructWithStaffCount()
        {
            int staffCount = 346;
            var target = new Subscription(null, null, Create.AnyDate(), 1, 0, staffCount, 0);
            Assert.That(target.Transaction.StaffCount, Is.EqualTo(staffCount));
        }

        [Test]
        public void ConstructWithStartDate()
        {
            DateTime startDate = Create.AnyDate();
            var target = new Subscription(null, null, startDate, 0, 0, 0, 0);
            Assert.That(target.Transaction.Date, Is.EqualTo(startDate));
        }

        [Test]
        public void ConstructWithStartDateAndMonths()
        {
            DateTime startDate = Create.AnyDate();
            int months = 3;
            var target = new Subscription(null, null, startDate, months, 0, 0, 0);
            Assert.That(target.Transaction.Period,
                        Is.EqualTo(new DatePeriod(startDate, startDate.AddMonths(3).AddDays(-1))));
        }

        [Test]
        public void NotRenewedByDefault()
        {
            Assert.That(new Subscription().Renewed, Is.False);
        }

        [Test]
        public void RenewSubscriptionAddsNewSubscription()
        {
            var customer = new Customer();
            DateTime end = Create.AnyDate();
            Subscription target = Create.SubscriptionEndingOn(end);
            target.CheckRenewal(customer, end);
            Assert.That(customer.Subscriptions[0], Is.Not.SameAs(target));
        }

        [Test]
        public void RenewSubscriptionAddsWithSameAmount()
        {
            var customer = new Customer();
            DateTime end = Create.AnyDate();
            Subscription target = Create.SubscriptionEndingOn(end);
            target.CheckRenewal(customer, end);
            Assert.That(customer.Subscriptions[0].Transaction.Amount, Is.EqualTo(target.Transaction.Amount));
        }

        [Test]
        public void RenewSubscriptionAddsWithSameBillableWeeksBefore()
        {
            var customer = new Customer();
            DateTime end = Create.AnyDate();
            Subscription target = Create.SubscriptionEndingOn(end);
            target.CheckRenewal(customer, end);
            Assert.That(customer.Subscriptions[0].Transaction.BillableWeeksBefore,
                        Is.EqualTo(target.Transaction.BillableWeeksBefore));
        }

        [Test]
        public void RenewSubscriptionAddsWithSameDescription()
        {
            var customer = new Customer();
            DateTime end = Create.AnyDate();
            Subscription target = Create.SubscriptionEndingOn(end);
            target.CheckRenewal(customer, end);
            Assert.That(customer.Subscriptions[0].Transaction.Description, Is.EqualTo(target.Transaction.Description));
        }

        [Test]
        public void RenewSubscriptionAddsWithSameMonthDuration()
        {
            var customer = new Customer();
            DateTime end = Create.AnyDate();
            Subscription target = Create.SubscriptionEndingOn(end);
            target.CheckRenewal(customer, end);
            Assert.That(customer.Subscriptions[0].Months, Is.EqualTo(target.Months));
        }

        [Test]
        public void RenewSubscriptionAddsWithSameName()
        {
            var customer = new Customer();
            DateTime end = Create.AnyDate();
            Subscription target = Create.SubscriptionEndingOn(end);
            target.CheckRenewal(customer, end);
            Assert.That(customer.Subscriptions[0].Transaction.Name, Is.EqualTo(target.Transaction.Name));
        }

        [Test]
        public void RenewSubscriptionAddsWithSameStaffCount()
        {
            var customer = new Customer();
            DateTime end = Create.AnyDate();
            Subscription target = Create.SubscriptionEndingOn(end);
            target.CheckRenewal(customer, end);
            Assert.That(customer.Subscriptions[0].StaffCount, Is.EqualTo(target.StaffCount));
        }

        [Test]
        public void RenewSubscriptionAddsWithStartDateJustAfterCurrentEndDate()
        {
            var customer = new Customer();
            DateTime end = Create.AnyDate();
            Subscription target = Create.SubscriptionEndingOn(end);
            target.CheckRenewal(customer, end);
            Assert.That(customer.Subscriptions[0].Transaction.Date, Is.EqualTo(end.AddDays(1)));
        }

        [Test]
        public void RenewSubscriptionDoesNothingWhenAlreadyRenewed()
        {
            var customer = new Customer();
            DateTime end = Create.AnyDate();
            Subscription target = Create.SubscriptionEndingOn(end);
            target.CheckRenewal(customer, end);
            target.CheckRenewal(customer, end);
            Assert.That(customer.Subscriptions, Has.Count.EqualTo(1));
        }

        [Test]
        public void RenewSubscriptionDoesNothingWhenNotYetInRenewalWindow()
        {
            var customer = new Customer();
            DateTime end = Create.AnyDate();
            Subscription target = Create.SubscriptionEndingOn(end);
            target.CheckRenewal(customer, end - Subscription.RenewalWindow - TimeSpan.FromTicks(1));
            Assert.That(customer.Subscriptions, Is.Empty);
        }

        [Test]
        public void RenewSubscriptionSetsRenewedFlag()
        {
            var customer = new Customer();
            DateTime end = Create.AnyDate();
            Subscription target = Create.SubscriptionEndingOn(end);
            target.CheckRenewal(customer, end);
            Assert.That(target.Renewed, Is.True);
        }

        [Test]
        public void RenewSubscriptionWhenJustWithinRenewalWindow()
        {
            var customer = new Customer();
            DateTime end = Create.AnyDate();
            Subscription target = Create.SubscriptionEndingOn(end);
            target.CheckRenewal(customer, end - Subscription.RenewalWindow);
            Assert.That(customer.Subscriptions, Is.Not.Empty);
        }

        [Test]
        public void UpdateSetsAmount()
        {
            var target = new Subscription(null, null, default(DateTime), 1, 1, 1, 0);
            decimal amount = 3245.6m;
            target.Update(null, null, default(DateTime), 1, amount, 1, 0);
            Assert.That(target.Transaction.Amount, Is.EqualTo(amount));
        }

        [Test]
        public void UpdateSetsBillableWeeksBefore()
        {
            var target = new Subscription(null, null, default(DateTime), 1, 1, 1, 0);
            int billableWeeksBefore = 435;
            target.Update(null, null, default(DateTime), 1, 1, 0, billableWeeksBefore);
            Assert.That(target.Transaction.BillableWeeksBefore, Is.EqualTo(billableWeeksBefore));
        }

        [Test]
        public void UpdateSetsDatePeriodForTransaction()
        {
            var target = new Subscription(null, null, default(DateTime), 1, 1, 1, 0);
            DateTime startDate = Create.AnyDate();
            int months = 4;
            target.Update(null, null, startDate, months, 1, 1, 0);
            Assert.That(target.Transaction.Period,
                        Is.EqualTo(new DatePeriod(startDate, startDate.AddMonths(4).AddDays(-1))));
        }

        [Test]
        public void UpdateSetsDescription()
        {
            var target = new Subscription(null, null, default(DateTime), 1, 1, 1, 0);
            string description = Create.AnyString();
            target.Update(null, description, default(DateTime), 1, 1, 1, 0);
            Assert.That(target.Transaction.Description, Is.EqualTo(description));
        }

        [Test]
        public void UpdateSetsMonths()
        {
            var target = new Subscription(null, null, default(DateTime), 1, 1, 1, 0);
            int months = 4;
            target.Update(null, null, default(DateTime), months, 1, 1, 0);
            Assert.That(target.Months, Is.EqualTo(months));
        }

        [Test]
        public void UpdateSetsName()
        {
            var target = new Subscription(null, null, default(DateTime), 1, 1, 1, 0);
            string name = Create.AnyString();
            target.Update(name, null, default(DateTime), 1, 1, 1, 0);
            Assert.That(target.Transaction.Name, Is.EqualTo(name));
        }

        [Test]
        public void UpdateSetsStaffCount()
        {
            var target = new Subscription(null, null, default(DateTime), 1, 1, 1, 0);
            int staffCount = 435;
            target.Update(null, null, default(DateTime), 1, 1, staffCount, 0);
            Assert.That(target.StaffCount, Is.EqualTo(staffCount));
        }

        [Test]
        public void UpdateSetsStartDate()
        {
            var target = new Subscription(null, null, default(DateTime), 1, 1, 1, 0);
            DateTime startDate = Create.AnyDate();
            target.Update(null, null, startDate, 1, 1, 1, 0);
            Assert.That(target.Transaction.Date, Is.EqualTo(startDate));
        }
    }
}