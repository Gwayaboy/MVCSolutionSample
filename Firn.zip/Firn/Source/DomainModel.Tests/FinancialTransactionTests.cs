using System;
using NUnit.Framework;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class FinancialTransactionTests
    {
        [Test]
        public void ConstructWithAmount()
        {
            decimal amount = 36.5m;
            var target = new FinancialTransaction(Create.AnyDate(), amount, null, null, default(BillingType));
            Assert.That(target.Amount, Is.EqualTo(amount));
        }

        [Test]
        public void ConstructWithBillingType()
        {
            BillingType value = Create.NonDefaultBillingType();
            var target = new FinancialTransaction(Create.AnyDate(), 0, null, null, value);
            Assert.That(target.Type, Is.EqualTo(value));
        }

        [Test]
        public void ConstructWithDate()
        {
            DateTime date = Create.AnyDate();
            var target = new FinancialTransaction(date, 0, null, null, default(BillingType));
            Assert.That(target.Date, Is.EqualTo(date));
        }

        [Test]
        public void ConstructWithDescription()
        {
            string description = Create.AnyString();
            var target = new FinancialTransaction(Create.AnyDate(), 0, null, description, default(BillingType));
            Assert.That(target.Description, Is.EqualTo(description));
        }

        [Test]
        public void ConstructWithName()
        {
            string name = Create.AnyString();
            var target = new FinancialTransaction(Create.AnyDate(), 0, name, null, default(BillingType));
            Assert.That(target.Name, Is.EqualTo(name));
        }

        [Test]
        public void IsATransaction()
        {
            Assert.That(new FinancialTransaction(), Is.InstanceOf<FinancialTransaction>());
        }
    }
}