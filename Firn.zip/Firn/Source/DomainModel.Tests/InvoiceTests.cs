using System;
using Intrigma.Firn.DomainModel.PaymentGateway;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.DomainModel.Tests
{
    [TestFixture]
    public class InvoiceTests
    {
        [Test]
        public void AddTwoLineItems()
        {
            var item1 = new InvoiceLineItem();
            var item2 = new InvoiceLineItem();
            var target = new Invoice();
            target.AddLineItem(item1);
            target.AddLineItem(item2);
            Assert.That(target.LineItems, Is.EqualTo(new[] {item1, item2}));
        }

        [Test]
        public void CannotAddLineItemDirectly()
        {
            var target = new Invoice();
            Assert.That(() => target.LineItems.Add(new InvoiceLineItem()), Throws.Exception);
        }

        [Test]
        public void ConstructWithCustomer()
        {
            var customer = new Customer();
            var target = new Invoice(customer, 0, default(DateTime), default(DateTime));
            Assert.That(target.Customer, Is.SameAs(customer));
        }

        [Test]
        public void ConstructWithCustomerAddsToListOfInvoicesForCustomer()
        {
            var customer = new Customer();
            var target = new Invoice(customer, 0, default(DateTime), default(DateTime));
            Assert.That(target.Customer.Invoices, Has.Some.SameAs(target));
        }

        [Test]
        public void ConstructWithDueDate()
        {
            var dueDate = Create.AnyDate();
            var target = new Invoice(new Customer(), 0, default(DateTime), dueDate);
            Assert.That(target.DueDate, Is.EqualTo(dueDate));
        }

        [Test]
        public void ConstructWithId()
        {
            const int id = 2346;
            var target = new Invoice(new Customer(), id, default(DateTime), default(DateTime));
            Assert.That(target.Id, Is.EqualTo(id));
        }

        [Test]
        public void ConstructWithInvoiceDate()
        {
            var invoiceDate = Create.AnyDate();
            var target = new Invoice(new Customer(), 0, invoiceDate, default(DateTime));
            Assert.That(target.InvoiceDate, Is.EqualTo(invoiceDate));
        }

        [Test]
        public void ToStringFormat()
        {
            var customer = new Customer();
            const int id = 345;
            var dueDate = Create.UniqueDate();
            var invoiceDate = Create.UniqueDate();
            var target = new Invoice(customer, id, invoiceDate, dueDate);
            Assert.That(target.ToString(),
                        Is.EqualTo(string.Format(Invoice.ToStringFormat, id, customer, invoiceDate, dueDate)));
        }

        [Test]
        public void TotalNoLineItems()
        {
            var target = new Invoice();
            Assert.That(target.Total, Is.EqualTo(0m));
        }

        [Test]
        public void TotalTwoLineItems()
        {
            var item1 = new InvoiceLineItem(default(DateTime), "asdfasd", null, 0, 4.45m);
            var item2 = new InvoiceLineItem(default(DateTime), null, null, 0, 24.54m);
            var target = new Invoice();
            target.AddLineItem(item1);
            target.AddLineItem(item2);
            Assert.That(target.Total, Is.EqualTo(item1.Price + item2.Price));
        }
    }

    [TestFixture]
    public class InvoicePaymentTests : MockTestFixture
    {
        #region Setup/Teardown

        public override void SetUp()
        {
            base.SetUp();
            _customer = DynamicMock<Customer>();
            _gateway = DynamicMock<IPaymentGateway>();
        }

        #endregion

        private IPaymentGateway _gateway;
        private Customer _customer;

        [Test]
        public void CancelClearsPaymentResult()
        {
            var invoice = Create.InvoicePaid(Mocks);
            ReplayAll();

            invoice.Cancel();
            Assert.That(invoice.PaymentResult, Is.Null);
        }

        [Test]
        public void CancelSetsStatus()
        {
            var invoice = new Invoice();
            ReplayAll();

            invoice.Cancel();
            Assert.That(invoice.PaymentStatus, Is.EqualTo(InvoicePaymentStatus.Canceled));
        }

        [Test]
        public void DefaultDatePaid()
        {
            ReplayAll();
            Assert.That(new Invoice().DatePaid, Is.Null);
        }

        [Test]
        public void DefaultStatus()
        {
            ReplayAll();
            Assert.That(new Invoice().PaymentStatus, Is.EqualTo(InvoicePaymentStatus.Pending));
        }

        [Test]
        public void DoNotSetDatePaidAfterFailedPayment()
        {
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(false);
            var date = Create.AnyDate();
            SetupResult.For(_customer.MakePayment(date, 0, _gateway)).Return(result);
            ReplayAll();

            var target = new Invoice(_customer, 0, default(DateTime), default(DateTime));
            target.Pay(date, _gateway);
            Assert.That(target.DatePaid, Is.Null);
        }

        [Test]
        public void MarkPaidClearsPaymentResult()
        {
            var invoice = Create.InvoicePaid(Mocks);
            ReplayAll();

            invoice.MarkPaid(Create.AnyDate());
            Assert.That(invoice.PaymentResult, Is.Null);
        }

        [Test]
        public void MarkPaidSetsDatePaid()
        {
            var invoice = new Invoice();
            var date = Create.AnyDate();
            ReplayAll();

            invoice.MarkPaid(date);
            Assert.That(invoice.DatePaid, Is.EqualTo(date));
        }

        [Test]
        public void MarkPaidSetsStatus()
        {
            var invoice = new Invoice();
            ReplayAll();

            invoice.MarkPaid(Create.AnyDate());
            Assert.That(invoice.PaymentStatus, Is.EqualTo(InvoicePaymentStatus.Paid));
        }

        [Test]
        public void RecordPayment()
        {
            var date = Create.AnyDate();
            const decimal amount = 235.5m;
            var billingType = Create.NonDefaultBillingType();
            _customer.RecordPayment(date, billingType, amount);
            ReplayAll();

            var target = new Invoice(_customer, 0, default(DateTime), default(DateTime));
            target.RecordPayment(date, billingType, amount);
        }

        [Test]
        public void RecordPaymentClearsPaymentResult()
        {
            var date = Create.AnyDate();
            const decimal amount = 235.5m;
            var billingType = Create.NonDefaultBillingType();
            var target = Create.InvoicePaid(Mocks);
            ReplayAll();

            target.RecordPayment(date, billingType, amount);
            Assert.That(target.PaymentResult, Is.Null);
        }

        [Test]
        public void RecordPaymentMarksInvoicePaid()
        {
            var date = Create.AnyDate();
            const decimal amount = 235.5m;
            var billingType = Create.NonDefaultBillingType();
            ReplayAll();

            var target = new Invoice(_customer, 0, default(DateTime), default(DateTime));
            target.RecordPayment(date, billingType, amount);
            Assert.That(target.PaymentStatus, Is.EqualTo(InvoicePaymentStatus.Paid));
        }

        [Test]
        public void RecordPaymentSetsDatePaid()
        {
            var date = Create.AnyDate();
            const decimal amount = 235.5m;
            var billingType = Create.NonDefaultBillingType();
            ReplayAll();

            var target = new Invoice(_customer, 0, default(DateTime), default(DateTime));
            target.RecordPayment(date, billingType, amount);
            Assert.That(target.DatePaid, Is.EqualTo(date));
        }

        [Test]
        public void ReturnPaymentResult()
        {
            var result = DynamicMock<IPaymentResult>();
            var date = Create.AnyDate();
            SetupResult.For(_customer.MakePayment(date, 0, _gateway)).Return(result);
            ReplayAll();

            var target = new Invoice(_customer, 0, default(DateTime), default(DateTime));
            Assert.That(target.Pay(date, _gateway), Is.SameAs(result));
        }

        [Test]
        public void SetDatePaidAfterSuccessfulPayment()
        {
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(true);
            var date = Create.AnyDate();
            SetupResult.For(_customer.MakePayment(date, 0, _gateway)).Return(result);
            ReplayAll();

            var target = new Invoice(_customer, 0, default(DateTime), default(DateTime));
            target.Pay(date, _gateway);
            Assert.That(target.DatePaid, Is.EqualTo(date));
        }

        [Test]
        public void SetInvoiceStatusToFailedAfterFailedPayment()
        {
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(false);
            var date = Create.AnyDate();
            SetupResult.For(_customer.MakePayment(date, 0, _gateway)).Return(result);
            ReplayAll();

            var target = new Invoice(_customer, 0, default(DateTime), default(DateTime));
            target.Pay(date, _gateway);
            Assert.That(target.PaymentStatus, Is.EqualTo(InvoicePaymentStatus.PaymentFailed));
        }

        [Test]
        public void SetInvoiceStatusToPaidAfterSuccessfulPayment()
        {
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(true);
            var date = Create.AnyDate();
            SetupResult.For(_customer.MakePayment(date, 0, _gateway)).Return(result);
            ReplayAll();

            var target = new Invoice(_customer, 0, default(DateTime), default(DateTime));
            target.Pay(date, _gateway);
            Assert.That(target.PaymentStatus, Is.EqualTo(InvoicePaymentStatus.Paid));
        }

        [Test]
        public void SetPaymentAmountToAnything()
        {
            var result = DynamicMock<IPaymentResult>();
            var date = Create.AnyDate();
            const decimal amount = 235.5m;
            SetupResult.For(_customer.MakePayment(date, amount, _gateway)).Return(result);
            ReplayAll();

            var target = new Invoice(_customer, 0, default(DateTime), default(DateTime));
            Assert.That(target.Pay(date, amount, _gateway), Is.SameAs(result));
        }

        [Test]
        public void SetPaymentAmountToInvoiceTotal()
        {
            var result = DynamicMock<IPaymentResult>();
            var date = Create.AnyDate();
            SetupResult.For(_customer.MakePayment(date, 3, _gateway)).Return(result);
            ReplayAll();

            var target = new Invoice(_customer, 0, default(DateTime), default(DateTime));
            target.AddLineItem(new InvoiceLineItem(default(DateTime), null, null, null, 1));
            target.AddLineItem(new InvoiceLineItem(default(DateTime), null, null, null, 2));
            Assert.That(target.Pay(date, _gateway), Is.SameAs(result));
        }

        [Test]
        public void SetPaymentResultAfterPayingSomething()
        {
            var result = DynamicMock<IPaymentResult>();
            var text = Create.AnyString();
            SetupResult.For(result.RawMessage).Return(text);
            var date = Create.AnyDate();
            const decimal amount = 2354;
            SetupResult.For(_customer.MakePayment(date, amount, _gateway)).Return(result);
            ReplayAll();

            var target = new Invoice(_customer, 0, default(DateTime), default(DateTime));
            target.Pay(date, amount, _gateway);
            Assert.That(target.PaymentResult, Is.EqualTo(text));
        }

        [Test]
        public void SetPaymentResultAfterPayment()
        {
            var result = DynamicMock<IPaymentResult>();
            var text = Create.AnyString();
            SetupResult.For(result.RawMessage).Return(text);
            var date = Create.AnyDate();
            SetupResult.For(_customer.MakePayment(date, 0, _gateway)).Return(result);
            ReplayAll();

            var target = new Invoice(_customer, 0, default(DateTime), default(DateTime));
            target.Pay(date, _gateway);
            Assert.That(target.PaymentResult, Is.EqualTo(text));
        }
    }
}