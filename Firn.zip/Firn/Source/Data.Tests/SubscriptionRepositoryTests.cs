using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;

namespace Intrigma.Firn.Data.Tests
{
    [TestFixture]
    public class SubscriptionRepositoryTests : NHibernateTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _customerRepository = new CustomerRepository(SessionManager);
        }

        private CustomerRepository _customerRepository;

        [Test]
        public void AddRenewedSubscription()
        {
            var customer = new Customer();
            Subscription subscription = Create.SubscriptionThatHasBeenRenewed(customer);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            customer = _customerRepository.GetById(customer.Id);
            foreach (Subscription actual in customer.Subscriptions)
            {
                if (actual.Id == subscription.Id)
                {
                    Assert.That(actual.Renewed, Is.True);
                }
            }
        }

        [Test]
        public void AddSubscriptionWithMonths()
        {
            var subscription = new Subscription(string.Empty, string.Empty, Create.AnyDate(), 5, 0, 0, 0);
            var customer = new Customer();
            customer.AddSubscription(subscription);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            customer = _customerRepository.GetById(customer.Id);
            Assert.That(customer.Subscriptions[0].Months, Is.EqualTo(subscription.Months));
        }

        [Test]
        public void AddSubscriptionWithStaffCount()
        {
            var subscription = new Subscription(string.Empty, string.Empty, Create.AnyDate(), 1, 0, 20, 0);
            var customer = new Customer();
            customer.AddSubscription(subscription);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            customer = _customerRepository.GetById(customer.Id);
            Assert.That(customer.Subscriptions[0].StaffCount, Is.EqualTo(subscription.StaffCount));
        }

        [Test]
        public void AddSubscriptionWithTransaction()
        {
            decimal amount = 3456;
            var subscription = new Subscription(string.Empty, string.Empty, Create.AnyDate(), 1, amount, 20, 0);
            var customer = new Customer();
            customer.AddSubscription(subscription);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            customer = _customerRepository.GetById(customer.Id);
            Subscription actual = customer.Subscriptions[0];
            Assert.That(actual.Transaction.Amount, Is.EqualTo(amount));
        }
    }
}