using System;
using Castle.Facilities.NHibernateIntegration;
using Intrigma.DatabaseVersion.Core;
using NHibernate;

namespace Intrigma.Firn.Data.Tests
{
    public class StubSessionManager : ISessionManager
    {
        private static ISessionFactory _factory;
        private readonly ISession _session;
        private readonly ITransaction _tx;

        public StubSessionManager()
        {
            if (_factory == null)
            {
                // Rebuild the test database and build the session factory.
                DatabaseVersionEngine engine = DatabaseHelper.BuildDatabaseVersionEngine(true);
                engine.DropDatabase();
                engine.Upgrade();

                _factory = DatabaseHelper.BuildSessionFactory(true);
            }
            _session = _factory.OpenSession();
            _tx = _session.BeginTransaction();
        }

        #region ISessionManager Members

        public ISession OpenSession()
        {
            return _session;
        }

        public ISession OpenSession(string alias)
        {
            throw new NotImplementedException();
        }

        public FlushMode DefaultFlushMode
        {
            get { throw new NotImplementedException(); }
            set { throw new NotImplementedException(); }
        }

        #endregion

        public void Flush()
        {
            _session.Flush();
        }

        public void Clear()
        {
            Flush();
            _session.Clear();
        }

        public void CleanUp()
        {
            _tx.Rollback();
            _session.Connection.Close();
            _session.Dispose();
            _factory.Dispose();
        }
    }
}