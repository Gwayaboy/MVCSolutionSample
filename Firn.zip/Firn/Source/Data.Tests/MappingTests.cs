using NHibernate.Cfg;
using NHibernate.Tool.hbm2ddl;
using NUnit.Framework;

namespace Intrigma.Firn.Data.Tests
{
    [TestFixture]
    public class MappingTests
    {
        [Test]
        public void CreateMappingTest()
        {
            Configuration cfg = DatabaseHelper.BuildConfiguration(true);
            var exporter = new SchemaExport(cfg);
            exporter.SetOutputFile("create.sql");
            exporter.Create(false, false);
        }
    }
}