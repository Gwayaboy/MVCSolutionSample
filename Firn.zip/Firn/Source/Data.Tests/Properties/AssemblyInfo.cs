﻿using System.Reflection;

[assembly: AssemblyTitle("Intrigma Firn Data Access Tests")]