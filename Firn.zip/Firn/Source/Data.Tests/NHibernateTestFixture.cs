using Intrigma.Firn.DomainModel.Tests;

namespace Intrigma.Firn.Data.Tests
{
    public class NHibernateTestFixture : MockTestFixture
    {
        private StubSessionManager _sessionManager;

        protected StubSessionManager SessionManager
        {
            get { return _sessionManager; }
        }

        public override void SetUp()
        {
            base.SetUp();
            _sessionManager = new StubSessionManager();
        }

        public override void TearDown()
        {
            if (_sessionManager != null)
            {
                _sessionManager.CleanUp();
            }
            base.TearDown();
        }
    }
}