using System;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;

namespace Intrigma.Firn.Data.Tests
{
    [TestFixture]
    public class AccountTransactionRepositoryTests : NHibernateTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _customerRepository = new CustomerRepository(SessionManager);
        }

        private CustomerRepository _customerRepository;

        [Test]
        public void OrderTransactionsByDateDesc()
        {
            var payment1 = new BaseTransaction(Create.AnyDate(), 345, string.Empty, string.Empty);
            var payment2 = new BaseTransaction(Create.AnyDate() + TimeSpan.FromDays(2), 345, string.Empty, string.Empty);
            var customer = new Customer();
            customer.AddTransaction(payment1);
            customer.AddTransaction(payment2);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            customer = _customerRepository.GetById(customer.Id);
            Assert.That(customer.Transactions[0].Id, Is.EqualTo(payment2.Id));
        }

        [Test]
        public void SaveAccountChargeTransaction()
        {
            var accountTransaction = new AccountChargeTransaction(Create.AnyDate(), 345, Create.AnyString(),
                                                                  string.Empty);
            var customer = new Customer();
            customer.AddTransaction(accountTransaction);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            customer = _customerRepository.GetById(customer.Id);
            Assert.That(customer.Transactions[0].Date, Is.EqualTo(accountTransaction.Date));
        }

        [Test]
        public void SaveAccountCreditTransaction()
        {
            var accountTransaction = new AccountCreditTransaction(Create.AnyDate(), 345, Create.AnyString());
            var customer = new Customer();
            customer.AddTransaction(accountTransaction);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            customer = _customerRepository.GetById(customer.Id);
            Assert.That(customer.Transactions[0].Date, Is.EqualTo(accountTransaction.Date));
        }

        [Test]
        public void SavePaymentTransactionBillingType()
        {
            var accountTransaction = new PaymentTransaction(Create.AnyDate(), 345, Create.NonDefaultBillingType());
            var customer = new Customer();
            customer.AddTransaction(accountTransaction);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            customer = _customerRepository.GetById(customer.Id);
            var gotIt = (PaymentTransaction) customer.Transactions[0];
            Assert.That(gotIt.Type, Is.EqualTo(accountTransaction.Type));
        }

        [Test]
        public void SaveRefundTransactionBillingType()
        {
            var accountTransaction = new RefundTransaction(Create.AnyDate(), 345, Create.AnyString(),
                                                           Create.NonDefaultBillingType());
            var customer = new Customer();
            customer.AddTransaction(accountTransaction);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            customer = _customerRepository.GetById(customer.Id);
            var gotIt = (RefundTransaction) customer.Transactions[0];
            Assert.That(gotIt.Type, Is.EqualTo(accountTransaction.Type));
        }

        [Test]
        public void SetBillableWeeksBeforeForInstallmentTransaction()
        {
            var accountTransaction = new InstallmentTransaction(Create.AnyDatePeriod(), 345, Create.AnyString(),
                                                                Create.AnyString(), 0, 5);
            var customer = new Customer();
            customer.AddTransaction(accountTransaction);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            customer = _customerRepository.GetById(customer.Id);
            var actual = (InstallmentTransaction) customer.Transactions[0];
            Assert.That(actual.BillableWeeksBefore, Is.EqualTo(accountTransaction.BillableWeeksBefore));
        }

        [Test]
        public void SetPeriodForInstallmentTransaction()
        {
            var accountTransaction = new InstallmentTransaction(Create.AnyDatePeriod(), 345, Create.AnyString(),
                                                                Create.AnyString(), 0, 0);
            var customer = new Customer();
            customer.AddTransaction(accountTransaction);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            customer = _customerRepository.GetById(customer.Id);
            var actual = (InstallmentTransaction) customer.Transactions[0];
            Assert.That(actual.Period, Is.EqualTo(accountTransaction.Period));
        }

        [Test]
        public void SetTransactionAmount()
        {
            var accountTransaction = new BaseTransaction(Create.AnyDate(), 345, string.Empty, string.Empty);
            var customer = new Customer();
            customer.AddTransaction(accountTransaction);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            customer = _customerRepository.GetById(customer.Id);
            BaseTransaction actual = customer.Transactions[0];
            Assert.That(actual.Amount, Is.EqualTo(accountTransaction.Amount));
        }

        [Test]
        public void SetTransactionDate()
        {
            var accountTransaction = new BaseTransaction(Create.AnyDate(), 345, string.Empty, string.Empty);
            var customer = new Customer();
            customer.AddTransaction(accountTransaction);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            customer = _customerRepository.GetById(customer.Id);
            BaseTransaction actual = customer.Transactions[0];
            Assert.That(actual.Date, Is.EqualTo(accountTransaction.Date));
        }

        [Test]
        public void SetTransactionDescription()
        {
            var accountTransaction = new BaseTransaction(Create.AnyDate(), 345, string.Empty, Create.AnyString());
            var customer = new Customer();
            customer.AddTransaction(accountTransaction);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            customer = _customerRepository.GetById(customer.Id);
            BaseTransaction actual = customer.Transactions[0];
            Assert.That(actual.Description, Is.EqualTo(accountTransaction.Description));
        }

        [Test]
        public void SetTransactionName()
        {
            var accountTransaction = new BaseTransaction(Create.AnyDate(), 345, Create.AnyString(), string.Empty);
            var customer = new Customer();
            customer.AddTransaction(accountTransaction);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            customer = _customerRepository.GetById(customer.Id);
            Assert.That(customer.Transactions[0].Name, Is.EqualTo(accountTransaction.Name));
        }
    }
}