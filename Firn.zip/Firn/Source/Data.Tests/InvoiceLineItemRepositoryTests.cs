using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;

namespace Intrigma.Firn.Data.Tests
{
    [TestFixture]
    public class InvoiceLineItemRepositoryTests : NHibernateTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _target = new NHibernateRepository<InvoiceLineItem>(SessionManager);
            _customerRepository = new CustomerRepository(SessionManager);
        }

        private NHibernateRepository<InvoiceLineItem> _target;
        private CustomerRepository _customerRepository;

        private static Customer CreateCustomerFromItem(InvoiceLineItem item)
        {
            var customer = new Customer();
            var invoice = new Invoice(customer, 5, Create.AnyDate(), Create.AnyDate());
            invoice.AddLineItem(item);
            return customer;
        }

        [Test]
        public void SetDate()
        {
            var item = new InvoiceLineItem(Create.AnyDate(), "asdfasdf", string.Empty, 5, 56);
            _customerRepository.Save(CreateCustomerFromItem(item));

            SessionManager.Clear();
            InvoiceLineItem retrieved = _target.GetById(item.Id);
            Assert.That(retrieved.Date, Is.EqualTo(item.Date));
        }

        [Test]
        public void SetDescription()
        {
            var item = new InvoiceLineItem(Create.AnyDate(), "asdfasdf", "description!", 5, 56);
            _customerRepository.Save(CreateCustomerFromItem(item));

            SessionManager.Clear();
            InvoiceLineItem retrieved = _target.GetById(item.Id);
            Assert.That(retrieved.Description, Is.EqualTo(item.Description));
        }

        [Test]
        public void SetName()
        {
            var item = new InvoiceLineItem(Create.AnyDate(), "asdfasdf", string.Empty, 5, 56);
            _customerRepository.Save(CreateCustomerFromItem(item));

            SessionManager.Clear();
            InvoiceLineItem retrieved = _target.GetById(item.Id);
            Assert.That(retrieved.Name, Is.EqualTo(item.Name));
        }

        [Test]
        public void SetPrice()
        {
            var item = new InvoiceLineItem(Create.AnyDate(), "asdfasdf", string.Empty, 5, 56);
            _customerRepository.Save(CreateCustomerFromItem(item));

            SessionManager.Clear();
            InvoiceLineItem retrieved = _target.GetById(item.Id);
            Assert.That(retrieved.Price, Is.EqualTo(item.Price));
        }

        [Test]
        public void SetStaffCount()
        {
            var item = new InvoiceLineItem(Create.AnyDate(), "asdfasdf", string.Empty, 5, 56);
            _customerRepository.Save(CreateCustomerFromItem(item));

            SessionManager.Clear();
            InvoiceLineItem retrieved = _target.GetById(item.Id);
            Assert.That(retrieved.StaffCount, Is.EqualTo(item.StaffCount));
        }

        [Test]
        public void SetStaffCountNull()
        {
            var item = new InvoiceLineItem(Create.AnyDate(), "asdfasdf", string.Empty, null, 56);
            _customerRepository.Save(CreateCustomerFromItem(item));

            SessionManager.Clear();
            InvoiceLineItem retrieved = _target.GetById(item.Id);
            Assert.That(retrieved.StaffCount, Is.EqualTo(item.StaffCount));
        }
    }
}