using System.Collections.Generic;
using System.Linq;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.PaymentGateway;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Data.Tests
{
    [TestFixture]
    public class InvoiceRepositoryTests : NHibernateTestFixture
    {
        #region Setup/Teardown

        public override void SetUp()
        {
            base.SetUp();
            _target = new InvoiceRepository(SessionManager);
            _customerRepository = new CustomerRepository(SessionManager);
        }

        #endregion

        private InvoiceRepository _target;
        private CustomerRepository _customerRepository;

        private static IList<int> GetIds<T>(IEnumerable<T> list) where T : IntegerKeyedObject
        {
            return list.Select(item => item.Id).ToList();
        }

        [Test]
        public void GetCustomer()
        {
            const int id = 4556;
            var customer = new Customer();
            new Invoice(customer, id, Create.AnyDate(), Create.AnyDate());
            _customerRepository.Save(customer);

            SessionManager.Clear();
            var retrieved = _target.GetById(id);
            Assert.That(retrieved.Customer.Id, Is.EqualTo(customer.Id));
        }

        [Test]
        public void GetLastInvoice()
        {
            var customer = new Customer();
            _customerRepository.Save(customer);
            var invoice1 = new Invoice(customer, 81, Create.AnyDate(), Create.AnyDate());
            _target.Save(invoice1);
            var invoice2 = new Invoice(customer, 83, Create.AnyDate(), Create.AnyDate());
            _target.Save(invoice2);
            var invoice3 = new Invoice(customer, 82, Create.AnyDate(), Create.AnyDate());
            _target.Save(invoice3);
            SessionManager.Clear();

            var retrieved = _target.LastInvoice();
            Assert.That(retrieved, Is.EqualTo(83));
        }

        [Test]
        public void GetLastInvoiceButThereAreNone()
        {
            Assert.That(_target.LastInvoice(), Is.EqualTo(0));
        }

        [Test]
        public void GetPayableInvoicesChecksCustomerBillingType()
        {
            var customer1 = new Customer {Id = 123};
            var customer2 = new Customer {Id = 3125, BillingType = BillingType.CreditCard};
            _customerRepository.Save(customer1);
            _customerRepository.Save(customer2);
            var date = Create.AnyDate();
            var invoice1 = new Invoice(customer1, 81, Create.AnyDate(), date);
            _target.Save(invoice1);
            var invoice2 = new Invoice(customer2, 83, Create.AnyDate(), date);
            _target.Save(invoice2);
            SessionManager.Clear();

            Assert.That(GetIds(_target.ListPayableInvoices(date)), Is.EqualTo(GetIds(new[] {invoice2})));
        }

        [Test]
        public void GetPayableInvoicesChecksDate()
        {
            var customer = new Customer {BillingType = BillingType.Eft};
            _customerRepository.Save(customer);
            var date = Create.AnyDate();
            var invoice1 = new Invoice(customer, 81, Create.AnyDate(), date.AddDays(-1));
            _target.Save(invoice1);
            var invoice2 = new Invoice(customer, 83, Create.AnyDate(), date);
            _target.Save(invoice2);
            var invoice3 = new Invoice(customer, 82, Create.AnyDate(), date.AddHours(5));
            _target.Save(invoice3);
            SessionManager.Clear();

            Assert.That(GetIds(_target.ListPayableInvoices(date)), Is.EqualTo(GetIds(new[] {invoice1, invoice2})));
        }

        [Test]
        public void GetPendingInvoices()
        {
            var customer = new Customer {BillingType = BillingType.Eft};
            _customerRepository.Save(customer);
            var date = Create.AnyDate();
            var invoice1 = new Invoice(customer, 81, Create.AnyDate(), date);
            invoice1.Cancel();
            _target.Save(invoice1);
            var invoice2 = new Invoice(customer, 83, Create.AnyDate(), date);
            _target.Save(invoice2);
            var invoice3 = new Invoice(customer, 82, Create.AnyDate(), date);
            invoice3.MarkPaid(Create.AnyDate());
            _target.Save(invoice3);
            SessionManager.Clear();

            Assert.That(GetIds(_target.ListPayableInvoices(date)), Is.EqualTo(GetIds(new[] {invoice2})));
        }

        [Test]
        public void OrderLineItemsByDate()
        {
            var customer = new Customer();
            var invoice = new Invoice(customer, 0, Create.AnyDate(), Create.AnyDate());
            var start = Create.AnyDate();
            invoice.AddLineItem(new InvoiceLineItem(start, string.Empty, string.Empty, null, 1));
            invoice.AddLineItem(new InvoiceLineItem(start.AddDays(1), string.Empty, string.Empty, null, 1));
            _customerRepository.Save(customer);

            SessionManager.Clear();
            var retrieved = _target.GetById(invoice.Id);
            Assert.That(retrieved.LineItems[0].Date, Is.EqualTo(start.AddDays(1)));
        }

        [Test]
        public void SetDueDate()
        {
            var customer = new Customer();
            var invoice = new Invoice(customer, 0, Create.AnyDate(), Create.AnyDate());
            _customerRepository.Save(customer);

            SessionManager.Clear();
            var retrieved = _target.GetById(invoice.Id);
            Assert.That(retrieved.DueDate, Is.EqualTo(invoice.DueDate));
        }

        [Test]
        public void SetInvoiceDate()
        {
            var customer = new Customer();
            var invoice = new Invoice(customer, 0, Create.AnyDate(), Create.AnyDate());
            _customerRepository.Save(customer);

            SessionManager.Clear();
            var retrieved = _target.GetById(invoice.Id);
            Assert.That(retrieved.InvoiceDate, Is.EqualTo(invoice.InvoiceDate));
        }

        [Test]
        public void SetInvoiceDatePaid()
        {
            var customer = new Customer();
            var gateway = DynamicMock<IPaymentGateway>();
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(true);
            SetupResult.For(result.RawMessage).Return(Create.UniqueString());
            SetupResult.For(gateway.MakePayment(customer, 0)).Return(result);
            var date = Create.AnyDate();
            ReplayAll();

            const int id = 4556;
            var invoice = new Invoice(customer, id, Create.AnyDate(), Create.AnyDate());
            invoice.Pay(date, gateway);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            var retrieved = _target.GetById(id);
            Assert.That(retrieved.DatePaid, Is.EqualTo(date));
        }

        [Test]
        public void SetInvoiceId()
        {
            const int id = 4556;
            var customer = new Customer();
            new Invoice(customer, id, Create.AnyDate(), Create.AnyDate());
            _customerRepository.Save(customer);

            SessionManager.Clear();
            var retrieved = _target.GetById(id);
            Assert.That(retrieved.Id, Is.EqualTo(id));
        }

        [Test]
        public void SetInvoicePaymentResult()
        {
            var customer = new Customer();
            var gateway = DynamicMock<IPaymentGateway>();
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.RawMessage).Return(Create.AnyString());
            SetupResult.For(gateway.MakePayment(customer, 0)).Return(result);
            ReplayAll();

            const int id = 4556;
            var invoice = new Invoice(customer, id, Create.AnyDate(), Create.AnyDate());
            invoice.Pay(Create.AnyDate(), gateway);
            _customerRepository.Save(customer);

            SessionManager.Clear();
            var retrieved = _target.GetById(id);
            Assert.That(retrieved.PaymentResult, Is.EqualTo(invoice.PaymentResult));
        }

        [Test]
        public void SetInvoicePaymentStatus()
        {
            const int id = 4556;
            var customer = new Customer();
            var invoice = new Invoice(customer, id, Create.AnyDate(), Create.AnyDate());
            invoice.Cancel();
            _customerRepository.Save(customer);

            SessionManager.Clear();
            var retrieved = _target.GetById(id);
            Assert.That(retrieved.PaymentStatus, Is.EqualTo(invoice.PaymentStatus));
        }

        [Test]
        public void SetTotal()
        {
            var customer = new Customer();
            var invoice = new Invoice(customer, 0, Create.AnyDate(), Create.AnyDate());
            invoice.AddLineItem(new InvoiceLineItem(Create.AnyDate(), string.Empty, string.Empty, null, 4));
            invoice.AddLineItem(new InvoiceLineItem(Create.AnyDate(), string.Empty, string.Empty, null, 6));
            _customerRepository.Save(customer);

            SessionManager.Clear();
            var retrieved = _target.GetById(invoice.Id);
            Assert.That(retrieved.Total, Is.EqualTo(invoice.Total));
        }
    }
}