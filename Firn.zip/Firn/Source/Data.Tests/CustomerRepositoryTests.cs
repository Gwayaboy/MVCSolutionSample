using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;

namespace Intrigma.Firn.Data.Tests
{
    [TestFixture]
    public class CustomerRepositoryTests : NHibernateTestFixture
    {
        #region Setup/Teardown

        public override void SetUp()
        {
            base.SetUp();
            _target = new CustomerRepository(SessionManager);
        }

        #endregion

        private CustomerRepository _target;

        [Test]
        public void ListTwoCustomersByName()
        {
            var customer1 = new Customer();
            var customer2 = new Customer();
            customer1.Id = 45;
            customer1.Name = "def";
            customer2.Id = 56;
            customer2.Name = "abc";
            _target.Save(customer1);
            _target.Save(customer2);

            SessionManager.Flush();
            Assert.That(_target.ListByName(), Is.EqualTo(new[] {customer2, customer1}));
        }

        [Test]
        public void NoCustomersToList()
        {
            Assert.That(_target.ListByName(), Is.Empty);
        }

        [Test]
        public void SetAttnFirstName()
        {
            var customer = new Customer {AttnFirstName = "asdfasdf"};
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(customer.Id);
            Assert.That(gotIt.AttnFirstName, Is.EqualTo(customer.AttnFirstName));
        }

        [Test]
        public void SetAttnLastName()
        {
            var customer = new Customer {AttnLastName = "asdfasdf"};
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(customer.Id);
            Assert.That(gotIt.AttnLastName, Is.EqualTo(customer.AttnLastName));
        }

        [Test]
        public void SetBillingNotes()
        {
            var customer = new Customer {BillingNotes = "asdfasdf"};
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(customer.Id);
            Assert.That(gotIt.BillingNotes, Is.EqualTo(customer.BillingNotes));
        }

        [Test]
        public void SetBillingPeriod()
        {
            var customer = new Customer {BillingPeriod = BillingPeriod.Quarterly};
            _target.Save(customer);

            SessionManager.Clear();
            var retrieved = _target.GetById(customer.Id);
            Assert.That(retrieved.BillingPeriod, Is.EqualTo(customer.BillingPeriod));
        }

        [Test]
        public void SetBillingStartDate()
        {
            var customer = new Customer {BillingStartDate = Create.AnyDate()};
            _target.Save(customer);

            SessionManager.Clear();
            var retrieved = _target.GetById(customer.Id);
            Assert.That(retrieved.BillingStartDate, Is.EqualTo(customer.BillingStartDate));
        }

        [Test]
        public void SetBillingType()
        {
            var customer = new Customer {BillingType = BillingType.Eft};
            _target.Save(customer);

            SessionManager.Clear();
            var retrieved = _target.GetById(customer.Id);
            Assert.That(retrieved.BillingType, Is.EqualTo(customer.BillingType));
        }

        [Test]
        public void SetCity()
        {
            var customer = new Customer {City = "stony brook"};
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(customer.Id);
            Assert.That(gotIt.City, Is.EqualTo(customer.City));
        }

        [Test]
        public void SetCurrentBalance()
        {
            var customer = Create.CustomerWithBalance(345);
            _target.Save(customer);

            SessionManager.Clear();
            var retrieved = _target.GetById(customer.Id);
            Assert.That(retrieved.EndingBalance, Is.EqualTo(customer.EndingBalance));
        }

        [Test]
        public void SetEmailAddress()
        {
            var customer = new Customer {EmailAddress = "stonybrook@ny.gov"};
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(customer.Id);
            Assert.That(gotIt.EmailAddress, Is.EqualTo(customer.EmailAddress));
        }

        [Test]
        public void SetId()
        {
            var customer = new Customer();
            const int id = 2435;
            customer.Id = id;
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(id);
            Assert.That(gotIt.Id, Is.EqualTo(id));
        }

        [Test]
        public void SetName()
        {
            var customer = new Customer {Name = "asdfasdffffff"};
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(customer.Id);
            Assert.That(gotIt.Name, Is.EqualTo(customer.Name));
        }

        [Test]
        public void SetNextInvoiceDate()
        {
            var customer = new Customer();
            Create.InvoiceForCustomer(customer);
            _target.Save(customer);

            SessionManager.Clear();
            var retrieved = _target.GetById(customer.Id);
            Assert.That(retrieved.NextInvoiceDate, Is.Not.Null);
        }

        [Test]
        public void SetNextSteps()
        {
            var customer = new Customer {NextSteps = "asdfasdf"};
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(customer.Id);
            Assert.That(gotIt.NextSteps, Is.EqualTo(customer.NextSteps));
        }

        [Test]
        public void SetNextStepsDate()
        {
            var customer = new Customer {NextStepsDate = Create.AnyDate()};
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(customer.Id);
            Assert.That(gotIt.NextStepsDate, Is.EqualTo(customer.NextStepsDate));
        }

        [Test]
        public void SetPaymentMethodId()
        {
            var customer = new Customer {PaymentMethodId = 5546};
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(customer.Id);
            Assert.That(gotIt.PaymentMethodId, Is.EqualTo(customer.PaymentMethodId));
        }

        [Test]
        public void SetPhone()
        {
            var customer = new Customer {Phone = "asdfasdf"};
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(customer.Id);
            Assert.That(gotIt.Phone, Is.EqualTo(customer.Phone));
        }

        [Test]
        public void SetSecondaryEmailAddresses()
        {
            var customer = new Customer();
            customer.SetSecondaryEmailAddresses(Create.Set(Create.UniqueEmailAddress(), Create.UniqueEmailAddress()));
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(customer.Id);
            Assert.That(gotIt.SecondaryEmailAddresses, Is.EquivalentTo(customer.SecondaryEmailAddresses));
        }

        [Test]
        public void SetState()
        {
            var customer = new Customer {State = "stony brook"};
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(customer.Id);
            Assert.That(gotIt.State, Is.EqualTo(customer.State));
        }

        [Test]
        public void SetStreetAddress1()
        {
            var customer = new Customer {StreetAddress1 = "my house"};
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(customer.Id);
            Assert.That(gotIt.StreetAddress1, Is.EqualTo(customer.StreetAddress1));
        }

        [Test]
        public void SetStreetAddress2()
        {
            var customer = new Customer {StreetAddress2 = "nassau hall"};
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(customer.Id);
            Assert.That(gotIt.StreetAddress2, Is.EqualTo(customer.StreetAddress2));
        }

        [Test]
        public void SetZip()
        {
            var customer = new Customer {Zip = "11790"};
            _target.Save(customer);

            SessionManager.Clear();
            var gotIt = _target.GetById(customer.Id);
            Assert.That(gotIt.Zip, Is.EqualTo(customer.Zip));
        }
    }
}