using System;
using Intrigma.Firn.Admin.Controllers;
using Intrigma.Firn.Core;
using Intrigma.Firn.Core.Tests.Web.Controllers;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.PaymentGateway;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Admin.Tests.Controllers
{
    [TestFixture]
    public class PaymentControllerTests : ControllerTestFixture<PaymentController>
    {
        private IRepository<Invoice> _invoiceRepository;
        private IPaymentManager _payment;
        private IRepository<Customer> _customerRepository;

        protected override PaymentController CreateController()
        {
            _invoiceRepository = DynamicMock<IRepository<Invoice>>();
            _customerRepository = DynamicMock<IRepository<Customer>>();
            _payment = DynamicMock<IPaymentManager>();
            return new PaymentController(_invoiceRepository, _payment, _customerRepository);
        }

        [Test]
        public void AddAccountChargeDoesIt()
        {
            const decimal amount = 345.6m;
            const int id = 345;
            var customer = DynamicMock<Customer>();
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            var name = Create.AnyString();
            var description = Create.AnyString();
            var date = Create.AnyDate();
            customer.AddAccountCharge(date, name, description, amount);
            ReplayAll();

            Controller.AddAccountCharge(id, date, name, description, amount);
        }

        [Test]
        public void AddAccountCreditDoesIt()
        {
            const decimal amount = 345.6m;
            const int id = 345;
            var customer = DynamicMock<Customer>();
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            var date = Create.AnyDate();
            var reason = Create.AnyString();
            customer.AddAccountCredit(date, amount, reason);
            ReplayAll();

            Controller.AddAccountCredit(id, date, amount, reason);
        }

        [Test]
        public void PaySetsInvoice()
        {
            const int id = 2434;
            var invoice = new Invoice();
            SetupResult.For(_invoiceRepository.GetById(id)).Return(invoice);
            ReplayAll();

            Controller.Pay(id, 435);
            Assert.That(Controller.PropertyBag[InvoiceConstants.Invoice], Is.SameAs(invoice));
        }

        [Test]
        public void PaySetsResult()
        {
            const int id = 2434;
            var invoice = new Invoice();
            SetupResult.For(_invoiceRepository.GetById(id)).Return(invoice);
            const decimal amount = 563.65m;
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(_payment.MakePayment(invoice, amount)).Return(result);
            ReplayAll();

            Controller.Pay(id, amount);
            Assert.That(Controller.PropertyBag[InvoiceConstants.PaymentResult], Is.SameAs(result));
        }

        [Test]
        public void RecordInvoicePaymentDoesIt()
        {
            const decimal amount = 345.6m;
            const int id = 345;
            var invoice = DynamicMock<Invoice>();
            SetupResult.For(_invoiceRepository.GetById(id)).Return(invoice);
            var billingType = Create.NonDefaultBillingType();
            var date = Create.AnyDate();
            invoice.RecordPayment(date, billingType, amount);
            ReplayAll();

            Controller.RecordInvoicePayment(id, date, billingType, amount);
        }

        [Test]
        public void RecordInvoicePaymentRedirectsBackToView()
        {
            const decimal amount = 345.6m;
            const int id = 345;
            var invoice = DynamicMock<Invoice>();
            SetupResult.For(_invoiceRepository.GetById(id)).Return(invoice);
            var billingType = Create.NonDefaultBillingType();
            var date = Create.AnyDate();
            ReplayAll();

            Controller.RecordInvoicePayment(id, date, billingType, amount);
            Assert.That(Response.RedirectedTo, Is.EqualTo("/Invoice/View.castle?id=" + id));
        }

        [Test]
        public void RecordPaymentDoesIt()
        {
            const decimal amount = 345.6m;
            const int id = 345;
            var customer = DynamicMock<Customer>();
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            var billingType = Create.NonDefaultBillingType();
            var date = Create.AnyDate();
            customer.RecordPayment(date, billingType, amount);
            ReplayAll();

            Controller.RecordPayment(id, date, billingType, amount);
        }

        [Test]
        public void RedirectAfterAddingAccountCharge()
        {
            const int id = 345;
            var customer = DynamicMock<Customer>();
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.AddAccountCharge(id, default(DateTime), null, null, 43);
            Assert.That(Response.RedirectedTo, Is.EqualTo("/Customer/View.castle?id=" + id));
        }

        [Test]
        public void RedirectAfterAddingAccountCredit()
        {
            const int id = 345;
            var customer = DynamicMock<Customer>();
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.AddAccountCredit(id, default(DateTime), 43, null);
            Assert.That(Response.RedirectedTo, Is.EqualTo("/Customer/View.castle?id=" + id));
        }

        [Test]
        public void RedirectAfterRecordPayment()
        {
            const int id = 345;
            var customer = DynamicMock<Customer>();
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.RecordPayment(id, default(DateTime), default(BillingType), 43);
            Assert.That(Response.RedirectedTo, Is.EqualTo("/Customer/View.castle?id=" + id));
        }

        [Test]
        public void RefundSetsCustomer()
        {
            const int id = 2434;
            var customer = new Customer();
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.Refund(id, null, 435);
            Assert.That(Controller.PropertyBag[CustomerConstants.Customer], Is.SameAs(customer));
        }

        [Test]
        public void RefundSetsResult()
        {
            const int id = 2434;
            var customer = new Customer();
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            const decimal amount = 563.65m;
            var reason = Create.AnyString();
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(_payment.IssueRefund(customer, amount, reason)).Return(result);
            ReplayAll();

            Controller.Refund(id, reason, amount);
            Assert.That(Controller.PropertyBag[InvoiceConstants.PaymentResult], Is.SameAs(result));
        }

        [Test]
        public void ShowAccountChargeSetsCustomer()
        {
            const int id = 2434;
            var customer = new Customer();
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.ShowAccountCharge(id);
            Assert.That(Controller.PropertyBag[CustomerConstants.Customer], Is.SameAs(customer));
        }

        [Test]
        public void ShowAccountCreditSetsCustomer()
        {
            const int id = 2434;
            var customer = new Customer();
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.ShowAccountCredit(id);
            Assert.That(Controller.PropertyBag[CustomerConstants.Customer], Is.SameAs(customer));
        }

        [Test]
        public void ShowRecordInvoicePaymentSetsInvoice()
        {
            const int id = 2434;
            var invoice = new Invoice();
            SetupResult.For(_invoiceRepository.GetById(id)).Return(invoice);
            ReplayAll();

            Controller.ShowRecordInvoicePayment(id);
            Assert.That(Controller.PropertyBag[InvoiceConstants.Invoice], Is.SameAs(invoice));
        }

        [Test]
        public void ShowRecordPaymentSetsCustomer()
        {
            const int id = 2434;
            var customer = new Customer();
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.ShowRecordPayment(id);
            Assert.That(Controller.PropertyBag[CustomerConstants.Customer], Is.SameAs(customer));
        }

        [Test]
        public void ShowRefundSetsCustomer()
        {
            const int id = 2434;
            var customer = new Customer();
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.ShowRefund(id);
            Assert.That(Controller.PropertyBag[CustomerConstants.Customer], Is.SameAs(customer));
        }

        [Test]
        public void ShowSetsInvoice()
        {
            const int id = 2434;
            var invoice = new Invoice();
            SetupResult.For(_invoiceRepository.GetById(id)).Return(invoice);
            ReplayAll();

            Controller.ShowPayment(id);
            Assert.That(Controller.PropertyBag[InvoiceConstants.Invoice], Is.SameAs(invoice));
        }
    }
}