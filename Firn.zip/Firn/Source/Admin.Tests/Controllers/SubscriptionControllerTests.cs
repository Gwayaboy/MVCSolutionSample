using System;
using Intrigma.Firn.Admin.Controllers;
using Intrigma.Firn.Core;
using Intrigma.Firn.Core.Tests.Web.Controllers;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Admin.Tests.Controllers
{
    [TestFixture]
    public class SubscriptionControllerTests : ControllerTestFixture<SubscriptionController>
    {
        private ICustomerRepository _customerRepository;
        private IRepository<Subscription> _subscriptionRepository;

        protected override SubscriptionController CreateController()
        {
            _customerRepository = DynamicMock<ICustomerRepository>();
            _subscriptionRepository = DynamicMock<IRepository<Subscription>>();
            return new SubscriptionController(_customerRepository, _subscriptionRepository);
        }

        [Test]
        public void DoNotAddNewSubscriptionWhenUpdating()
        {
            var customer = new Customer();
            Subscription subscription = Create.Subscription();
            int customerId = 3456;
            int id = 235;
            SetupResult.For(_customerRepository.GetById(customerId)).Return(customer);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            Controller.Update(customerId, id, 0, null, null, default(DateTime), 1, 0, 0);
            Assert.That(customer.Subscriptions, Is.Empty);
        }

        [Test]
        public void ShowSetsBillableWeeksBefore()
        {
            int id = 3456;
            var subscription = new Subscription(null, null, Create.AnyDate(), 12, 1, 100, 5);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            Controller.Show(5, id);
            Assert.That(Controller.PropertyBag[SubscriptionConstants.BillableWeeksBefore],
                        Is.EqualTo(subscription.Transaction.BillableWeeksBefore));
        }

        [Test]
        public void ShowSetsCustomer()
        {
            var customer = new Customer();
            int id = 3456;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.Show(id, null);
            Assert.That(Controller.PropertyBag[CustomerConstants.Customer], Is.SameAs(customer));
        }

        [Test]
        public void ShowSetsDefaultBillableWeeksBeforeForNewSubscription()
        {
            ReplayAll();

            Controller.Show(5, null);
            Assert.That(Controller.PropertyBag[SubscriptionConstants.BillableWeeksBefore],
                        Is.EqualTo(InstallmentTransaction.DefaultBillableWeeksBefore));
        }

        [Test]
        public void ShowSetsDescription()
        {
            int id = 3456;
            var subscription = new Subscription(null, Create.AnyString(), default(DateTime), 1, 1, 1, 0);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            Controller.Show(5, id);
            Assert.That(Controller.PropertyBag[SubscriptionConstants.Description],
                        Is.EqualTo(subscription.Transaction.Description));
        }

        [Test]
        public void ShowSetsMonths()
        {
            int id = 3456;
            var subscription = new Subscription(null, null, Create.AnyDate(), 12, 1, 1, 0);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            Controller.Show(5, id);
            Assert.That(Controller.PropertyBag[SubscriptionConstants.Months], Is.EqualTo(subscription.Months));
        }

        [Test]
        public void ShowSetsName()
        {
            int id = 3456;
            var subscription = new Subscription(Create.AnyString(), null, default(DateTime), 1, 1, 1, 0);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            Controller.Show(5, id);
            Assert.That(Controller.PropertyBag[SubscriptionConstants.Name], Is.EqualTo(subscription.Transaction.Name));
        }

        [Test]
        public void ShowSetsPrice()
        {
            int id = 3456;
            var subscription = new Subscription(null, null, Create.AnyDate(), 12, 100.5m, 1, 0);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            Controller.Show(5, id);
            Assert.That(Controller.PropertyBag[SubscriptionConstants.Amount],
                        Is.EqualTo(subscription.Transaction.Amount));
        }

        [Test]
        public void ShowSetsStaffCount()
        {
            int id = 3456;
            var subscription = new Subscription(null, null, Create.AnyDate(), 12, 1, 100, 0);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            Controller.Show(5, id);
            Assert.That(Controller.PropertyBag[SubscriptionConstants.StaffCount], Is.EqualTo(subscription.StaffCount));
        }

        [Test]
        public void ShowSetsStartDate()
        {
            int id = 3456;
            var subscription = new Subscription(null, null, Create.AnyDate(), 1, 1, 1, 0);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            Controller.Show(5, id);
            Assert.That(Controller.PropertyBag[SubscriptionConstants.StartDate],
                        Is.EqualTo(subscription.Transaction.Date));
        }

        [Test]
        public void ShowSetsSubscriptionId()
        {
            int id = 3456;
            var subscription = new Subscription(Create.AnyString(), null, default(DateTime), 1, 1, 1, 0);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            Controller.Show(5, id);
            Assert.That(Controller.PropertyBag[SubscriptionConstants.Id], Is.EqualTo(id));
        }

        [Test]
        public void UpdateAddsSubscriptionWithAmount()
        {
            var customer = new Customer();
            int id = 3456;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            decimal amount = 2356;
            Controller.Update(id, null, amount, null, null, default(DateTime), 1, 0, 0);
            Assert.That(customer.Subscriptions[0].Transaction.Amount, Is.EqualTo(amount));
        }

        [Test]
        public void UpdateAddsSubscriptionWithBillableWeeksBefore()
        {
            var customer = new Customer();
            int id = 3456;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            int value = 346;
            Controller.Update(id, null, 346, null, null, default(DateTime), 1, 0, value);
            Assert.That(customer.Subscriptions[0].Transaction.BillableWeeksBefore, Is.EqualTo(value));
        }

        [Test]
        public void UpdateAddsSubscriptionWithDescription()
        {
            var customer = new Customer();
            int id = 3456;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            string description = Create.AnyString();
            Controller.Update(id, null, 346, null, description, default(DateTime), 1, 0, 0);
            Assert.That(customer.Subscriptions[0].Transaction.Description, Is.EqualTo(description));
        }

        [Test]
        public void UpdateAddsSubscriptionWithMonths()
        {
            var customer = new Customer();
            int id = 3456;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            int months = 2;
            Controller.Update(id, null, 346, null, null, Create.AnyDate(), months, 0, 0);
            Assert.That(customer.Subscriptions[0].Months, Is.EqualTo(months));
        }

        [Test]
        public void UpdateAddsSubscriptionWithName()
        {
            var customer = new Customer();
            int id = 3456;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            string name = Create.AnyString();
            Controller.Update(id, null, 346, name, null, default(DateTime), 1, 0, 0);
            Assert.That(customer.Subscriptions[0].Transaction.Name, Is.EqualTo(name));
        }

        [Test]
        public void UpdateAddsSubscriptionWithStaffCount()
        {
            var customer = new Customer();
            int id = 3456;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            int value = 346;
            Controller.Update(id, null, 346, null, null, default(DateTime), 1, value, 0);
            Assert.That(customer.Subscriptions[0].StaffCount, Is.EqualTo(value));
        }

        [Test]
        public void UpdateAddsSubscriptionWithStartDate()
        {
            var customer = new Customer();
            int id = 3456;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            DateTime startDate = Create.AnyDate();
            Controller.Update(id, null, 346, null, null, startDate, 1, 0, 0);
            Assert.That(customer.Subscriptions[0].Transaction.Date, Is.EqualTo(startDate));
        }

        [Test]
        public void UpdateAmount()
        {
            var customer = new Customer();
            Subscription subscription = Create.Subscription();
            int customerId = 3456;
            int id = 235;
            SetupResult.For(_customerRepository.GetById(customerId)).Return(customer);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            decimal amount = 346;
            Controller.Update(customerId, id, amount, null, null, default(DateTime), 1, 0, 0);
            Assert.That(subscription.Transaction.Amount, Is.EqualTo(amount));
        }

        [Test]
        public void UpdateBillableWeeksBefore()
        {
            var customer = new Customer();
            Subscription subscription = Create.Subscription();
            int customerId = 3456;
            int id = 235;
            SetupResult.For(_customerRepository.GetById(customerId)).Return(customer);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            int billableWeeksBefore = 346;
            Controller.Update(customerId, id, 0, null, null, default(DateTime), 1, 0, billableWeeksBefore);
            Assert.That(subscription.Transaction.BillableWeeksBefore, Is.EqualTo(billableWeeksBefore));
        }

        [Test]
        public void UpdateDescription()
        {
            var customer = new Customer();
            Subscription subscription = Create.Subscription();
            int customerId = 3456;
            int id = 235;
            SetupResult.For(_customerRepository.GetById(customerId)).Return(customer);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            string description = Create.UniqueString();
            Controller.Update(customerId, id, 0, null, description, default(DateTime), 1, 0, 0);
            Assert.That(subscription.Transaction.Description, Is.EqualTo(description));
        }

        [Test]
        public void UpdateMonths()
        {
            var customer = new Customer();
            Subscription subscription = Create.Subscription();
            int customerId = 3456;
            int id = 235;
            SetupResult.For(_customerRepository.GetById(customerId)).Return(customer);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            int months = 3;
            Controller.Update(customerId, id, 0, null, null, default(DateTime), months, 0, 0);
            Assert.That(subscription.Months, Is.EqualTo(months));
        }

        [Test]
        public void UpdateName()
        {
            var customer = new Customer();
            Subscription subscription = Create.Subscription();
            int customerId = 3456;
            int id = 235;
            SetupResult.For(_customerRepository.GetById(customerId)).Return(customer);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            string name = Create.UniqueString();
            Controller.Update(customerId, id, 0, name, null, default(DateTime), 1, 0, 0);
            Assert.That(subscription.Transaction.Name, Is.EqualTo(name));
        }

        [Test]
        public void UpdateRedirectsWhenFinished()
        {
            var customer = new Customer();
            int id = 3456;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.Update(id, null, 2345, null, null, default(DateTime), 1, 0, 0);
            Assert.That(Response.RedirectedTo, Is.EqualTo("/Customer/View.castle?id=" + id));
        }

        [Test]
        public void UpdateSavesCustomer()
        {
            var customer = new Customer();
            int id = 3456;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            _customerRepository.Save(customer);
            ReplayAll();

            Controller.Update(id, null, 2345, null, null, default(DateTime), 1, 0, 0);
        }

        [Test]
        public void UpdateStaffCount()
        {
            var customer = new Customer();
            Subscription subscription = Create.Subscription();
            int customerId = 3456;
            int id = 235;
            SetupResult.For(_customerRepository.GetById(customerId)).Return(customer);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            int staffCount = 346;
            Controller.Update(customerId, id, 0, null, null, default(DateTime), 1, staffCount, 0);
            Assert.That(subscription.StaffCount, Is.EqualTo(staffCount));
        }

        [Test]
        public void UpdateStartDate()
        {
            var customer = new Customer();
            Subscription subscription = Create.Subscription();
            int customerId = 3456;
            int id = 235;
            SetupResult.For(_customerRepository.GetById(customerId)).Return(customer);
            SetupResult.For(_subscriptionRepository.GetById(id)).Return(subscription);
            ReplayAll();

            DateTime startDate = Create.AnyDate();
            Controller.Update(customerId, id, 0, null, null, startDate, 1, 0, 0);
            Assert.That(subscription.Transaction.Date, Is.EqualTo(startDate));
        }
    }
}