using Intrigma.Firn.Admin.Controllers;
using Intrigma.Firn.Core.Tests.Web.Controllers;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Admin.Tests.Controllers
{
    [TestFixture]
    public class HomeControllerTests : ControllerTestFixture<HomeController>
    {
        private ICustomerRepository _customerRepository;

        protected override HomeController CreateController()
        {
            _customerRepository = DynamicMock<ICustomerRepository>();
            return new HomeController(_customerRepository);
        }

        [Test]
        public void IndexSetsListOfCustomers()
        {
            var customers = new[] {new Customer(),};
            SetupResult.For(_customerRepository.ListByName()).Return(customers);
            ReplayAll();

            Controller.Index();
            Assert.That(Controller.PropertyBag["customers"], Is.SameAs(customers));
        }
    }
}