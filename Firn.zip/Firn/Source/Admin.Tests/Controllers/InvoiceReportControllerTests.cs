using Castle.MonoRail.Framework;
using Castle.MonoRail.Framework.Test;
using Intrigma.Firn.Admin.Controllers;
using Intrigma.Firn.Core.InvoiceReport;
using Intrigma.Firn.Core.Tests.Web.Controllers;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Admin.Tests.Controllers
{
    [TestFixture]
    public class InvoiceReportControllerTests : ControllerTestFixture<InvoiceReportController>
    {
        public override void Init()
        {
            base.Init();
            Mocks.BackToRecordAll();
        }

        private IRepository<Invoice> _repository;
        private IInvoiceReportBuilder _reportBuilder;
        private IReportPdfExporter _pdfExporter;
        private IInvoiceMailer _invoiceMailer;

        protected override IMockResponse BuildResponse(UrlInfo info)
        {
            return DynamicMock<IMockResponse>();
        }

        protected override InvoiceReportController CreateController()
        {
            _repository = DynamicMock<IRepository<Invoice>>();
            _pdfExporter = DynamicMock<IReportPdfExporter>();
            _reportBuilder = DynamicMock<IInvoiceReportBuilder>();
            _invoiceMailer = DynamicMock<IInvoiceMailer>();
            return new InvoiceReportController(_repository, _pdfExporter, _reportBuilder, _invoiceMailer);
        }

        [Test]
        public void CancelViewWhenShowingReport()
        {
            ReplayAll();

            Controller.View(4);
            Assert.That(Controller.SelectedViewName, Is.Null);
        }

        [Test]
        public void EmailSetsInvoiceInView()
        {
            int id = 546;
            var invoice = new Invoice();
            SetupResult.For(_repository.GetById(id)).Return(invoice);
            ReplayAll();

            Controller.Email(id);
            Assert.That(Controller.PropertyBag["invoice"], Is.SameAs(invoice));
        }

        [Test]
        public void SendEmailAndSetResults()
        {
            int id = 546;
            var invoice = new Invoice();
            SetupResult.For(_repository.GetById(id)).Return(invoice);
            string results = Create.AnyString();
            SetupResult.For(_invoiceMailer.Mail(invoice)).Return(results);
            ReplayAll();

            Controller.Email(id);
            Assert.That(Controller.PropertyBag[InvoiceConstants.EmailResults], Is.EqualTo(results));
        }

        [Test]
        public void SetContentType()
        {
            Response.ContentType = InvoiceReportController.PdfContentType;
            ReplayAll();

            Controller.View(45);
        }

        [Test]
        public void WriteReportBytes()
        {
            int id = 546;
            var invoice = new Invoice();
            SetupResult.For(_repository.GetById(id)).Return(invoice);
            var report = DynamicMock<IInvoiceReport>();
            byte[] contents = {1, 4, 6, 7};
            SetupResult.For(_reportBuilder.Build(invoice)).Return(report);
            SetupResult.For(_pdfExporter.Export(report)).Return(contents);
            Response.BinaryWrite(contents);
            ReplayAll();

            Controller.View(id);
        }
    }
}