using System;
using Intrigma.Firn.Admin.Controllers;
using Intrigma.Firn.Core;
using Intrigma.Firn.Core.Tests.Web.Controllers;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Admin.Tests.Controllers
{
    [TestFixture]
    public class InvoiceControllerTests : ControllerTestFixture<InvoiceController>
    {
        private ICurrentDateFetcher _date;
        private INextInvoiceNumber _invoiceNumber;
        private IInvoiceRepository _invoiceRepository;
        private IInvoiceFactory _invoiceFactory;
        private ICustomerRepository _customerRepository;
        private ICustomerInvoiceCreator _invoiceGenerator;

        protected override InvoiceController CreateController()
        {
            _date = DynamicMock<ICurrentDateFetcher>();
            _invoiceNumber = DynamicMock<INextInvoiceNumber>();
            _invoiceRepository = DynamicMock<IInvoiceRepository>();
            _invoiceFactory = DynamicMock<IInvoiceFactory>();
            _customerRepository = DynamicMock<ICustomerRepository>();
            _invoiceGenerator = DynamicMock<ICustomerInvoiceCreator>();
            return new InvoiceController(_date, _invoiceNumber, _invoiceRepository, _invoiceFactory, _customerRepository,
                                         _invoiceGenerator);
        }

        [Test]
        public void CancelInvoice()
        {
            const int id = 453245;
            var invoice = DynamicMock<Invoice>();
            SetupResult.For(_invoiceRepository.GetById(id)).Return(invoice);
            invoice.Cancel();
            ReplayAll();

            Controller.Cancel(id);
        }

        [Test]
        public void CancelInvoiceAndRedirectToViewPage()
        {
            const int id = 453245;
            var invoice = DynamicMock<Invoice>();
            SetupResult.For(_invoiceRepository.GetById(id)).Return(invoice);
            ReplayAll();

            Controller.Cancel(id);
            Assert.That(Response.RedirectedTo, Is.EqualTo("/Controller/View.castle?id=" + id));
        }

        [Test]
        public void CancelInvoiceAndSaveIt()
        {
            const int id = 453245;
            var invoice = DynamicMock<Invoice>();
            SetupResult.For(_invoiceRepository.GetById(id)).Return(invoice);
            _invoiceRepository.Save(invoice);
            ReplayAll();

            Controller.Cancel(id);
        }

        [Test]
        public void CreateSetsCustomerInBag()
        {
            const int id = 234;
            var customer = new Customer();
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.Create(id);
            Assert.That(Controller.PropertyBag[CustomerConstants.Customer], Is.SameAs(customer));
        }

        [Test]
        public void CreateSetsDueDateInBag()
        {
            var now = Create.AnyDate();
            SetupResult.For(_date.Now).Return(now);
            ReplayAll();

            Controller.Create(0);
            Assert.That(Controller.PropertyBag[InvoiceConstants.DueDate], Is.EqualTo(now.ToShortDateString()));
        }

        [Test]
        public void CreateSetsInvoiceDateInBag()
        {
            var now = Create.AnyDate();
            SetupResult.For(_date.Now).Return(now);
            ReplayAll();

            Controller.Create(0);
            Assert.That(Controller.PropertyBag[InvoiceConstants.InvoiceDate], Is.EqualTo(now.ToShortDateString()));
        }

        [Test]
        public void CreateSetsInvoiceNumberInBag()
        {
            const int num = 234;
            SetupResult.For(_invoiceNumber.Next).Return(num);
            ReplayAll();

            Controller.Create(0);
            Assert.That(Controller.PropertyBag[InvoiceConstants.InvoiceNumber], Is.EqualTo(num));
        }

        [Test]
        public void GenerateInvoiceForCustomerAndSetResultsInView()
        {
            var date = Create.AnyDate();
            SetupResult.For(_date.Now).Return(date);
            var customer = new Customer();
            const int id = 345;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            var invoice = new Invoice();
            SetupResult.For(_invoiceGenerator.CreateFor(customer, date)).Return(invoice);
            ReplayAll();

            Controller.Generate(id);
            Assert.That(Controller.PropertyBag[InvoiceConstants.Invoice], Is.SameAs(invoice));
        }

        [Test]
        public void GenerateSetsCustomerInView()
        {
            var date = Create.AnyDate();
            SetupResult.For(_date.Now).Return(date);
            var customer = new Customer();
            const int id = 345;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.Generate(id);
            Assert.That(Controller.PropertyBag[CustomerConstants.Customer], Is.SameAs(customer));
        }

        [Test]
        public void MarkPaidInvoice()
        {
            const int id = 453245;
            var invoice = DynamicMock<Invoice>();
            SetupResult.For(_invoiceRepository.GetById(id)).Return(invoice);
            var date = Create.AnyDate();
            SetupResult.For(_date.Now).Return(date);
            invoice.MarkPaid(date);
            ReplayAll();

            Controller.MarkPaid(id);
        }

        [Test]
        public void MarkPaidInvoiceAndRedirectToViewPage()
        {
            const int id = 453245;
            var invoice = DynamicMock<Invoice>();
            SetupResult.For(_invoiceRepository.GetById(id)).Return(invoice);
            ReplayAll();

            Controller.MarkPaid(id);
            Assert.That(Response.RedirectedTo, Is.EqualTo("/Controller/View.castle?id=" + id));
        }

        [Test]
        public void MarkPaidInvoiceAndSaveIt()
        {
            const int id = 453245;
            var invoice = DynamicMock<Invoice>();
            SetupResult.For(_invoiceRepository.GetById(id)).Return(invoice);
            _invoiceRepository.Save(invoice);
            ReplayAll();

            Controller.MarkPaid(id);
        }

        [Test]
        public void SubmitClickedAddsOneLineItem()
        {
            var invoice = new Invoice();
            const int customerId = 234;
            var customer = new Customer();
            SetupResult.For(_customerRepository.GetById(customerId)).Return(customer);
            SetupResult.For(_invoiceFactory.Create(customer, Create.AnyDate(), Create.AnyDate(), 0)).Return(invoice);
            LastCall.IgnoreArguments();
            const string name = "name1";
            const string descr = "descr1";
            const int count = 100;
            const decimal price = 2333;
            var item = new InvoiceLineItemModel(Create.AnyDate(), name, descr, count, price);
            ReplayAll();

            Controller.SubmitClicked(Create.AnyDate(), Create.AnyDate(), 0, customerId, new[] {item});
            Assert.That(invoice.LineItems.Count, Is.EqualTo(1));
            Assert.That(invoice.LineItems[0].Date, Is.EqualTo(item.Date));
            Assert.That(invoice.LineItems[0].Name, Is.EqualTo(name));
            Assert.That(invoice.LineItems[0].Description, Is.EqualTo(descr));
            Assert.That(invoice.LineItems[0].StaffCount, Is.EqualTo(count));
            Assert.That(invoice.LineItems[0].Price, Is.EqualTo(price));
        }

        [Test]
        public void SubmitClickedAddsTwoLineItems()
        {
            // ugh. kill me now.
            var invoice = new Invoice();
            SetupResult.For(_invoiceFactory.Create(null, Create.AnyDate(), Create.AnyDate(), 0)).Return(invoice);
            LastCall.IgnoreArguments();
            const string name1 = "name1";
            const string descr1 = "descr1";
            const int count1 = 100;
            const decimal price1 = 2333;
            const string name2 = "name2";
            const string descr2 = "descr2";
            int? count2 = null;
            const decimal price2 = 2333;
            var item1 = new InvoiceLineItemModel(default(DateTime), name1, descr1, count1, price1);
            var item2 = new InvoiceLineItemModel(default(DateTime), name2, descr2, count2, price2);
            ReplayAll();

            Controller.SubmitClicked(Create.AnyDate(), Create.AnyDate(), 0, 0, new[] {item1, item2});
            Assert.That(invoice.LineItems.Count, Is.EqualTo(2));
            Assert.That(invoice.LineItems[0].Name, Is.EqualTo(name1));
            Assert.That(invoice.LineItems[0].Description, Is.EqualTo(descr1));
            Assert.That(invoice.LineItems[0].StaffCount, Is.EqualTo(count1));
            Assert.That(invoice.LineItems[0].Price, Is.EqualTo(price1));

            Assert.That(invoice.LineItems[1].Name, Is.EqualTo(name2));
            Assert.That(invoice.LineItems[1].Description, Is.EqualTo(descr2));
            Assert.That(invoice.LineItems[1].StaffCount, Is.EqualTo(count2));
            Assert.That(invoice.LineItems[1].Price, Is.EqualTo(price2));
        }

        [Test]
        public void SubmitClickedRedirectsToInvoice()
        {
            var invoice = new Invoice();
            const int id = 2134;
            invoice.Id = id;
            SetupResult.For(_invoiceFactory.Create(null, Create.AnyDate(), Create.AnyDate(), 0)).Return(invoice);
            LastCall.IgnoreArguments();
            ReplayAll();

            Controller.SubmitClicked(Create.AnyDate(), Create.AnyDate(), 0, 0, new InvoiceLineItemModel[0]);
            Assert.That(Response.RedirectedTo, Is.EqualTo("/Controller/View.castle?id=" + id));
        }

        [Test]
        public void SubmitClickedSavesInvoice()
        {
            var invoice = new Invoice();
            SetupResult.For(_invoiceFactory.Create(null, Create.AnyDate(), Create.AnyDate(), 0)).Return(invoice);
            LastCall.IgnoreArguments();
            _invoiceRepository.Save(invoice);
            ReplayAll();

            Controller.SubmitClicked(Create.AnyDate(), Create.AnyDate(), 0, 0, new InvoiceLineItemModel[0]);
        }

        [Test]
        public void SubmitClickedUsesFactory()
        {
            var invoice = new Invoice();
            var invoiceDate = new DateTime(2008, 4, 2);
            var dueDate = new DateTime(2007, 1, 1);
            const int invoiceNum = 234;
            const int customerId = 658;
            var customer = new Customer();
            SetupResult.For(_customerRepository.GetById(customerId)).Return(customer);
            SetupResult.For(_invoiceFactory.Create(customer, invoiceDate, dueDate, invoiceNum)).Return(invoice);
            ReplayAll();

            Controller.SubmitClicked(invoiceDate, dueDate, invoiceNum, customerId, new InvoiceLineItemModel[0]);
        }

        [Test]
        public void ViewSetsInvoice()
        {
            const int id = 453245;
            var invoice = new Invoice();
            SetupResult.For(_invoiceRepository.GetById(id)).Return(invoice);
            ReplayAll();

            Controller.Create(0);
            Controller.View(id);
            Assert.That(Controller.PropertyBag["invoice"], Is.SameAs(invoice));
        }
    }
}