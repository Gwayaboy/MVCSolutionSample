using System;
using Intrigma.Firn.Admin.Controllers;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;

namespace Intrigma.Firn.Admin.Tests.Controllers
{
    [TestFixture]
    public class InvoiceLineItemModelTests
    {
        [Test]
        public void Ctor()
        {
            const string name = "name";
            const string description = "description";
            const int staffCount = 2342;
            const decimal price = 234;
            DateTime date = Create.AnyDate();
            var target = new InvoiceLineItemModel(date, name, description, staffCount, price);
            Assert.That(target.Name, Is.EqualTo(name));
            Assert.That(target.Description, Is.EqualTo(description));
            Assert.That(target.StaffCount, Is.EqualTo(staffCount));
            Assert.That(target.Price, Is.EqualTo(price));
            Assert.That(target.Date, Is.EqualTo(date));
        }

        [Test]
        public void Date()
        {
            var target = new InvoiceLineItemModel();
            DateTime date = Create.AnyDate();
            target.Date = date;
            Assert.That(target.Date, Is.EqualTo(date));
        }

        [Test]
        public void Description()
        {
            var target = new InvoiceLineItemModel();
            const string description = "descr";
            target.Description = description;
            Assert.That(target.Description, Is.EqualTo(description));
        }

        [Test]
        public void Name()
        {
            var target = new InvoiceLineItemModel();
            const string name = "name";
            target.Name = name;
            Assert.That(target.Name, Is.EqualTo(name));
        }

        [Test]
        public void Price()
        {
            var target = new InvoiceLineItemModel();
            const decimal price = 235.13m;
            target.Price = price;
            Assert.That(target.Price, Is.EqualTo(price));
        }

        [Test]
        public void StaffCount()
        {
            var target = new InvoiceLineItemModel();
            const int count = 235;
            target.StaffCount = count;
            Assert.That(target.StaffCount, Is.EqualTo(count));
        }
    }
}