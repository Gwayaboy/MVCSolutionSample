using System;
using Intrigma.Firn.Admin.Controllers;
using Intrigma.Firn.DomainModel;
using NUnit.Framework;

namespace Intrigma.Firn.Admin.Tests.Controllers
{
    [TestFixture]
    public class InvoiceFactoryTests
    {
        [Test]
        public void Create()
        {
            var target = new InvoiceFactory();
            var invoiceDate = new DateTime(2007, 3, 2);
            var dueDate = new DateTime(2004, 2, 1);
            const int invoiceNum = 235;
            var customer = new Customer();

            Invoice result = target.Create(customer, invoiceDate, dueDate, invoiceNum);
            Assert.That(result.InvoiceDate, Is.EqualTo(invoiceDate));
            Assert.That(result.DueDate, Is.EqualTo(dueDate));
            Assert.That(result.Id, Is.EqualTo(invoiceNum));
        }
    }
}