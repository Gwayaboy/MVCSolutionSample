using Intrigma.Firn.Admin.Controllers;
using Intrigma.Firn.Core;
using Intrigma.Firn.Core.Tests.Web.Controllers;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Admin.Tests.Controllers
{
    [TestFixture]
    public class CustomerControllerTests : ControllerTestFixture<CustomerController>
    {
        private ICustomerRepository _customerRepository;
        private ICurrentDateFetcher _date;

        protected override CustomerController CreateController()
        {
            _customerRepository = DynamicMock<ICustomerRepository>();
            _date = DynamicMock<ICurrentDateFetcher>();
            return new CustomerController(_customerRepository, _date, null);
        }

        [Test]
        public void GetCustomerFromRequest()
        {
            var customer = new Customer();
            int id = 2435;
            Request.Params["id"] = id.ToString();
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Assert.That(Controller.GetCustomer(), Is.SameAs(customer));
        }

        [Test]
        public void RedirectToCorrectUrl()
        {
            var customer = new Customer();
            customer.Id = 2435;
            ReplayAll();

            Controller.RedirectToView(customer);
            Assert.That(Response.RedirectedTo, Is.EqualTo("/Controller/View.castle?id=" + customer.Id));
        }
    }
}