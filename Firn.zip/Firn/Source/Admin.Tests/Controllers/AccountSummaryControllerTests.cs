using System;
using Intrigma.Firn.Admin.Controllers;
using Intrigma.Firn.Core;
using Intrigma.Firn.Core.Tests.Web.Controllers;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Admin.Tests.Controllers
{
    [TestFixture]
    public class AccountSummaryControllerTests : ControllerTestFixture<AccountSummaryController>
    {
        private IRepository<Customer> _customerRepository;

        protected override AccountSummaryController CreateController()
        {
            _customerRepository = DynamicMock<IRepository<Customer>>();
            return new AccountSummaryController(_customerRepository);
        }

        [Test]
        public void ShowAccountSummarySetsBillingNotesInBag()
        {
            const int id = 235;
            var customer = new Customer {BillingNotes = Create.UniqueString()};
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.Show(id);
            Assert.That(Controller.PropertyBag[CustomerConstants.BillingNotes], Is.EqualTo(customer.BillingNotes));
        }

        [Test]
        public void ShowAccountSummarySetsBillingPeriodInBag()
        {
            const int id = 235;
            var customer = new Customer {BillingPeriod = BillingPeriod.Monthly};
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.Show(id);
            Assert.That(Controller.PropertyBag[CustomerConstants.BillingPeriod], Is.EqualTo(customer.BillingPeriod));
        }

        [Test]
        public void ShowAccountSummarySetsBillingStartDateInBag()
        {
            const int id = 235;
            var customer = new Customer {BillingStartDate = Create.AnyDate()};
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.Show(id);
            Assert.That(Controller.PropertyBag[CustomerConstants.BillingStartDate],
                        Is.EqualTo(customer.BillingStartDate));
        }

        [Test]
        public void ShowAccountSummarySetsCustomerInBag()
        {
            const int id = 235;
            var customer = new Customer();
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.Show(id);
            Assert.That(Controller.PropertyBag[CustomerConstants.Customer], Is.SameAs(customer));
        }

        [Test]
        public void ShowAccountSummarySetsNextInvoiceDateInBag()
        {
            const int id = 235;
            var customer = new Customer {NextInvoiceDate = Create.AnyDate()};
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.Show(id);
            Assert.That(Controller.PropertyBag[CustomerConstants.NextInvoiceDate], Is.EqualTo(customer.NextInvoiceDate));
        }

        [Test]
        public void ShowAccountSummarySetsNextStepsDateInBag()
        {
            const int id = 235;
            var customer = new Customer {NextStepsDate = Create.AnyDate()};
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.Show(id);
            Assert.That(Controller.PropertyBag[CustomerConstants.NextStepsDate], Is.EqualTo(customer.NextStepsDate));
        }

        [Test]
        public void ShowAccountSummarySetsNextStepsInBag()
        {
            const int id = 235;
            var customer = new Customer {NextSteps = Create.UniqueString()};
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.Show(id);
            Assert.That(Controller.PropertyBag[CustomerConstants.NextSteps], Is.EqualTo(customer.NextSteps));
        }

        [Test]
        public void UpdateAccountSummaryRedirectsWhenDone()
        {
            var customer = new Customer();
            const int id = 235;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.Update(id, null, default(BillingPeriod), null, null, null, null);
            Assert.That(Response.RedirectedTo, Is.EqualTo("/Customer/View.castle?id=" + id));
        }

        [Test]
        public void UpdateAccountSummarySavesCustomer()
        {
            var customer = new Customer();
            const int id = 235;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            _customerRepository.Save(customer);
            ReplayAll();

            Controller.Update(id, null, default(BillingPeriod), null, null, null, null);
        }

        [Test]
        public void UpdateAccountSummarySetsBillingNotes()
        {
            var customer = new Customer();
            const int id = 235;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            var value = Create.UniqueString();
            ReplayAll();

            Controller.Update(id, null, default(BillingPeriod), value, null, null, null);
            Assert.That(customer.BillingNotes, Is.EqualTo(value));
        }

        [Test]
        public void UpdateAccountSummarySetsBillingNotesToEmptyWhenNull()
        {
            var customer = new Customer();
            const int id = 235;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.Update(id, null, default(BillingPeriod), null, null, null, null);
            Assert.That(customer.BillingNotes, Is.Empty);
        }

        [Test]
        public void UpdateAccountSummarySetsBillingPeriod()
        {
            var customer = new Customer();
            const int id = 235;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            const BillingPeriod value = BillingPeriod.Semiannually;
            ReplayAll();

            Controller.Update(id, null, value, null, null, null, null);
            Assert.That(customer.BillingPeriod, Is.EqualTo(value));
        }

        [Test]
        public void UpdateAccountSummarySetsBillingStartDate()
        {
            var customer = new Customer();
            const int id = 235;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            DateTime? value = Create.AnyDate();
            ReplayAll();

            Controller.Update(id, value, default(BillingPeriod), null, null, null, null);
            Assert.That(customer.BillingStartDate, Is.EqualTo(value));
        }

        [Test]
        public void UpdateAccountSummarySetsNextInvoiceDate()
        {
            var customer = new Customer();
            const int id = 235;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            var value = Create.AnyDate();
            ReplayAll();

            Controller.Update(id, null, default(BillingPeriod), null, value, null, null);
            Assert.That(customer.NextInvoiceDate, Is.EqualTo(value));
        }

        [Test]
        public void UpdateAccountSummarySetsNextSteps()
        {
            var customer = new Customer();
            const int id = 235;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            var value = Create.UniqueString();
            ReplayAll();

            Controller.Update(id, null, default(BillingPeriod), null, null, value, null);
            Assert.That(customer.NextSteps, Is.EqualTo(value));
        }

        [Test]
        public void UpdateAccountSummarySetsNextStepsDate()
        {
            var customer = new Customer();
            const int id = 235;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            var value = Create.AnyDate();
            ReplayAll();

            Controller.Update(id, null, default(BillingPeriod), null, null, null, value);
            Assert.That(customer.NextStepsDate, Is.EqualTo(value));
        }

        [Test]
        public void UpdateAccountSummarySetsNextStepsToEmptyWhenNull()
        {
            var customer = new Customer();
            const int id = 235;
            SetupResult.For(_customerRepository.GetById(id)).Return(customer);
            ReplayAll();

            Controller.Update(id, null, default(BillingPeriod), null, null, null, null);
            Assert.That(customer.NextSteps, Is.Empty);
        }
    }
}