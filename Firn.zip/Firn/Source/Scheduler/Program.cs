using Intrigma.Firn.Core.ServiceHost;

namespace Intrigma.Firn.Scheduler
{
    public static class Program
    {
        public static void Main(string[] args)
        {
            ServiceRunner.Run(new SchedulerService(), args);
        }
    }
}