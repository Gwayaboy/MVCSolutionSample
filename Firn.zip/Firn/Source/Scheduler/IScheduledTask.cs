namespace Intrigma.Firn.Scheduler
{
    public interface IScheduledTask
    {
        void Run();
    }
}