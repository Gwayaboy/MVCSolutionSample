﻿using System.Reflection;

[assembly: AssemblyTitle("Intrigma Firn Scheduler")]