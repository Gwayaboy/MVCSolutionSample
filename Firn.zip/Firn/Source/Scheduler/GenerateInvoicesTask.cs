using System;
using Castle.Core.Logging;
using Castle.Facilities.NHibernateIntegration;
using Intrigma.Firn.Core;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Scheduler
{
    public class GenerateInvoicesTask : IScheduledTask
    {
        private readonly ICustomerRepository _customerRepository;
        private readonly ICurrentDateFetcher _date;
        private readonly ICustomerInvoiceGenerator _invoiceGenerator;
        private readonly ILogger _logger;
        private readonly ISessionManager _sessionManager;

        public GenerateInvoicesTask(ISessionManager sessionManager, ICurrentDateFetcher date,
                                    ICustomerRepository customerRepository, ICustomerInvoiceGenerator invoiceGenerator,
                                    ILogger logger)
        {
            _sessionManager = sessionManager;
            _date = date;
            _customerRepository = customerRepository;
            _invoiceGenerator = invoiceGenerator;
            _logger = logger;
        }

        #region IScheduledTask Members

        public void Run()
        {
            DateTime now = _date.Now;
            using (_sessionManager.OpenSession())
            {
                foreach (Customer customer in _customerRepository.ListByName())
                {
                    if (customer.ShouldInvoiceOn(now))
                    {
                        _logger.InfoFormat("Generating invoice for: {0}", customer);
                        _invoiceGenerator.GenerateInvoice(customer, now);
                    }
                }
            }
        }

        #endregion
    }
}