using Castle.Core.Logging;
using Castle.Facilities.NHibernateIntegration;
using Castle.Services.Transaction;
using Intrigma.Firn.Core;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.PaymentGateway;

namespace Intrigma.Firn.Scheduler
{
    [Transactional]
    public class PayPendingInvoicesTask : IScheduledTask
    {
        public const string PaymentErrorFormat = "Failed to pay {0}: {1}";
        private readonly ICurrentDateFetcher _dateFetcher;
        private readonly IInvoiceRepository _invoiceRepository;
        private readonly ILogger _logger;
        private readonly IPaymentGateway _paymentGateway;
        private readonly ISessionManager _sessionManager;

        public PayPendingInvoicesTask(ISessionManager sessionManager, IPaymentGateway paymentGateway,
                                      ICurrentDateFetcher dateFetcher, IInvoiceRepository invoiceRepository,
                                      ILogger logger)
        {
            _sessionManager = sessionManager;
            _paymentGateway = paymentGateway;
            _dateFetcher = dateFetcher;
            _invoiceRepository = invoiceRepository;
            _logger = logger;
        }

        #region IScheduledTask Members

        [Transaction]
        public virtual void Run()
        {
            using (_sessionManager.OpenSession())
            {
                foreach (Invoice invoice in _invoiceRepository.ListPayableInvoices(_dateFetcher.Now))
                {
                    _logger.InfoFormat("Paying {0}", invoice);
                    IPaymentResult result = invoice.Pay(_dateFetcher.Now, _paymentGateway);
                    if (!result.Success)
                    {
                        _logger.ErrorFormat(PaymentErrorFormat, invoice, result.RawMessage);
                    }
                }
            }
        }

        #endregion
    }
}