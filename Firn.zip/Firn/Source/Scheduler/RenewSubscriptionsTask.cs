using System;
using Castle.Facilities.NHibernateIntegration;
using Castle.Services.Transaction;
using Intrigma.Firn.Core;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Scheduler
{
    [Transactional]
    public class RenewSubscriptionsTask : IScheduledTask
    {
        private readonly ICurrentDateFetcher _now;
        private readonly ICustomerRepository _repository;
        private readonly ISessionManager _sessionManager;

        public RenewSubscriptionsTask(ISessionManager sessionManager, ICustomerRepository repository,
                                      ICurrentDateFetcher now)
        {
            _sessionManager = sessionManager;
            _repository = repository;
            _now = now;
        }

        #region IScheduledTask Members

        [Transaction]
        public virtual void Run()
        {
            DateTime now = _now.Now;
            using (_sessionManager.OpenSession())
            {
                foreach (Customer customer in _repository.ListByName())
                {
                    customer.CheckSubscriptionRenewals(now);
                }
            }
        }

        #endregion
    }
}