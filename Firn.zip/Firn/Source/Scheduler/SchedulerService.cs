using System;
using System.Threading;
using Intrigma.Firn.Core.ServiceHost;

namespace Intrigma.Firn.Scheduler
{
    public class SchedulerService : AbstractThreadedService
    {
        private static readonly TimeSpan _waitInterval = TimeSpan.FromHours(1);

        protected override void RunWorker(WaitHandle stopEvent)
        {
            IScheduledTask[] tasks = WindsorContainer.ResolveAll<IScheduledTask>();
            if (tasks.Length == 0)
            {
                Logger.Error("No scheduled tasks to run; exiting");
                return;
            }
            do
            {
                Logger.Debug("Run all scheduled tasks: starting");
                foreach (IScheduledTask task in tasks)
                {
                    Logger.DebugFormat("Running task {0}", task);
                    try
                    {
                        task.Run();
                    }
                    catch (Exception ex)
                    {
                        Logger.ErrorFormat("Unhandled exception while running scheduled task: {0}", ex);
                    }
                }
                Logger.Debug("Run all scheduled tasks: finished");
            } while (!stopEvent.WaitOne(_waitInterval, true));
        }
    }
}