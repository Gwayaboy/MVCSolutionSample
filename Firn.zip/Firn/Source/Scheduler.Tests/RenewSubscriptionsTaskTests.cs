using System;
using Castle.Facilities.NHibernateIntegration;
using Intrigma.Firn.Core;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NHibernate;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Scheduler.Tests
{
    [TestFixture]
    public class RenewSubscriptionsTaskTests : MockTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _sessionManager = DynamicMock<ISessionManager>();
            _repository = DynamicMock<ICustomerRepository>();
            _now = DynamicMock<ICurrentDateFetcher>();
            _target = new RenewSubscriptionsTask(_sessionManager, _repository, _now);
        }

        private RenewSubscriptionsTask _target;
        private ISessionManager _sessionManager;
        private ICustomerRepository _repository;
        private ICurrentDateFetcher _now;

        [Test]
        public void DisposeSession()
        {
            var session = DynamicMock<ISession>();
            SetupResult.For(_sessionManager.OpenSession()).Return(session);
            SetupResult.For(_repository.ListByName()).Return(new Customer[0]);
            session.Dispose();
            ReplayAll();

            _target.Run();
        }

        [Test]
        public void RenewSubscriptionsForTwoCustomers()
        {
            DateTime now = Create.AnyDate();
            SetupResult.For(_now.Now).Return(now);
            Customer[] customers = CreateMocksArray<Customer>(2);
            SetupResult.For(_repository.ListByName()).Return(customers);
            customers[0].CheckSubscriptionRenewals(now);
            customers[1].CheckSubscriptionRenewals(now);
            ReplayAll();

            _target.Run();
        }
    }
}