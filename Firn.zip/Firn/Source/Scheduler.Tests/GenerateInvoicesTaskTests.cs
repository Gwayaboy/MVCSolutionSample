using System;
using Castle.Core.Logging;
using Castle.Facilities.NHibernateIntegration;
using Intrigma.Firn.Core;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.Tests;
using NHibernate;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Scheduler.Tests
{
    [TestFixture]
    public class GenerateInvoicesTaskTests : MockTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _sessionManager = DynamicMock<ISessionManager>();
            _date = DynamicMock<ICurrentDateFetcher>();
            _repository = DynamicMock<ICustomerRepository>();
            _invoiceGenerator = DynamicMock<ICustomerInvoiceGenerator>();
            _target = new GenerateInvoicesTask(_sessionManager, _date, _repository, _invoiceGenerator,
                                               NullLogger.Instance);
        }

        private GenerateInvoicesTask _target;
        private ISessionManager _sessionManager;
        private ICustomerInvoiceGenerator _invoiceGenerator;
        private ICustomerRepository _repository;
        private ICurrentDateFetcher _date;

        private delegate DateTime NowDelegate();

        [Test]
        public void DoNotGenerateInvoiceIfNotTimeYet()
        {
            DateTime date = Create.AnyDate();
            SetupResult.For(_date.Now).Return(date);
            Customer[] customers = CreateMocksArray<Customer>(2);
            SetupResult.For(_repository.ListByName()).Return(customers);
            DoNotExpect.Call(delegate { _invoiceGenerator.GenerateInvoice(customers[1], date); });
            ReplayAll();

            _target.Run();
        }

        [Test]
        public void GenerateForOneCustomer()
        {
            DateTime date = Create.AnyDate();
            SetupResult.For(_date.Now).Return(date);
            Customer[] customers = CreateMocksArray<Customer>(2);
            SetupResult.For(_repository.ListByName()).Return(customers);
            SetupResult.For(customers[1].ShouldInvoiceOn(date)).Return(true);
            SetupResult.For(_invoiceGenerator.GenerateInvoice(customers[1], date)).Return(null);
            ReplayAll();

            _target.Run();
        }

        [Test]
        public void OnlyFetchTimeOnceSinceItChanges()
        {
            DateTime date = Create.AnyDate();
            int callCount = 0;
            SetupResult.For(_date.Now).Do((NowDelegate) delegate
                                                            {
                                                                Assert.That(++callCount, Is.LessThanOrEqualTo(1));
                                                                return date;
                                                            });
            Customer[] customers = CreateMocksArray<Customer>(2);
            SetupResult.For(_repository.ListByName()).Return(customers);
            ReplayAll();

            _target.Run();
        }

        [Test]
        public void OpenAndDisposeSession()
        {
            var session = DynamicMock<ISession>();
            SetupResult.For(_sessionManager.OpenSession()).Return(session);
            SetupResult.For(_repository.ListByName()).Return(new Customer[0]);
            session.Dispose();
            ReplayAll();

            _target.Run();
        }
    }
}