using System;
using Castle.Core.Logging;
using Castle.Facilities.NHibernateIntegration;
using Intrigma.Firn.Core;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.PaymentGateway;
using Intrigma.Firn.DomainModel.Tests;
using NHibernate;
using NUnit.Framework;
using Rhino.Mocks;

namespace Intrigma.Firn.Scheduler.Tests
{
    [TestFixture]
    public class PayPendingInvoicesTaskTests : MockTestFixture
    {
        public override void SetUp()
        {
            base.SetUp();
            _sessionManager = DynamicMock<ISessionManager>();
            _paymentGateway = DynamicMock<IPaymentGateway>();
            _clock = DynamicMock<ICurrentDateFetcher>();
            _repository = DynamicMock<IInvoiceRepository>();
            _logger = DynamicMock<ILogger>();
            _target = new PayPendingInvoicesTask(_sessionManager, _paymentGateway, _clock, _repository, _logger);
        }

        private PayPendingInvoicesTask _target;
        private ISessionManager _sessionManager;
        private IPaymentGateway _paymentGateway;
        private ICurrentDateFetcher _clock;
        private IInvoiceRepository _repository;
        private ILogger _logger;

        [Test]
        public void DoNotLogErrorOnSuccess()
        {
            DateTime now = Create.AnyDate();
            SetupResult.For(_clock.Now).Return(now);
            Invoice[] invoices = CreateMocksArray<Invoice>(1);
            SetupResult.For(_repository.ListPayableInvoices(now)).Return(invoices);
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(true);
            SetupResult.For(invoices[0].Pay(now, _paymentGateway)).Return(result);
            DoNotExpect.Call(
                delegate { _logger.ErrorFormat(PayPendingInvoicesTask.PaymentErrorFormat, invoices[0], null); });
            ReplayAll();

            _target.Run();
        }

        [Test]
        public void LogErrorWhenPaymentFails()
        {
            DateTime now = Create.AnyDate();
            SetupResult.For(_clock.Now).Return(now);
            Invoice[] invoices = CreateMocksArray<Invoice>(1);
            SetupResult.For(_repository.ListPayableInvoices(now)).Return(invoices);
            var result = DynamicMock<IPaymentResult>();
            string raw = Create.AnyString();
            SetupResult.For(result.RawMessage).Return(raw);
            SetupResult.For(invoices[0].Pay(now, _paymentGateway)).Return(result);
            _logger.ErrorFormat(PayPendingInvoicesTask.PaymentErrorFormat, invoices[0], raw);
            ReplayAll();

            _target.Run();
        }

        [Test]
        public void PayTwoInvoices()
        {
            DateTime now = Create.AnyDate();
            SetupResult.For(_clock.Now).Return(now);
            Invoice[] invoices = CreateMocksArray<Invoice>(2);
            SetupResult.For(_repository.ListPayableInvoices(now)).Return(invoices);
            var result = DynamicMock<IPaymentResult>();
            SetupResult.For(result.Success).Return(true);
            Expect.Call(invoices[0].Pay(now, _paymentGateway)).Return(result);
            Expect.Call(invoices[1].Pay(now, _paymentGateway)).Return(result);
            ReplayAll();

            _target.Run();
        }

        [Test]
        public void UseASession()
        {
            var session = DynamicMock<ISession>();
            SetupResult.For(_sessionManager.OpenSession()).Return(session);
            DateTime now = Create.AnyDate();
            SetupResult.For(_clock.Now).Return(now);
            SetupResult.For(_repository.ListPayableInvoices(now)).Return(new Invoice[0]);
            session.Dispose();
            ReplayAll();

            _target.Run();
        }
    }
}