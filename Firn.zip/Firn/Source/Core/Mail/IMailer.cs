using System.Net.Mail;

namespace Intrigma.Firn.Core.Mail
{
    public interface IMailer
    {
        void Mail(MailMessage message);
    }
}