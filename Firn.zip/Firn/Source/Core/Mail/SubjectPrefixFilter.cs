using System.Net.Mail;
using Intrigma.Firn.Core.Environment;

namespace Intrigma.Firn.Core.Mail
{
    public class SubjectPrefixFilter : IMailFilter
    {
        private readonly IEnvironment _environment;

        public SubjectPrefixFilter(IEnvironment environment)
        {
            _environment = environment;
        }

        #region IMailFilter Members

        public bool Process(MailMessage msg)
        {
            msg.Subject = _environment.EmailSubjectPrefix + msg.Subject;
            return true;
        }

        #endregion
    }
}