using System.Net.Mail;

namespace Intrigma.Firn.Core.Mail
{
    public interface IMailFilter
    {
        bool Process(MailMessage msg);
    }
}