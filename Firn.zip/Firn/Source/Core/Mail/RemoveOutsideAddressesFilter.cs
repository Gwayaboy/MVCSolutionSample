using System.Collections.Generic;
using System.Net.Mail;

namespace Intrigma.Firn.Core.Mail
{
    public class RemoveOutsideAddressesFilter : IMailFilter
    {
        public const string AcceptableAddressSuffix = "@intrigma.com";

        #region IMailFilter Members

        public bool Process(MailMessage msg)
        {
            ProcessMailAddressCollection(msg.To);
            ProcessMailAddressCollection(msg.CC);
            ProcessMailAddressCollection(msg.Bcc);
            return (msg.To.Count > 0);
        }

        #endregion

        private static void ProcessMailAddressCollection(IList<MailAddress> addresses)
        {
            for (int index = 0; index < addresses.Count;)
            {
                if (addresses[index].Address.EndsWith(AcceptableAddressSuffix))
                {
                    index++;
                }
                else
                {
                    addresses.RemoveAt(index);
                }
            }
        }
    }
}