using System.Collections.Generic;
using System.Net.Mail;
using Castle.Core.Logging;

namespace Intrigma.Firn.Core.Mail
{
    public class MailProcessor : IMailProcessor
    {
        private readonly ILogger _logger;
        private readonly IMailer _mailService;
        private IList<IMailFilter> _filters;

        public MailProcessor(IMailer mailService, ILogger logger)
        {
            _mailService = mailService;
            _logger = logger;
        }

        public IList<IMailFilter> Filters
        {
            set { _filters = value; }
        }

        #region IMailProcessor Members

        public void Send(MailMessage msg)
        {
            foreach (IMailFilter filter in _filters)
            {
                if (!filter.Process(msg))
                {
                    return;
                }
            }
            _logger.Debug("Sending message: subject: {0}\nbody:{1}", msg.Subject, msg.Body);
            _mailService.Mail(msg);
        }

        #endregion
    }
}