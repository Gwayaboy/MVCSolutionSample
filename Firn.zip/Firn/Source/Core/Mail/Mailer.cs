using System.Net.Mail;

namespace Intrigma.Firn.Core.Mail
{
    public class Mailer : IMailer
    {
        #region IMailer Members

        public void Mail(MailMessage message)
        {
            new SmtpClient().Send(message);
        }

        #endregion
    }
}