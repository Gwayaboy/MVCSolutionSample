using System.Net.Mail;

namespace Intrigma.Firn.Core.Mail
{
    public interface IMailProcessor
    {
        void Send(MailMessage msg);
    }
}