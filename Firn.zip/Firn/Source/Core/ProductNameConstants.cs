using System.Linq;
using System.Net.Mail;
using System.Reflection;

namespace Intrigma.Firn.Core
{
    public static class ProductNameConstants
    {
        public const string ITEmailAddress = "it@intrigma.com";
        public static readonly MailAddress FromAddress = new MailAddress("billing@intrigma.com", "Intrigma");
        public static readonly string Copyright;

        static ProductNameConstants()
        {
            var attribute =
                (AssemblyCopyrightAttribute)
                Assembly.GetExecutingAssembly().GetCustomAttributes(typeof(AssemblyCopyrightAttribute), true).
                    FirstOrDefault();
            if (attribute != null)
            {
                Copyright = attribute.Copyright;
            }
        }
    }
}