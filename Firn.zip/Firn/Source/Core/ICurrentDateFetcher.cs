using System;

namespace Intrigma.Firn.Core
{
    public interface ICurrentDateFetcher
    {
        DateTime Now { get; }
    }
}