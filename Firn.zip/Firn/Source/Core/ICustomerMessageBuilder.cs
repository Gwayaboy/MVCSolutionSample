using System.Net.Mail;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core
{
    public interface ICustomerMessageBuilder
    {
        MailMessage Build(Customer customer);
    }
}