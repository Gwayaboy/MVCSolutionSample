using System;

namespace Intrigma.Firn.Core
{
    public class CurrentDateFetcher : ICurrentDateFetcher
    {
        #region ICurrentDateFetcher Members

        public DateTime Now
        {
            get { return DateTime.Now; }
        }

        #endregion
    }
}