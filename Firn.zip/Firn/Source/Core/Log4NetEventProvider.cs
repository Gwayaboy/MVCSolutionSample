using System.Web.Management;
using log4net;

namespace Intrigma.Firn.Core
{
    public class Log4NetEventProvider : WebEventProvider
    {
        private static readonly ILog _logger = LogManager.GetLogger(typeof(Log4NetEventProvider));

        public override void ProcessEvent(WebBaseEvent raisedEvent)
        {
            _logger.ErrorFormat("ASP.NET error: {0}", raisedEvent);
        }

        public override void Shutdown() {}

        public override void Flush() {}
    }
}