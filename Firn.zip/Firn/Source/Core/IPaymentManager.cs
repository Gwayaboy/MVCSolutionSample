using Castle.Services.Transaction;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.PaymentGateway;

namespace Intrigma.Firn.Core
{
    public interface IPaymentManager
    {
        IPaymentResult MakePayment(Invoice invoice, decimal amount);

        [Transaction]
        IPaymentResult IssueRefund(Customer customer, decimal amount, string reason);
    }
}