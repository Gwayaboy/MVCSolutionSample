namespace Intrigma.Firn.Core
{
    public interface INextInvoiceNumber
    {
        int Next { get; }
    }
}