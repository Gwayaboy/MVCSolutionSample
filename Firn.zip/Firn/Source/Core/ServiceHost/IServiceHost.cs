namespace Intrigma.Firn.Core.ServiceHost
{
    public interface IServiceHost
    {
        void Run();
    }
}