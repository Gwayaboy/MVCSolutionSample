using System.ServiceProcess;

namespace Intrigma.Firn.Core.ServiceHost
{
    public class WindowsServiceHost : ServiceBase, IServiceHost
    {
        private readonly IHostedService _service;

        public WindowsServiceHost(IHostedService service)
        {
            _service = service;
        }

        #region IServiceHost Members

        public void Run()
        {
            Run(this);
        }

        #endregion

        protected override void OnStart(string[] args)
        {
            base.OnStart(args);
            _service.Start(args);
        }

        protected override void OnStop()
        {
            base.OnStop();
            _service.Stop();
        }
    }
}