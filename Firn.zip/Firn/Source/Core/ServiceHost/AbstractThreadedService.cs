using System.Threading;

namespace Intrigma.Firn.Core.ServiceHost
{
    public abstract class AbstractThreadedService : WindsorService
    {
        private readonly ManualResetEvent _stopEvent = new ManualResetEvent(false);
        private Thread _workerThread;

        private void StartEngine()
        {
            _stopEvent.Reset();
            _workerThread = new Thread(OnWorkerStart);
            _workerThread.Start();
        }

        private void OnWorkerStart()
        {
            RunWorker(_stopEvent);
        }

        protected virtual void RunWorker(WaitHandle stopEvent) {}

        protected virtual void StopWorker()
        {
            _stopEvent.Set();
            _workerThread.Join();
            _workerThread = null;
        }

        public override void Start(string[] args)
        {
            base.Start(args);
            StartEngine();
        }

        public override void Stop()
        {
            StopWorker();
        }
    }
}