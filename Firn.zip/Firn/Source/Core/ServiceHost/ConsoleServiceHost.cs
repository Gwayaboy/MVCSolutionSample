using System;

namespace Intrigma.Firn.Core.ServiceHost
{
    public class ConsoleServiceHost : IServiceHost
    {
        private readonly string[] _args;
        private readonly IHostedService _service;

        public ConsoleServiceHost(IHostedService service, string[] args)
        {
            _service = service;
            _args = args;
        }

        #region IServiceHost Members

        public void Run()
        {
            Console.WriteLine("Starting service...");
            _service.Start(_args);
            Console.WriteLine("Started service.");
            ConsoleKeyInfo key;
            do
            {
                key = Console.ReadKey(true);
            } while (!((key.Key == ConsoleKey.D) && (key.Modifiers & ConsoleModifiers.Control) > 0));
            Console.WriteLine("Stopping service...");
            _service.Stop();
            Console.WriteLine("Stopped service.");
        }

        #endregion
    }
}