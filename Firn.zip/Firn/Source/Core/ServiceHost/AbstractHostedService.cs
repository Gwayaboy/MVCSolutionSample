namespace Intrigma.Firn.Core.ServiceHost
{
    public class AbstractHostedService : IHostedService
    {
        #region IHostedService Members

        public virtual void Start(string[] args) {}

        public virtual void Stop() {}

        public virtual void Attach(IServiceHost host) {}

        #endregion
    }
}