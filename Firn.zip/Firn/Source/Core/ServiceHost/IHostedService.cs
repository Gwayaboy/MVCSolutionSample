namespace Intrigma.Firn.Core.ServiceHost
{
    public interface IHostedService
    {
        void Start(string[] args);
        void Stop();
        void Attach(IServiceHost host);
    }
}