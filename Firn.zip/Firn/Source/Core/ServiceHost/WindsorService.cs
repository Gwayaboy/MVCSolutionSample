using System;
using Castle.Core.Logging;
using Castle.Windsor;

namespace Intrigma.Firn.Core.ServiceHost
{
    public class WindsorService : AbstractHostedService
    {
        protected readonly ILogger Logger;
        protected readonly IWindsorContainer WindsorContainer;

        public WindsorService()
        {
            WindsorContainer = CoreConfiguration.BuildContainer();
            Logger = WindsorContainer.GetService<ILogger>();
            AppDomain.CurrentDomain.UnhandledException += CurrentDomain_UnhandledException;
            CoreConfiguration.RegisterTypesInAssembly(GetType().Assembly, WindsorContainer.Kernel);
        }

        private void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Logger.Fatal("Unhandled exception: {0}", e.ExceptionObject);
        }
    }
}