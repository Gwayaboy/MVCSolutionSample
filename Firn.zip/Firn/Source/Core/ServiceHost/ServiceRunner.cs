namespace Intrigma.Firn.Core.ServiceHost
{
    public static class ServiceRunner
    {
        public static void Run(IHostedService service, string[] args)
        {
            var host = CreateHost(service, args);
            service.Attach(host);
            host.Run();
        }

        private static IServiceHost CreateHost(IHostedService service, string[] args)
        {
            return System.Environment.UserInteractive
                       ? (IServiceHost) new ConsoleServiceHost(service, args)
                       : new WindowsServiceHost(service);
        }
    }
}