using System;
using System.Collections;
using System.Configuration;
using System.Reflection;
using Intrigma.Firn.Data;

namespace Intrigma.Firn.Core.Environment
{
    public static class EnvironmentContext
    {
        public const string DefaultConfiguration = "Development";
        public const string EnvironmentNameSetting = "environment";
        public const string SectionName = "firn";
        public const string DefaultRole = "Standalone";
        public const string RoleNameSetting = "role";
        private const string _connectionStringKey = "connectionString";

        private static readonly IEnvironment _currentEnvironment;
        private static readonly IRole _currentRole;

        static EnvironmentContext()
        {
            var environmentName = (string) ConfigurationSection[EnvironmentNameSetting];
            environmentName = (string.IsNullOrEmpty(environmentName) ? DefaultConfiguration : environmentName);
            var envType =
                Assembly.GetExecutingAssembly().GetType(
                    string.Format("{0}.{1}Environment", typeof(IEnvironment).Namespace, environmentName), true);
            _currentEnvironment = (IEnvironment) Activator.CreateInstance(envType);

            var roleName = (string) ConfigurationSection[RoleNameSetting];
            roleName = string.IsNullOrEmpty(roleName) ? DefaultRole : roleName;
            var roleType =
                Assembly.GetExecutingAssembly().GetType(
                    string.Format("{0}.{1}Role", typeof(IRole).Namespace, roleName), true);
            _currentRole = (IRole) Activator.CreateInstance(roleType);

            DatabaseHelper.ConnectionString = (ConfigurationSection.Contains(_connectionStringKey))
                                                  ? (string) ConfigurationSection[_connectionStringKey]
                                                  : _currentEnvironment.ConnectionString;
        }

        public static IDictionary ConfigurationSection
        {
            get { return (IDictionary) ConfigurationManager.GetSection(SectionName) ?? new Hashtable(); }
        }

        public static IEnvironment CurrentEnvironment
        {
            get { return _currentEnvironment; }
        }

        public static IRole CurrentRole
        {
            get { return _currentRole; }
        }
    }
}