namespace Intrigma.Firn.Core.Environment
{
    public class StandaloneRole : IRole
    {
        public bool AdminEnabled
        {
            get { return true; }
        }

        public bool AppServerEnabled
        {
            get { return true; }
        }

        public bool SchedulerEnabled
        {
            get { return true; }
        }

        public bool SelfServiceEnabled
        {
            get { return true; }
        }

        public bool UpgradeDatabaseOnInstall
        {
            get { return true; }
        }
    }
}