namespace Intrigma.Firn.Core.Environment
{
    public class WebRole : IRole
    {
        public bool AdminEnabled
        {
            get { return true; }
        }

        public bool AppServerEnabled
        {
            get { return false; }
        }

        public bool SchedulerEnabled
        {
            get { return false; }
        }

        public bool SelfServiceEnabled
        {
            get { return true; }
        }

        public bool UpgradeDatabaseOnInstall
        {
            get { return false; }
        }
    }
}