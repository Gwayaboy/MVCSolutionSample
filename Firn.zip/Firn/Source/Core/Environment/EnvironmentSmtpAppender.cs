using log4net.Appender;

namespace Intrigma.Firn.Core.Environment
{
    public class EnvironmentSmtpAppender : SmtpAppender
    {
        private const string _subjectFormat = "{0}: {1}";

        public override void ActivateOptions()
        {
            base.ActivateOptions();
            Subject = string.Format(_subjectFormat, EnvironmentContext.CurrentEnvironment.Name, Subject);
        }
    }
}