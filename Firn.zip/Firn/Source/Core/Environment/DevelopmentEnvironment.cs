namespace Intrigma.Firn.Core.Environment
{
    public class DevelopmentEnvironment : IEnvironment
    {
        public const string DefaultConnectionString =
            "Data Source=(local);Initial Catalog=Firn;Integrated Security=True";

        #region IEnvironment Members

        public bool UpgradeDatabaseOnStart
        {
            get { return true; }
        }

        public bool RemoveExternalEmailAddresses
        {
            get { return true; }
        }

        public string Name
        {
            get { return "Development"; }
        }

        public string LoggingConfigFile
        {
            get { return "log4net-dev.config"; }
        }

        public string AuthenticationCookieDomain
        {
            get { return string.Empty; }
        }

        public string SchedulerEntryUrl
        {
            get { return "http://localhost:4706/"; }
        }

        public bool RunInDebugMode
        {
            get { return true; }
        }

        public bool UseStubPaymentGateway
        {
            get { return true; }
        }

        public string ConnectionString
        {
            get { return DefaultConnectionString; }
        }

        public string EmailSubjectPrefix
        {
            get { return "Development: "; }
        }

        #endregion
    }
}