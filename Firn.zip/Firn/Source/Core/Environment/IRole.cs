﻿namespace Intrigma.Firn.Core.Environment
{
    public interface IRole
    {
        bool AdminEnabled { get; }
        bool AppServerEnabled { get; }
        bool SchedulerEnabled { get; }
        bool SelfServiceEnabled { get; }
        bool UpgradeDatabaseOnInstall { get; }
    }
}