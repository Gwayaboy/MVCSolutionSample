namespace Intrigma.Firn.Core.Environment
{
    public interface IEnvironment
    {
        bool UpgradeDatabaseOnStart { get; }
        bool RemoveExternalEmailAddresses { get; }
        string Name { get; }
        string LoggingConfigFile { get; }
        string AuthenticationCookieDomain { get; }
        string SchedulerEntryUrl { get; }
        bool RunInDebugMode { get; }
        bool UseStubPaymentGateway { get; }
        string ConnectionString { get; }
        string EmailSubjectPrefix { get; }
    }
}