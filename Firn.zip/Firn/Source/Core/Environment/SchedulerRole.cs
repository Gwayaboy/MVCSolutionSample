namespace Intrigma.Firn.Core.Environment
{
    public class SchedulerRole : IRole
    {
        public bool AdminEnabled
        {
            get { return false; }
        }

        public bool AppServerEnabled
        {
            get { return true; }
        }

        public bool SchedulerEnabled
        {
            get { return true; }
        }

        public bool SelfServiceEnabled
        {
            get { return false; }
        }

        public bool UpgradeDatabaseOnInstall
        {
            get { return true; }
        }
    }
}