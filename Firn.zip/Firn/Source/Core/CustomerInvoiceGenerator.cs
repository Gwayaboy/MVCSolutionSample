using System;
using Intrigma.Firn.Core.InvoiceReport;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core
{
    public class CustomerInvoiceGenerator : ICustomerInvoiceGenerator
    {
        private readonly ICustomerInvoiceCreator _creator;
        private readonly IInvoiceMailer _invoiceMailer;

        public CustomerInvoiceGenerator(IInvoiceMailer invoiceMailer, ICustomerInvoiceCreator creator)
        {
            _invoiceMailer = invoiceMailer;
            _creator = creator;
        }

        #region ICustomerInvoiceGenerator Members

        public virtual Invoice GenerateInvoice(Customer customer, DateTime date)
        {
            var invoice = _creator.CreateFor(customer, date);
            if (invoice != null)
            {
                _invoiceMailer.Mail(invoice);
            }
            return invoice;
        }

        #endregion
    }
}