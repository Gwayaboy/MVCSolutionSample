namespace Intrigma.Firn.Core
{
    public static class SubscriptionConstants
    {
        public const string Amount = "amount";
        public const string BillableWeeksBefore = "billableWeeksBefore";
        public const string Description = "description";
        public const string Id = "id";
        public const string Months = "months";
        public const string Name = "name";
        public const string StaffCount = "staffCount";
        public const string StartDate = "startDate";
    }
}