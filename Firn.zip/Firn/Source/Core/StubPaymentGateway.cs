using System;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.PaymentGateway;

namespace Intrigma.Firn.Core
{
    public class StubPaymentGateway : IPaymentGateway
    {
        public const string PaymentFailureFormat = @"Stub payment failed (stub only accepts credit card transactions)
Customer: {0}
Amount: {1:c}";

        public const string PaymentSuccessFormat = @"Stub payment successful (note: no actual money exchanged!)
Customer: {0}
Amount: {1:c}";

        public const string RefundFailureFormat = @"Stub refund failed (stub only accepts credit card transactions)
Customer: {0}
Amount: {1:c}";

        public const string RefundSuccessFormat = @"Stub refund successful (note: no actual money exchanged!)
Customer: {0}
Amount: {1:c}";

        #region IPaymentGateway Members

        public IPaymentResult IssueRefund(Customer customer, decimal amount)
        {
            return customer.BillingType == BillingType.CreditCard
                       ? new PaymentResult(string.Format(RefundSuccessFormat, customer, amount), true)
                       : new PaymentResult(string.Format(RefundFailureFormat, customer, amount), false);
        }

        public IPaymentResult MakePayment(Customer customer, decimal amount)
        {
            return customer.BillingType == BillingType.CreditCard
                       ? new PaymentResult(string.Format(PaymentSuccessFormat, customer, amount), true)
                       : new PaymentResult(string.Format(PaymentFailureFormat, customer, amount), false);
        }

        public void DeletePaymentMethod(int paymentMethodId)
        {
            // No problem! Happy to help.
        }

        public int CreatePaymentMethod(BillingType billingType, PaymentType paymentType)
        {
            return (int) billingType;
        }

        public PaymentType GetPaymentMethod(BillingType billingType, int id)
        {
            switch (billingType)
            {
                case BillingType.MailPayment:
                    return new PaymentType();
                case BillingType.CreditCard:
                    return new PaymentType
                        {
                            AccountHolderName = "John Smith",
                            CreditCardExpirationMonth = 12,
                            CreditCardExpirationYear = 2020,
                            CreditCardNumber = "XXXX-XXXX-XXXX-1234",
                            CreditCardProcurement = false,
                            CreditCardType = CreditCardType.Visa
                        };
                case BillingType.Eft:
                    return new PaymentType
                        {
                            AccountHolderName = "Cathy Johnson",
                            EftAccountNumber = "XXXXXX123",
                            EftRoutingNumber = "012345678",
                            EftAccountType = EftAccountType.Checking
                        };
                default:
                    throw new ArgumentOutOfRangeException();
            }
        }

        #endregion
    }
}