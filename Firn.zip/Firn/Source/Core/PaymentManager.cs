using Castle.Services.Transaction;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.PaymentGateway;

namespace Intrigma.Firn.Core
{
    [Transactional]
    public class PaymentManager : IPaymentManager
    {
        public const string PaymentDescription = "Payment";
        private readonly ICurrentDateFetcher _now;
        private readonly IPaymentGateway _paymentGateway;
        private readonly IRepository<Customer> _repository;

        public PaymentManager(ICurrentDateFetcher now, IRepository<Customer> repository, IPaymentGateway paymentGateway)
        {
            _now = now;
            _repository = repository;
            _paymentGateway = paymentGateway;
        }

        #region IPaymentManager Members

        [Transaction]
        public IPaymentResult MakePayment(Invoice invoice, decimal amount)
        {
            Customer customer = invoice.Customer;
            IPaymentResult result = invoice.Pay(_now.Now, amount, _paymentGateway);
            _repository.Save(customer);
            return result;
        }

        [Transaction]
        public IPaymentResult IssueRefund(Customer customer, decimal amount, string reason)
        {
            IPaymentResult result = customer.IssueRefund(_now.Now, amount, reason, _paymentGateway);
            _repository.Save(customer);
            return result;
        }

        #endregion
    }
}