using Castle.Core.Configuration;
using Castle.Facilities.NHibernateIntegration.Internal;
using Intrigma.Firn.Data;
using NHibernate.Cfg;

namespace Intrigma.Firn.Core
{
    public class NHibernateConfigurationBuilder : IConfigurationBuilder
    {
        #region IConfigurationBuilder Members

        public Configuration GetConfiguration(IConfiguration config)
        {
            return DatabaseHelper.BuildConfiguration(false);
        }

        #endregion
    }
}