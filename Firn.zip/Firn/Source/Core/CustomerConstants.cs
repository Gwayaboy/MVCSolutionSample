namespace Intrigma.Firn.Core
{
    public static class CustomerConstants
    {
        public const string AttnFirstName = "attnFirstName";
        public const string AttnLastName = "attnLastName";
        public const string BillingNotes = "billingNotes";
        public const string BillingPeriod = "billingPeriod";
        public const string BillingStartDate = "billingStartDate";
        public const string BillingType = "billingType";
        public const string City = "city";
        public const string CurrentDate = "currentDate";
        public const string Customer = "customer";
        public const string Email = "email";
        public const string Id = "id";
        public const string Name = "name";
        public const string NewFlag = "isNew";
        public const string NextInvoiceDate = "nextInvoiceDate";
        public const string NextSteps = "nextSteps";
        public const string NextStepsDate = "nextStepsDate";
        public const string PaymentMethod = "payment";
        public const string Phone = "phone";
        public const string SecondaryEmails = "secondaryEmails";
        public const string State = "state";
        public const string Street1 = "street1";
        public const string Street2 = "street2";
        public const string Subscriptions = "subscriptions";
        public const string Transaction = "tx";
        public const string Transactions = "transactions";
        public const string Zip = "zip";
    }
}