using System;
using Castle.MonoRail.Framework;
using Castle.Services.Transaction;
using Iesi.Collections.Generic;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.PaymentGateway;

namespace Intrigma.Firn.Core.Web.Controllers
{
    [Transactional]
    public abstract class CustomerController : BaseController
    {
        protected readonly ICustomerRepository _customerRepository;
        private readonly ICurrentDateFetcher _date;
        private readonly IPaymentGateway _gateway;

        public CustomerController(ICustomerRepository customerRepository, ICurrentDateFetcher date,
                                  IPaymentGateway gateway)
        {
            _customerRepository = customerRepository;
            _date = date;
            _gateway = gateway;
        }

        public abstract Customer GetCustomer();

        public void ShowContactInformation()
        {
            Customer customer = GetCustomer();
            LoadContactInformation(customer);
            PropertyBag[CustomerConstants.AttnFirstName] = customer.AttnFirstName;
            PropertyBag[CustomerConstants.AttnLastName] = customer.AttnLastName;
            PropertyBag[CustomerConstants.Street1] = customer.StreetAddress1;
            PropertyBag[CustomerConstants.Street2] = customer.StreetAddress2;
            PropertyBag[CustomerConstants.City] = customer.City;
            PropertyBag[CustomerConstants.State] = customer.State;
            PropertyBag[CustomerConstants.Zip] = customer.Zip;
            PropertyBag[CustomerConstants.Email] = customer.EmailAddress;
            PropertyBag[CustomerConstants.SecondaryEmails] = string.Join("\n",
                                                                         Util.SetToArray(
                                                                             customer.SecondaryEmailAddresses));
            PropertyBag[CustomerConstants.Phone] = customer.Phone;
        }

        public virtual void LoadContactInformation(Customer customer)
        {
            PropertyBag[CustomerConstants.Customer] = customer;
        }

        public virtual void View()
        {
            Customer customer = GetCustomer();
            PropertyBag[CustomerConstants.Customer] = customer;
            PropertyBag["invoices"] = customer.Invoices;
            PropertyBag[CustomerConstants.Transactions] = customer.Transactions;
            PropertyBag[CustomerConstants.Subscriptions] = customer.Subscriptions;
            PropertyBag[CustomerConstants.PaymentMethod] = customer.GetPaymentMethod(_gateway);
            PropertyBag[CustomerConstants.CurrentDate] = _date.Now;
        }

        [Transaction]
        public virtual void UpdateContactInformation(string attnFirstName, string attnLastName, string street1,
                                                     string street2, string city, string state, string zip, string phone,
                                                     string email, string secondaryEmails)
        {
            Customer customer = GetCustomer();
            LoadContactInformation(customer);
            secondaryEmails = secondaryEmails ?? string.Empty;
            ISet<string> errors = customer.SetSecondaryEmailAddresses(Util.ArrayToSet(secondaryEmails.Split('\n')));
            PropertyBag["errors"] = errors;
            if (errors.Count > 0)
            {
                RenderView("ShowContactInformation");
                return;
            }
            customer.AttnFirstName = attnFirstName;
            customer.AttnLastName = attnLastName;
            customer.StreetAddress1 = street1;
            customer.StreetAddress2 = street2 ?? string.Empty;
            customer.City = city;
            customer.State = state;
            customer.Zip = zip;
            customer.EmailAddress = email;
            customer.Phone = phone;
            _customerRepository.Save(customer);

            RedirectToView(customer);
        }

        public void ShowPaymentMethod()
        {
            Customer customer = GetCustomer();
            PropertyBag[CustomerConstants.Customer] = customer;
            PropertyBag[CustomerConstants.BillingType] = customer.BillingType;
        }

        [Transaction]
        public virtual void ChangePaymentMethod(BillingType billingType, [DataBind("payment")] PaymentType payment)
        {
            Customer customer = GetCustomer();
            try
            {
                customer.UpdatePaymentMethod(billingType, payment, _gateway);
                RedirectToView(customer);
            }
            catch (Exception ex)
            {
                PropertyBag["error"] = ex.Message;
                PropertyBag[CustomerConstants.Customer] = customer;
                PropertyBag[CustomerConstants.PaymentMethod] = payment;
                RenderView("ShowPaymentMethod");
            }
        }

        public abstract void RedirectToView(Customer customer);
    }
}