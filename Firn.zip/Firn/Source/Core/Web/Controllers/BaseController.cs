using Castle.MonoRail.Framework;

namespace Intrigma.Firn.Core.Web.Controllers
{
    [Layout("default")]
    [Helper(typeof(EnumFormatHelper), "EnumFormat")]
    public abstract class BaseController : SmartDispatcherController {}
}