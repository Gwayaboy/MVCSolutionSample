using System;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core
{
    public interface ICustomerInvoiceGenerator
    {
        Invoice GenerateInvoice(Customer customer, DateTime date);
    }
}