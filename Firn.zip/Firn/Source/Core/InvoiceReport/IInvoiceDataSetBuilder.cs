using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core.InvoiceReport
{
    public interface IInvoiceDataSetBuilder
    {
        void Build(InvoiceReportDataSet dataSet, Invoice invoice);
    }
}