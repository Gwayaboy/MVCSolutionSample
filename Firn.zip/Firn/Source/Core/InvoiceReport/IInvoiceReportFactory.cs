namespace Intrigma.Firn.Core.InvoiceReport
{
    public interface IInvoiceReportFactory
    {
        IInvoiceReport Create();
    }
}