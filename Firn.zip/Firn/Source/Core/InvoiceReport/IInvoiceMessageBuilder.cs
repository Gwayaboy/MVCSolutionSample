using System.Net.Mail;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core.InvoiceReport
{
    public interface IInvoiceMessageBuilder
    {
        MailMessage Build(Invoice invoice);
    }
}