using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core.InvoiceReport
{
    public class InvoiceDataSetBuilder : IInvoiceDataSetBuilder
    {
        private readonly IInvoiceRowBuilder _invoiceRowBuilder;
        private readonly IInvoiceLineItemRowBuilder _lineItemBuilder;

        public InvoiceDataSetBuilder(IInvoiceRowBuilder invoiceRowBuilder, IInvoiceLineItemRowBuilder lineItemBuilder)
        {
            _invoiceRowBuilder = invoiceRowBuilder;
            _lineItemBuilder = lineItemBuilder;
        }

        #region IInvoiceDataSetBuilder Members

        public void Build(InvoiceReportDataSet dataSet, Invoice invoice)
        {
            InvoiceReportDataSet.InvoiceRow row = _invoiceRowBuilder.Add(dataSet, invoice);
            foreach (InvoiceLineItem item in invoice.LineItems)
            {
                _lineItemBuilder.Add(dataSet, row, item);
            }
        }

        #endregion
    }
}