using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core.InvoiceReport
{
    public interface IInvoiceLineItemRowBuilder
    {
        InvoiceReportDataSet.InvoiceLineItemRow Add(InvoiceReportDataSet dataSet,
                                                    InvoiceReportDataSet.InvoiceRow invoiceRow, InvoiceLineItem item);
    }
}