using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core.InvoiceReport
{
    public interface IInvoiceReportBuilder
    {
        IInvoiceReport Build(Invoice invoice);
    }
}