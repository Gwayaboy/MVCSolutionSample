using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core.InvoiceReport
{
    public class InvoiceRowBuilder : IInvoiceRowBuilder
    {
        private readonly EnumFormatHelper _enumFormat = new EnumFormatHelper();

        #region IInvoiceRowBuilder Members

        public InvoiceReportDataSet.InvoiceRow Add(InvoiceReportDataSet dataSet, Invoice invoice)
        {
            Customer customer = invoice.Customer;
            return dataSet.Invoice.AddInvoiceRow(invoice.Id, invoice.Total, invoice.DueDate, invoice.InvoiceDate,
                                                 customer.AttnFullName, customer.Name, customer.EmailAddress,
                                                 customer.Address, _enumFormat.GetDescription(customer.BillingType),
                                                 customer.BillingPeriod.ToString(), customer.Phone);
        }

        #endregion
    }
}