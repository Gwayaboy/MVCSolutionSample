using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core.InvoiceReport
{
    public interface IInvoiceRowBuilder
    {
        InvoiceReportDataSet.InvoiceRow Add(InvoiceReportDataSet dataSet, Invoice invoice);
    }
}