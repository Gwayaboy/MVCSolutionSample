using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core.InvoiceReport
{
    public interface IInvoiceMailer
    {
        string Mail(Invoice invoice);
    }
}