using Intrigma.Firn.Core.Mail;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core.InvoiceReport
{
    public class InvoiceMailer : IInvoiceMailer
    {
        public const string NoEmailError = "The customer does not have an email address configured.";
        private readonly IMailProcessor _mailer;
        private readonly IInvoiceMessageBuilder _messageBuilder;

        public InvoiceMailer(IInvoiceMessageBuilder messageBuilder, IMailProcessor mailer)
        {
            _messageBuilder = messageBuilder;
            _mailer = mailer;
        }

        #region IInvoiceMailer Members

        public string Mail(Invoice invoice)
        {
            if (!invoice.Customer.CanSendEmail)
            {
                return NoEmailError;
            }
            _mailer.Send(_messageBuilder.Build(invoice));
            return null;
        }

        #endregion
    }
}