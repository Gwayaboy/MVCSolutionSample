using System.IO;
using DevExpress.XtraPrinting;
using DevExpress.XtraReports.UI;

namespace Intrigma.Firn.Core.InvoiceReport
{
    public class ReportPdfExporter : IReportPdfExporter
    {
        #region IReportPdfExporter Members

        public byte[] Export(IInvoiceReport report)
        {
            // Not testing this ugly I/O business.
            var realReport = (XtraReport) report;
            PdfExportOptions pdfOptions = realReport.ExportOptions.Pdf;
            pdfOptions.Compressed = true;
            pdfOptions.ImageQuality = PdfJpegImageQuality.High;
            var stream = new MemoryStream();
            realReport.ExportToPdf(stream);
            return stream.ToArray();
        }

        #endregion
    }
}