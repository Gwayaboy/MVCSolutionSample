using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core.InvoiceReport
{
    public class InvoiceLineItemRowBuilder : IInvoiceLineItemRowBuilder
    {
        #region IInvoiceLineItemRowBuilder Members

        public InvoiceReportDataSet.InvoiceLineItemRow Add(InvoiceReportDataSet dataSet,
                                                           InvoiceReportDataSet.InvoiceRow invoiceRow,
                                                           InvoiceLineItem item)
        {
            InvoiceReportDataSet.InvoiceLineItemRow row = dataSet.InvoiceLineItem.AddInvoiceLineItemRow(item.Id,
                                                                                                        invoiceRow,
                                                                                                        item.Name,
                                                                                                        item.Description,
                                                                                                        item.StaffCount ??
                                                                                                        0, item.Price,
                                                                                                        item.Date);
            if (item.StaffCount == null)
            {
                row.SetStaffCountNull();
            }
            return row;
        }

        #endregion
    }
}