using DevExpress.XtraReports.UI;

namespace Intrigma.Firn.Core.InvoiceReport
{
    public partial class InvoiceReport : XtraReport, IInvoiceReport
    {
        public InvoiceReport()
        {
            InitializeComponent();
        }
    }
}