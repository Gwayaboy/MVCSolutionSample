using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core.InvoiceReport
{
    public class InvoiceReportBuilder : IInvoiceReportBuilder
    {
        private readonly IInvoiceDataSetBuilder _dataSetBuilder;
        private readonly IInvoiceReportDataSetFactory _dataSetFactory;
        private readonly IInvoiceReportFactory _reportFactory;

        public InvoiceReportBuilder(IInvoiceReportDataSetFactory dataSetFactory, IInvoiceDataSetBuilder dataSetBuilder,
                                    IInvoiceReportFactory reportFactory)
        {
            _dataSetFactory = dataSetFactory;
            _dataSetBuilder = dataSetBuilder;
            _reportFactory = reportFactory;
        }

        #region IInvoiceReportBuilder Members

        public IInvoiceReport Build(Invoice invoice)
        {
            IInvoiceReport report = _reportFactory.Create();
            InvoiceReportDataSet dataSet = _dataSetFactory.Create();
            _dataSetBuilder.Build(dataSet, invoice);
            report.DataSource = dataSet;
            return report;
        }

        #endregion
    }
}