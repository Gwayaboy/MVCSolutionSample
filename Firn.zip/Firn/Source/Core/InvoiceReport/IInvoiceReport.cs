namespace Intrigma.Firn.Core.InvoiceReport
{
    public interface IInvoiceReport
    {
        object DataSource { set; }
    }
}