namespace Intrigma.Firn.Core.InvoiceReport
{
    public interface IInvoiceReportDataSetFactory
    {
        InvoiceReportDataSet Create();
    }
}