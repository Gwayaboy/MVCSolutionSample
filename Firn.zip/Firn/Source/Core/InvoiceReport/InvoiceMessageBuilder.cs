using System.IO;
using System.Net.Mail;
using System.Net.Mime;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core.InvoiceReport
{
    public class InvoiceMessageBuilder : IInvoiceMessageBuilder
    {
        public const string AttachmentNameFormat = "Invoice{0}.pdf";

        public const string AutoPayBodyFormat =
            @"Hello,

Thank you for choosing Intrigma. Invoice #{0} is attached. We will automatically {2} on the due date, {1:d}. If you have any questions in the meantime, please reply and let us know.
" +
            Signature;

        public const string BodyFormat =
            @"Hello,

Thank you for choosing Intrigma. Invoice #{0}, due on {1:d}, is attached. Please mail your payment to the address shown on the invoice. If you have any questions, please reply and let us know.
" +
            Signature;

        public const string Signature = @"
Have a great day,
The Intrigma Team";

        public const string SubjectFormat = "Intrigma Invoice #{0}, due {1:d}";
        private readonly ICustomerMessageBuilder _customerMessageBuilder;
        private readonly IReportPdfExporter _pdfExporter;
        private readonly IInvoiceReportBuilder _reportBuilder;

        public InvoiceMessageBuilder(IInvoiceReportBuilder reportBuilder, IReportPdfExporter pdfExporter,
                                     ICustomerMessageBuilder customerMessageBuilder)
        {
            _reportBuilder = reportBuilder;
            _pdfExporter = pdfExporter;
            _customerMessageBuilder = customerMessageBuilder;
        }

        #region IInvoiceMessageBuilder Members

        public MailMessage Build(Invoice invoice)
        {
            Customer customer = invoice.Customer;
            MailMessage message = _customerMessageBuilder.Build(customer);
            message.Subject = string.Format(SubjectFormat, invoice.Id, invoice.DueDate);
            if (customer.CanAutomaticallyChargePayments)
            {
                string phraseFormat =
                    new EnumFormatHelper().GetAttributeText<PaymentPhraseAttribute>(customer.BillingType);
                string paymentPhrase = string.Format(phraseFormat, invoice.Total);
                message.Body = string.Format(AutoPayBodyFormat, invoice.Id, invoice.DueDate, paymentPhrase);
            }
            else
            {
                message.Body = string.Format(BodyFormat, invoice.Id, invoice.DueDate);
            }
            Stream stream = new MemoryStream(_pdfExporter.Export(_reportBuilder.Build(invoice)));
            message.Attachments.Add(new Attachment(stream, string.Format(AttachmentNameFormat, invoice.Id),
                                                   MediaTypeNames.Application.Pdf));
            return message;
        }

        #endregion
    }
}