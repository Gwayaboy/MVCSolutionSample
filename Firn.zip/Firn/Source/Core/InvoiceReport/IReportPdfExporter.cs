namespace Intrigma.Firn.Core.InvoiceReport
{
    public interface IReportPdfExporter
    {
        byte[] Export(IInvoiceReport report);
    }
}