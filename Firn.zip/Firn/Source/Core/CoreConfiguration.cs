using System.Collections.Generic;
using System.Reflection;
using Castle.Core.Configuration;
using Castle.Facilities.AutomaticTransactionManagement;
using Castle.Facilities.Logging;
using Castle.Facilities.TypedFactory;
using Castle.MicroKernel;
using Castle.MicroKernel.Registration;
using Castle.MicroKernel.Releasers;
using Castle.Windsor;
using Castle.Windsor.Configuration.Interpreters;
using Intrigma.Firn.Core.Environment;
using Intrigma.Firn.Core.InvoiceReport;
using Intrigma.Firn.Core.Mail;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel.PaymentGateway;

namespace Intrigma.Firn.Core
{
    public static class CoreConfiguration
    {
        public static IWindsorContainer BuildContainer()
        {
            if (EnvironmentContext.CurrentEnvironment.UpgradeDatabaseOnStart)
            {
                DatabaseHelper.UpgradeDatabase();
            }
            var container = new WindsorContainer(new XmlInterpreter());
            // We have nothing that has to be cleaned up when disposed.
            container.Kernel.ReleasePolicy = new NoTrackingReleasePolicy();
            container.AddFacility("logging",
                                  new LoggingFacility(LoggerImplementation.Log4net,
                                                      EnvironmentContext.CurrentEnvironment.LoggingConfigFile));
            container.AddFacility<TransactionFacility>();
            container.AddFacility<TypedFactoryFacility>();
            var factoryFacility = GetFacility<TypedFactoryFacility>(container.Kernel);
            factoryFacility.AddTypedFactoryEntry(new FactoryEntry("invoiceReportDataSetFactory",
                                                                  typeof(IInvoiceReportDataSetFactory), "Create", null));
            factoryFacility.AddTypedFactoryEntry(new FactoryEntry("invoiceReportFactory", typeof(IInvoiceReportFactory),
                                                                  "Create", null));
            container.Register(Component.For<IEnvironment>().Instance(EnvironmentContext.CurrentEnvironment));
            container.Register(
                Component.For<IInvoiceReport>().ImplementedBy<InvoiceReport.InvoiceReport>().LifeStyle.Transient);
            container.Register(Component.For<InvoiceReportDataSet>().LifeStyle.Transient);
            container.Register(Component.For<IPaymentGateway>().ImplementedBy<StubPaymentGateway>());
            container.Register(Component.For<RemoveOutsideAddressesFilter>().Named("removeOutside"));
            container.Register(Component.For<SubjectPrefixFilter>().Named("subjectPrefix"));
            var mailFilters = new List<string> {"subjectPrefix"};
            if (EnvironmentContext.CurrentEnvironment.RemoveExternalEmailAddresses)
            {
                mailFilters.Insert(0, "removeOutside");
            }

            container.Register(
                Component.For<IMailProcessor>()
                         .ImplementedBy<MailProcessor>()
                         .Parameters(ListParameter("filters", mailFilters.ToArray())));
            container.Register(Component.For(typeof(IRepository<>)).ImplementedBy(typeof(NHibernateRepository<>)));
            container.Register(Component.For<ICustomerRepository>().ImplementedBy<CustomerRepository>());
            container.Register(Component.For<IInvoiceRepository>().ImplementedBy<InvoiceRepository>());
            RegisterTypesInAssembly(typeof(CoreConfiguration).Assembly, container.Kernel);
            return container;
        }

        public static T GetFacility<T>(IKernel kernel) where T : IFacility
        {
            foreach (var facility in kernel.GetFacilities())
            {
                if (facility is T)
                {
                    return (T) facility;
                }
            }
            return default(T);
        }

        public static void RegisterTypesInAssembly(Assembly assembly, IKernel kernel)
        {
            kernel.Register(AllTypes.Pick().FromAssembly(assembly).WithService.FirstInterface());
        }

        public static Parameter ListParameter(string name, params string[] ids)
        {
            var config = new MutableConfiguration(name);
            foreach (var id in ids)
            {
                config.Children.Add(new MutableConfiguration(name, "${" + id + "}"));
            }
            return Parameter.ForKey(name).Eq(config);
        }
    }
}