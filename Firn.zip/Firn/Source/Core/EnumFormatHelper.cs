using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using Castle.Core;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core
{
    public class EnumFormatHelper
    {
        public string GetDescription(Enum e)
        {
            return GetDescriptionFromName(e.ToString(), e.GetType());
        }

        private static string GetDescriptionFromName(string name, Type type)
        {
            MemberInfo[] members = type.GetMember(name);
            object[] attributes = members[0].GetCustomAttributes(typeof(DescriptionAttribute), false);
            if (attributes.Length == 0)
            {
                return name;
            }
            return ((DescriptionAttribute) attributes[0]).Description;
        }

        public IList<Pair<int, string>> EnumToPairs(Type type)
        {
            return EnumToPairs(type, new object[0]);
        }

        public IList<Pair<int, string>> EnumToPairs(Type type, IList exclude)
        {
            var result = new List<Pair<int, string>>();
            Array values = Enum.GetValues(type);
            string[] names = Enum.GetNames(type);
            for (int index = 0; index < names.Length; index++)
            {
                object value = values.GetValue(index);
                if (!Contains(exclude, value))
                {
                    result.Add(new Pair<int, string>((int) values.GetValue(index),
                                                     GetDescriptionFromName(names[index], type)));
                }
            }
            return result;
        }

        private static bool Contains(IList items, object toFind)
        {
            foreach (object item in items)
            {
                if (item.Equals(toFind))
                {
                    return true;
                }
            }
            return false;
        }

        public string GetAttributeText<T>(Enum value) where T : IDescriptionAttribute
        {
            string name = value.ToString();
            MemberInfo[] members = value.GetType().GetMember(name);
            object[] attributes = members[0].GetCustomAttributes(typeof(T), false);
            if (attributes.Length == 0)
            {
                return null;
            }
            return ((IDescriptionAttribute) attributes[0]).Text;
        }
    }
}