using Iesi.Collections.Generic;

namespace Intrigma.Firn.Core
{
    public static class Util
    {
        public static T[] SetToArray<T>(ISet<T> set)
        {
            var array = new T[set.Count];
            set.CopyTo(array, 0);
            return array;
        }

        public static ISet<T> ArrayToSet<T>(T[] array)
        {
            return new HashedSet<T>(array);
        }
    }
}