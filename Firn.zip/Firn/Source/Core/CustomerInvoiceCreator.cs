using System;
using Castle.Services.Transaction;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core
{
    [Transactional]
    public class CustomerInvoiceCreator : ICustomerInvoiceCreator
    {
        private readonly INextInvoiceNumber _idFetcher;
        private readonly IInvoiceRepository _invoiceRepository;

        public CustomerInvoiceCreator(INextInvoiceNumber idFetcher, IInvoiceRepository invoiceRepository)
        {
            _idFetcher = idFetcher;
            _invoiceRepository = invoiceRepository;
        }

        [Transaction]
        public Invoice CreateFor(Customer customer, DateTime date)
        {
            Statement statement = customer.CreateStatement(date);
            Invoice invoice = statement.CreateInvoice(_idFetcher.Next);
            if (invoice == null)
            {
                return null;
            }
            _invoiceRepository.Save(invoice);
            return invoice;
        }
    }
}