using Intrigma.Firn.DomainModel.PaymentGateway;

namespace Intrigma.Firn.Core
{
    public struct PaymentResult : IPaymentResult
    {
        private readonly string _rawMessage;
        private readonly bool _success;

        public PaymentResult(string rawMessage, bool success)
        {
            _rawMessage = rawMessage;
            _success = success;
        }

        #region IPaymentResult Members

        public string RawMessage
        {
            get { return _rawMessage; }
        }

        public bool Success
        {
            get { return _success; }
        }

        #endregion
    }
}