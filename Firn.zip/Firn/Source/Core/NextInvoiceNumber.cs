using Intrigma.Firn.Data;

namespace Intrigma.Firn.Core
{
    public class NextInvoiceNumber : INextInvoiceNumber
    {
        private readonly IInvoiceRepository _invoices;

        public NextInvoiceNumber(IInvoiceRepository invoices)
        {
            _invoices = invoices;
        }

        #region INextInvoiceNumber Members

        public int Next
        {
            get { return _invoices.LastInvoice() + 1; }
        }

        #endregion
    }
}