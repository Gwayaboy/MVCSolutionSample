using System;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core
{
    public interface ICustomerInvoiceCreator
    {
        Invoice CreateFor(Customer customer, DateTime date);
    }
}