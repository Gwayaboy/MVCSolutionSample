using System.Net.Mail;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Core
{
    public class CustomerMessageBuilder : ICustomerMessageBuilder
    {
        #region ICustomerMessageBuilder Members

        public MailMessage Build(Customer customer)
        {
            var message = new MailMessage(ProductNameConstants.FromAddress,
                                          new MailAddress(customer.EmailAddress, customer.AttnFullName));
            foreach (string cc in customer.SecondaryEmailAddresses)
            {
                message.CC.Add(new MailAddress(cc));
            }
            return message;
        }

        #endregion
    }
}