using System.Reflection;
using System.Web;
using Castle.MicroKernel.Registration;
using Castle.MonoRail.Framework;
using Castle.MonoRail.WindsorExtension;
using Castle.Windsor;
using Intrigma.Firn.Core;

namespace Intrigma.Firn.Admin
{
    public class Global : HttpApplication, IContainerAccessor
    {
        private static IWindsorContainer _container;

        #region IContainerAccessor

        public IWindsorContainer Container
        {
            get { return _container; }
        }

        #endregion

        public void Application_OnStart()
        {
            _container = CoreConfiguration.BuildContainer();
            _container.Kernel.AddFacility<MonoRailFacility>();
            _container.Kernel.Register(
                AllTypes.Of<SmartDispatcherController>().FromAssembly(Assembly.GetExecutingAssembly()));
            _container.Kernel.Register(AllTypes.Of<ViewComponent>().FromAssembly(Assembly.GetExecutingAssembly()));
            CoreConfiguration.RegisterTypesInAssembly(Assembly.GetExecutingAssembly(), _container.Kernel);
        }

        public void Application_OnEnd()
        {
            if (_container != null)
            {
                _container.Dispose();
            }
        }
    }
}