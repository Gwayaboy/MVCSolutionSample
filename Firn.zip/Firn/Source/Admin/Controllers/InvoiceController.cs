using System;
using System.Collections.Specialized;
using Castle.MonoRail.Framework;
using Castle.Services.Transaction;
using Intrigma.Firn.Core;
using Intrigma.Firn.Core.Web.Controllers;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Admin.Controllers
{
    [Transactional]
    public class InvoiceController : BaseController
    {
        private readonly ICustomerRepository _customerRepository;
        private readonly ICurrentDateFetcher _date;
        private readonly IInvoiceFactory _invoiceFactory;
        private readonly ICustomerInvoiceCreator _invoiceGenerator;
        private readonly INextInvoiceNumber _invoiceNumber;
        private readonly IInvoiceRepository _invoiceRepository;

        public InvoiceController(ICurrentDateFetcher date, INextInvoiceNumber invoiceNumber,
                                 IInvoiceRepository invoiceRepository, IInvoiceFactory invoiceFactory,
                                 ICustomerRepository customerRepository, ICustomerInvoiceCreator invoiceGenerator)
        {
            _date = date;
            _invoiceNumber = invoiceNumber;
            _invoiceRepository = invoiceRepository;
            _invoiceFactory = invoiceFactory;
            _customerRepository = customerRepository;
            _invoiceGenerator = invoiceGenerator;
        }

        public void View(int id)
        {
            PropertyBag[InvoiceConstants.Invoice] = _invoiceRepository.GetById(id);
        }

        public void Create(int id)
        {
            var today = _date.Now.ToShortDateString();
            PropertyBag[InvoiceConstants.InvoiceDate] = today;
            PropertyBag[InvoiceConstants.DueDate] = today;
            PropertyBag[InvoiceConstants.InvoiceNumber] = _invoiceNumber.Next;
            PropertyBag[CustomerConstants.Customer] = _customerRepository.GetById(id);
        }

        public void Generate(int id)
        {
            var customer = _customerRepository.GetById(id);
            PropertyBag[CustomerConstants.Customer] = customer;
            PropertyBag[InvoiceConstants.Invoice] = _invoiceGenerator.CreateFor(customer, _date.Now);
        }

        [Transaction]
        public virtual void SubmitClicked(DateTime invoiceDate, DateTime dueDate, int invoiceNum, int customerId,
                                          [DataBind("lineItems")] InvoiceLineItemModel[] items)
        {
            var invoice = _invoiceFactory.Create(_customerRepository.GetById(customerId), invoiceDate, dueDate,
                                                 invoiceNum);
            foreach (var item in items)
            {
                invoice.AddLineItem(new InvoiceLineItem(item.Date, item.Name, item.Description, item.StaffCount,
                                                        item.Price));
            }
            _invoiceRepository.Save(invoice);

            RedirectToView(invoice.Id);
        }

        private void RedirectToView(int id)
        {
            RedirectToAction("View", new NameValueCollection {{"id", id.ToString()}});
        }

        [Transaction]
        public virtual void Cancel(int id)
        {
            var invoice = _invoiceRepository.GetById(id);
            invoice.Cancel();
            _invoiceRepository.Save(invoice);

            RedirectToView(id);
        }

        [Transaction]
        public virtual void MarkPaid(int id)
        {
            var invoice = _invoiceRepository.GetById(id);
            invoice.MarkPaid(_date.Now);
            _invoiceRepository.Save(invoice);

            RedirectToView(id);
        }
    }
}