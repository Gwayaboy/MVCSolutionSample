using System;

namespace Intrigma.Firn.Admin.Controllers
{
    public struct InvoiceLineItemModel
    {
        private DateTime _date;
        private string _description;
        private string _name;
        private decimal _price;
        private int? _staffCount;

        public InvoiceLineItemModel(DateTime date, string name, string description, int? staffCount, decimal price)
        {
            _date = date;
            _name = name;
            _description = description;
            _staffCount = staffCount;
            _price = price;
        }

        public string Description
        {
            get { return _description; }
            set { _description = value; }
        }

        public int? StaffCount
        {
            get { return _staffCount; }
            set { _staffCount = value; }
        }

        public decimal Price
        {
            get { return _price; }
            set { _price = value; }
        }

        public string Name
        {
            get { return _name; }
            set { _name = value; }
        }

        public DateTime Date
        {
            get { return _date; }
            set { _date = value; }
        }
    }
}