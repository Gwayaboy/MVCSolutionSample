using System;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Admin.Controllers
{
    public interface IInvoiceFactory
    {
        Invoice Create(Customer customer, DateTime invoiceDate, DateTime dueDate, int invoiceNum);
    }
}