using System;
using System.Collections.Specialized;
using Castle.Services.Transaction;
using Intrigma.Firn.Core;
using Intrigma.Firn.Core.Web.Controllers;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Admin.Controllers
{
    [Transactional]
    public class SubscriptionController : BaseController
    {
        private readonly ICustomerRepository _customerRepository;
        private readonly IRepository<Subscription> _subscriptionRepository;

        public SubscriptionController(ICustomerRepository customerRepository,
                                      IRepository<Subscription> subscriptionRepository)
        {
            _customerRepository = customerRepository;
            _subscriptionRepository = subscriptionRepository;
        }

        public void Show(int customerId, int? id)
        {
            PropertyBag[CustomerConstants.Customer] = _customerRepository.GetById(customerId);
            if (id == null)
            {
                PropertyBag[SubscriptionConstants.BillableWeeksBefore] =
                    InstallmentTransaction.DefaultBillableWeeksBefore;
                return;
            }
            Subscription subscription = _subscriptionRepository.GetById(id.Value);
            PropertyBag[SubscriptionConstants.Id] = id;
            PropertyBag[SubscriptionConstants.Name] = subscription.Transaction.Name;
            PropertyBag[SubscriptionConstants.Description] = subscription.Transaction.Description;
            PropertyBag[SubscriptionConstants.StartDate] = subscription.Transaction.Date;
            PropertyBag[SubscriptionConstants.Months] = subscription.Months;
            PropertyBag[SubscriptionConstants.StaffCount] = subscription.StaffCount;
            PropertyBag[SubscriptionConstants.Amount] = subscription.Transaction.Amount;
            PropertyBag[SubscriptionConstants.BillableWeeksBefore] = subscription.Transaction.BillableWeeksBefore;
        }

        [Transaction]
        public virtual void Update(int customerId, int? id, decimal amount, string name, string description,
                                   DateTime startDate, int months, int staffCount, int billableWeeksBefore)
        {
            Customer customer = _customerRepository.GetById(customerId);
            if (id == null)
            {
                customer.AddSubscription(new Subscription(name, description, startDate, months, amount, staffCount,
                                                          billableWeeksBefore));
            }
            else
            {
                Subscription subscription = _subscriptionRepository.GetById(id.Value);
                subscription.Update(name, description, startDate, months, amount, staffCount, billableWeeksBefore);
            }
            _customerRepository.Save(customer);

            var parameters = new NameValueCollection();
            parameters["id"] = customerId.ToString();
            Redirect("Customer", "View", parameters);
        }
    }
}