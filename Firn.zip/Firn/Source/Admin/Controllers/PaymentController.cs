using System;
using System.Collections.Specialized;
using Castle.Services.Transaction;
using Intrigma.Firn.Core;
using Intrigma.Firn.Core.Web.Controllers;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Admin.Controllers
{
    [Transactional]
    public class PaymentController : BaseController
    {
        private readonly IRepository<Customer> _customerRepository;
        private readonly IRepository<Invoice> _invoiceRepository;
        private readonly IPaymentManager _paymentProcessor;

        public PaymentController(IRepository<Invoice> invoiceRepository, IPaymentManager paymentProcessor,
                                 IRepository<Customer> customerRepository)
        {
            _invoiceRepository = invoiceRepository;
            _paymentProcessor = paymentProcessor;
            _customerRepository = customerRepository;
        }

        public void ShowPayment(int id)
        {
            PropertyBag[InvoiceConstants.Invoice] = _invoiceRepository.GetById(id);
        }

        public void Pay(int id, decimal amount)
        {
            var invoice = _invoiceRepository.GetById(id);
            PropertyBag[InvoiceConstants.Invoice] = invoice;
            PropertyBag[InvoiceConstants.PaymentResult] = _paymentProcessor.MakePayment(invoice, amount);
        }

        public void ShowRefund(int id)
        {
            var customer = _customerRepository.GetById(id);
            PropertyBag[CustomerConstants.Customer] = customer;
        }

        public void Refund(int id, string reason, decimal amount)
        {
            var customer = _customerRepository.GetById(id);
            PropertyBag[CustomerConstants.Customer] = customer;
            PropertyBag[InvoiceConstants.PaymentResult] = _paymentProcessor.IssueRefund(customer, amount, reason);
        }

        public void ShowRecordPayment(int id)
        {
            var customer = _customerRepository.GetById(id);
            PropertyBag[CustomerConstants.Customer] = customer;
        }

        [Transaction]
        public virtual void RecordPayment(int id, DateTime date, BillingType billingType, decimal amount)
        {
            var customer = _customerRepository.GetById(id);
            customer.RecordPayment(date, billingType, amount);
            RedirectToViewCustomer(id);
        }

        private void RedirectToViewCustomer(int id)
        {
            var parameters = new NameValueCollection();
            parameters["id"] = id.ToString();
            Redirect("Customer", "View", parameters);
        }

        public void ShowAccountCredit(int id)
        {
            var customer = _customerRepository.GetById(id);
            PropertyBag[CustomerConstants.Customer] = customer;
        }

        [Transaction]
        public virtual void AddAccountCredit(int id, DateTime date, decimal amount, string reason)
        {
            var customer = _customerRepository.GetById(id);
            customer.AddAccountCredit(date, amount, reason);
            RedirectToViewCustomer(id);
        }

        public void ShowAccountCharge(int id)
        {
            var customer = _customerRepository.GetById(id);
            PropertyBag[CustomerConstants.Customer] = customer;
        }

        [Transaction]
        public virtual void AddAccountCharge(int id, DateTime date, string name, string description, decimal amount)
        {
            var customer = _customerRepository.GetById(id);
            customer.AddAccountCharge(date, name, description, amount);
            RedirectToViewCustomer(id);
        }

        public void ShowRecordInvoicePayment(int id)
        {
            PropertyBag[InvoiceConstants.Invoice] = _invoiceRepository.GetById(id);
        }

        [Transaction]
        public virtual void RecordInvoicePayment(int id, DateTime date, BillingType billingType, decimal amount)
        {
            var invoice = _invoiceRepository.GetById(id);
            invoice.RecordPayment(date, billingType, amount);
            Redirect("Invoice", "View", new NameValueCollection {{"id", id.ToString()}});
        }
    }
}