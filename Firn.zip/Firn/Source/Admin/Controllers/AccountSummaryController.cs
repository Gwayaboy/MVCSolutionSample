using System;
using System.Collections.Specialized;
using Castle.Services.Transaction;
using Intrigma.Firn.Core;
using Intrigma.Firn.Core.Web.Controllers;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Admin.Controllers
{
    [Transactional]
    public class AccountSummaryController : BaseController
    {
        private readonly IRepository<Customer> _customerRepository;

        public AccountSummaryController(IRepository<Customer> customerRepository)
        {
            _customerRepository = customerRepository;
        }

        public void Show(int id)
        {
            var customer = _customerRepository.GetById(id);
            PropertyBag[CustomerConstants.BillingStartDate] = customer.BillingStartDate;
            PropertyBag[CustomerConstants.BillingPeriod] = customer.BillingPeriod;
            PropertyBag[CustomerConstants.BillingNotes] = customer.BillingNotes;
            PropertyBag[CustomerConstants.NextInvoiceDate] = customer.NextInvoiceDate;
            PropertyBag[CustomerConstants.NextSteps] = customer.NextSteps;
            PropertyBag[CustomerConstants.NextStepsDate] = customer.NextStepsDate;
            PropertyBag[CustomerConstants.Customer] = customer;
        }

        [Transaction]
        public virtual void Update(int id, DateTime? billingStartDate, BillingPeriod billingPeriod, string billingNotes,
                                   DateTime? nextInvoiceDate, string nextSteps, DateTime? nextStepsDate)
        {
            var customer = _customerRepository.GetById(id);
            customer.BillingStartDate = billingStartDate;
            customer.BillingPeriod = billingPeriod;
            customer.BillingNotes = billingNotes ?? string.Empty;
            customer.NextInvoiceDate = nextInvoiceDate;
            customer.NextSteps = nextSteps ?? string.Empty;
            customer.NextStepsDate = nextStepsDate;
            _customerRepository.Save(customer);

            var values = new NameValueCollection();
            values["id"] = id.ToString();
            Redirect("Customer", "View", values);
        }
    }
}