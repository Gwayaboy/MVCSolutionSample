using System.Net.Mime;
using Intrigma.Firn.Core.InvoiceReport;
using Intrigma.Firn.Core.Web.Controllers;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Admin.Controllers
{
    public class InvoiceReportController : BaseController
    {
        public const string PdfContentType = MediaTypeNames.Application.Pdf;
        private readonly IInvoiceMailer _invoiceMailer;
        private readonly IReportPdfExporter _pdfExporter;
        private readonly IInvoiceReportBuilder _reportBuilder;
        private readonly IRepository<Invoice> _repository;

        public InvoiceReportController(IRepository<Invoice> repository, IReportPdfExporter pdfExporter,
                                       IInvoiceReportBuilder reportBuilder, IInvoiceMailer invoiceMailer)
        {
            _repository = repository;
            _pdfExporter = pdfExporter;
            _reportBuilder = reportBuilder;
            _invoiceMailer = invoiceMailer;
        }

        public void View(int id)
        {
            CancelView();
            Invoice invoice = _repository.GetById(id);
            IInvoiceReport report = _reportBuilder.Build(invoice);
            Response.ContentType = PdfContentType;
            Response.BinaryWrite(_pdfExporter.Export(report));
        }

        public void Email(int id)
        {
            Invoice invoice = _repository.GetById(id);
            PropertyBag[InvoiceConstants.Invoice] = invoice;
            PropertyBag[InvoiceConstants.EmailResults] = _invoiceMailer.Mail(invoice);
        }
    }
}