using System.Collections.Specialized;
using Castle.Services.Transaction;
using Intrigma.Firn.Core;
using Intrigma.Firn.Data;
using Intrigma.Firn.DomainModel;
using Intrigma.Firn.DomainModel.PaymentGateway;

namespace Intrigma.Firn.Admin.Controllers
{
    [Transactional]
    public class CustomerController : Core.Web.Controllers.CustomerController
    {
        public CustomerController(ICustomerRepository customerRepository, ICurrentDateFetcher date,
                                  IPaymentGateway gateway) : base(customerRepository, date, gateway) {}

        public override Customer GetCustomer()
        {
            int id = int.Parse(Request.Params["id"]);
            return _customerRepository.GetById(id);
        }

        public override void RedirectToView(Customer customer)
        {
            var values = new NameValueCollection();
            values["id"] = customer.Id.ToString();
            RedirectToAction("View", values);
        }
    }
}