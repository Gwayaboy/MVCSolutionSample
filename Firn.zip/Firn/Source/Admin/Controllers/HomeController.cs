using Intrigma.Firn.Core.Web.Controllers;
using Intrigma.Firn.Data;

namespace Intrigma.Firn.Admin.Controllers
{
    public class HomeController : BaseController
    {
        private readonly ICustomerRepository _customerRepository;

        public HomeController(ICustomerRepository customerRepository)
        {
            _customerRepository = customerRepository;
        }

        public void Index()
        {
            PropertyBag["customers"] = _customerRepository.ListByName();
        }
    }
}