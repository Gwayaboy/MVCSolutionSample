using System;
using Intrigma.Firn.DomainModel;

namespace Intrigma.Firn.Admin.Controllers
{
    public class InvoiceFactory : IInvoiceFactory
    {
        #region IInvoiceFactory Members

        public Invoice Create(Customer customer, DateTime invoiceDate, DateTime dueDate, int invoiceNum)
        {
            return new Invoice(customer, invoiceNum, invoiceDate, dueDate);
        }

        #endregion
    }
}