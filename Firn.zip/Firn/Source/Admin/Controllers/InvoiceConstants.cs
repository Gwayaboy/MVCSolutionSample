namespace Intrigma.Firn.Admin.Controllers
{
    public class InvoiceConstants
    {
        public const string DueDate = "dueDate";
        public const string EmailResults = "emailResults";
        public const string Invoice = "invoice";
        public const string InvoiceDate = "invoiceDate";
        public const string InvoiceNumber = "invoiceNum";
        public const string PaymentResult = "paymentResult";
    }
}