jQuery.validator.addMethod("datePicker", function(value, element) {
	if (this.optional(element))
	{
	    return true;
	}
	var result = /^(\d{1,2})\/(\d{1,2})\/(\d{4})$/.exec(value);
	if (result == null)
	{
	    return false;
	}
	var year = result[3];
	var month = result[1] - 1;
	var day = result[2];
	var date = new Date(year, month, day);
	return (date.getDate() == day) && (date.getMonth() == month) && (date.getFullYear() == year);
}, "Please enter a valid date.");
